#include "ModeRail.h"
#include "../NativeDesignSystem.h"
#include "../GraphicsDevice.h"

namespace components {

ModeRail::ModeRail() {
    // Visual top-to-bottom order. Modes without a real backend are disabled.
    m_items = {
        { app::AppMode::View,     L"View",     controls::IconType::View,     true  },
        { app::AppMode::Edit,     L"Edit",     controls::IconType::Edit,     true  },
        { app::AppMode::Comment,  L"Comment",  controls::IconType::Comment,  true  },
        { app::AppMode::Organize, L"Organize", controls::IconType::Organize, true  },
        { app::AppMode::Tools,    L"Tools",    controls::IconType::Tools,    true  }
    };
}

void ModeRail::EnsureFormat() {
    if (m_labelFormat) return;

    auto factory = GraphicsDevice::Instance().GetDWriteFactory();
    if (!factory) return;

    HRESULT hr = factory->CreateTextFormat(
        L"Segoe UI", nullptr,
        DWRITE_FONT_WEIGHT_MEDIUM, DWRITE_FONT_STYLE_NORMAL, DWRITE_FONT_STRETCH_NORMAL,
        design::TypographySize::Caption, L"en-us", &m_labelFormat);
    if (FAILED(hr) || !m_labelFormat) { m_labelFormat.Reset(); return; }

    m_labelFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
    m_labelFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_NEAR);
    m_labelFormat->SetWordWrapping(DWRITE_WORD_WRAPPING_NO_WRAP);
}

int ModeRail::ItemAt(float x, float y) const {
    if (x < m_bounds.left || x > m_bounds.right) return -1;
    if (y < m_bounds.top || y > m_bounds.bottom) return -1;
    float adjustedY = y - m_bounds.top - design::Spacing::Medium2;
    if (adjustedY < 0) return -1;
    int idx = static_cast<int>(adjustedY / kItemHeight);
    if (idx < 0 || idx >= static_cast<int>(m_items.size())) return -1;
    return idx;
}

void ModeRail::Render(ComPtr<ID2D1RenderTarget> target) {
    EnsureFormat();

    // Rail background
    ComPtr<ID2D1SolidColorBrush> bgBrush;
    target->CreateSolidColorBrush(design::Colors::Background, &bgBrush);
    target->FillRectangle(m_bounds, bgBrush.Get());

    ComPtr<ID2D1SolidColorBrush> brush;
    target->CreateSolidColorBrush(design::Colors::TextSecondary, &brush);

    for (int i = 0; i < static_cast<int>(m_items.size()); ++i) {
        const Item& item = m_items[i];
        float cellTop = m_bounds.top + i * kItemHeight + design::Spacing::Medium2; // add top padding
        float cellBottom = cellTop + kItemHeight;
        if (cellTop > m_bounds.bottom) break; // don't draw below the rail
        D2D1_RECT_F cell = { m_bounds.left, cellTop, m_bounds.right, cellBottom };

        bool isActive = (item.mode == m_activeMode);

        // Cell background: hovered enabled = subtle hover.
        if (item.enabled && i == m_hoverIndex && !isActive) {
            ComPtr<ID2D1SolidColorBrush> hoverBrush;
            target->CreateSolidColorBrush(design::Colors::ControlHover, &hoverBrush);
            target->FillRectangle(cell, hoverBrush.Get());
        }

        // Content color
        D2D1_COLOR_F contentColor = design::Colors::TextSecondary;
        if (!item.enabled) contentColor = design::Colors::TextDisabled;
        else if (isActive) contentColor = design::Colors::TextPrimary; // Or a specific active color

        // Active pill container
        if (isActive) {
            ComPtr<ID2D1SolidColorBrush> accentBrush;
            // Draw a rounded pill in the center of the cell
            D2D1_COLOR_F pillColor = design::Colors::AccentPrimary; 
            pillColor.a = 0.2f; // semi-transparent background for pill
            target->CreateSolidColorBrush(pillColor, &accentBrush);
            
            float pillMarginX = 8.0f;
            float pillMarginY = 4.0f;
            D2D1_RECT_F pillRect = { cell.left + pillMarginX, cellTop + pillMarginY, cell.right - pillMarginX, cellBottom - pillMarginY };
            D2D1_ROUNDED_RECT roundedPill = D2D1::RoundedRect(pillRect, 8.0f, 8.0f);
            target->FillRoundedRectangle(&roundedPill, accentBrush.Get());
            
            // Text color matches the vibrant primary color
            contentColor = design::Colors::AccentPrimary;
            contentColor.a = 1.0f;
        }

        // Icon (24x24) centered horizontally, upper portion of the cell
        float cx = (m_bounds.left + m_bounds.right) / 2.0f;
        float iconTop = cellTop + 10.0f;
        D2D1_RECT_F iconBounds = { cx - 12.0f, iconTop, cx + 12.0f, iconTop + 24.0f };
        controls::IconRenderer::DrawIcon(target, item.icon, iconBounds, contentColor);

        // Label under the icon
        if (m_labelFormat) {
            ComPtr<ID2D1SolidColorBrush> textBrush;
            target->CreateSolidColorBrush(contentColor, &textBrush);
            D2D1_RECT_F labelBounds = { m_bounds.left, iconTop + 26.0f, m_bounds.right, cellBottom - 2.0f };
            target->DrawText(item.label.c_str(), static_cast<UINT32>(item.label.length()),
                m_labelFormat.Get(), labelBounds, textBrush.Get());
        }
    }

    // Right border of the rail
    ComPtr<ID2D1SolidColorBrush> borderBrush;
    target->CreateSolidColorBrush(design::Colors::Border, &borderBrush);
    target->DrawLine(
        D2D1::Point2F(m_bounds.right, m_bounds.top),
        D2D1::Point2F(m_bounds.right, m_bounds.bottom),
        borderBrush.Get(), 1.0f);
}

void ModeRail::OnMouseMove(float x, float y) {
    int idx = ItemAt(x, y);
    if (idx >= 0 && !m_items[idx].enabled) idx = -1; // don't hover disabled modes
    m_hoverIndex = idx;
}

void ModeRail::OnMouseDown(float x, float y) {
    int idx = ItemAt(x, y);
    m_pressedIndex = (idx >= 0 && m_items[idx].enabled) ? idx : -1;
}

void ModeRail::OnMouseUp(float x, float y) {
    int idx = ItemAt(x, y);
    if (idx >= 0 && idx == m_pressedIndex && m_items[idx].enabled) {
        m_activeMode = m_items[idx].mode;
        if (m_onModeSelected) m_onModeSelected(m_items[idx].mode);
    }
    m_pressedIndex = -1;
}

void ModeRail::OnMouseLeave() {
    m_hoverIndex = -1;
    m_pressedIndex = -1;
}

} // namespace components
