#pragma once
#include <d2d1_1.h>
#include <wrl/client.h>
#include "../GraphicsDevice.h"
#include <algorithm>

using Microsoft::WRL::ComPtr;

namespace controls {

enum class IconType {
    None, Home, Recent, Star, Edit, Comment, Combine, Open, Menu, Settings, Save, Undo, Redo, Search, ZoomIn, ZoomOut, AddText, Highlight, Rectangle, Close, Maximize, Minimize, Convert, OCR, Translate, Compress, Batch, PDFDocument, Folder, More,
    // Mode-rail icons (added for the multi-mode workspace)
    View, Organize, Tools, Form
};

class IconRenderer {
public:
    static void DrawIcon(ComPtr<ID2D1RenderTarget> target, IconType type, const D2D1_RECT_F& bounds, D2D1_COLOR_F color) {
        ComPtr<ID2D1SolidColorBrush> brush;
        target->CreateSolidColorBrush(color, &brush);
        
        float cx = (bounds.left + bounds.right) / 2.0f;
        float cy = (bounds.top + bounds.bottom) / 2.0f;
        float w = bounds.right - bounds.left;
        float h = bounds.bottom - bounds.top;
        float s = (w < h ? w : h) * 0.5f; // size
        float stroke = 1.5f;

        switch (type) {
            case IconType::Convert: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.4f, cy - s*0.4f, cx + s*0.1f, cy + s*0.4f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.1f, cy), D2D1::Point2F(cx + s*0.5f, cy), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.5f, cy), D2D1::Point2F(cx + s*0.3f, cy - s*0.2f), brush.Get(), stroke);
                break;
            }
            case IconType::OCR: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.5f, cy - s*0.5f, cx + s*0.5f, cy + s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.2f, cy - s*0.2f), D2D1::Point2F(cx + s*0.2f, cy - s*0.2f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.2f, cy + s*0.2f), D2D1::Point2F(cx + s*0.2f, cy + s*0.2f), brush.Get(), stroke);
                break;
            }
            case IconType::Translate: {
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx, cy), s*0.4f, s*0.4f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy), D2D1::Point2F(cx + s*0.4f, cy), brush.Get(), stroke);
                break;
            }
            case IconType::Compress: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.5f, cy - s*0.3f, cx + s*0.5f, cy + s*0.3f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.2f, cy - s*0.6f), D2D1::Point2F(cx - s*0.2f, cy - s*0.3f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.2f, cy + s*0.3f), D2D1::Point2F(cx + s*0.2f, cy + s*0.6f), brush.Get(), stroke);
                break;
            }
            case IconType::Batch: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.5f, cy - s*0.5f, cx + s*0.2f, cy + s*0.2f), brush.Get(), stroke);
                target->DrawRectangle(D2D1::RectF(cx - s*0.2f, cy - s*0.2f, cx + s*0.5f, cy + s*0.5f), brush.Get(), stroke);
                break;
            }
            case IconType::PDFDocument: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.4f, cy - s*0.5f, cx + s*0.4f, cy + s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.2f, cy - s*0.2f), D2D1::Point2F(cx + s*0.2f, cy - s*0.2f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.2f, cy), D2D1::Point2F(cx + s*0.2f, cy), brush.Get(), stroke);
                break;
            }
            case IconType::Folder: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.5f, cy - s*0.3f, cx + s*0.5f, cy + s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.5f, cy - s*0.3f), D2D1::Point2F(cx - s*0.2f, cy - s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.2f, cy - s*0.5f), D2D1::Point2F(cx + s*0.2f, cy - s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.2f, cy - s*0.5f), D2D1::Point2F(cx + s*0.5f, cy - s*0.3f), brush.Get(), stroke);
                break;
            }
            case IconType::More: {
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx - s*0.3f, cy), 1.5f, 1.5f), brush.Get(), stroke);
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx, cy), 1.5f, 1.5f), brush.Get(), stroke);
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx + s*0.3f, cy), 1.5f, 1.5f), brush.Get(), stroke);
                break;
            }
            case IconType::Home: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.4f, cy, cx + s*0.4f, cy + s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.6f, cy), D2D1::Point2F(cx, cy - s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx, cy - s*0.5f), D2D1::Point2F(cx + s*0.6f, cy), brush.Get(), stroke);
                break;
            }
            case IconType::Recent: {
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx, cy), s*0.5f, s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx, cy - s*0.3f), D2D1::Point2F(cx, cy), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx, cy), D2D1::Point2F(cx + s*0.2f, cy + s*0.2f), brush.Get(), stroke);
                break;
            }
            case IconType::Star: {
                target->DrawLine(D2D1::Point2F(cx, cy - s*0.5f), D2D1::Point2F(cx + s*0.3f, cy + s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.3f, cy + s*0.5f), D2D1::Point2F(cx - s*0.5f, cy - s*0.1f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.5f, cy - s*0.1f), D2D1::Point2F(cx + s*0.5f, cy - s*0.1f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.5f, cy - s*0.1f), D2D1::Point2F(cx - s*0.3f, cy + s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.3f, cy + s*0.5f), D2D1::Point2F(cx, cy - s*0.5f), brush.Get(), stroke);
                break;
            }
            case IconType::Open: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.5f, cy - s*0.4f, cx + s*0.5f, cy + s*0.4f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.5f, cy - s*0.1f), D2D1::Point2F(cx + s*0.5f, cy - s*0.1f), brush.Get(), stroke);
                break;
            }
            case IconType::Edit: {
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy + s*0.4f), D2D1::Point2F(cx + s*0.3f, cy - s*0.3f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.3f, cy - s*0.3f), D2D1::Point2F(cx + s*0.5f, cy - s*0.1f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.5f, cy - s*0.1f), D2D1::Point2F(cx - s*0.2f, cy + s*0.6f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.2f, cy + s*0.6f), D2D1::Point2F(cx - s*0.4f, cy + s*0.4f), brush.Get(), stroke);
                break;
            }
            case IconType::Save: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.5f, cy - s*0.5f, cx + s*0.5f, cy + s*0.5f), brush.Get(), stroke);
                target->DrawRectangle(D2D1::RectF(cx - s*0.3f, cy - s*0.5f, cx + s*0.3f, cy - s*0.1f), brush.Get(), stroke);
                break;
            }
            case IconType::Search: {
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx - s*0.2f, cy - s*0.2f), s*0.3f, s*0.3f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.05f, cy + s*0.05f), D2D1::Point2F(cx + s*0.5f, cy + s*0.5f), brush.Get(), stroke);
                break;
            }
            case IconType::Menu: {
                target->DrawLine(D2D1::Point2F(cx - s*0.5f, cy - s*0.3f), D2D1::Point2F(cx + s*0.5f, cy - s*0.3f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.5f, cy), D2D1::Point2F(cx + s*0.5f, cy), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.5f, cy + s*0.3f), D2D1::Point2F(cx + s*0.5f, cy + s*0.3f), brush.Get(), stroke);
                break;
            }
            case IconType::Settings: {
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx, cy), s*0.2f, s*0.2f), brush.Get(), stroke);
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx, cy), s*0.5f, s*0.5f), brush.Get(), stroke); 
                break;
            }
            case IconType::Close: {
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy - s*0.4f), D2D1::Point2F(cx + s*0.4f, cy + s*0.4f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy + s*0.4f), D2D1::Point2F(cx + s*0.4f, cy - s*0.4f), brush.Get(), stroke);
                break;
            }
            case IconType::Maximize: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.4f, cy - s*0.4f, cx + s*0.4f, cy + s*0.4f), brush.Get(), stroke);
                break;
            }
            case IconType::Minimize: {
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy), D2D1::Point2F(cx + s*0.4f, cy), brush.Get(), stroke);
                break;
            }
            case IconType::Comment: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.5f, cy - s*0.4f, cx + s*0.5f, cy + s*0.3f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.2f, cy + s*0.3f), D2D1::Point2F(cx - s*0.2f, cy + s*0.6f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.2f, cy + s*0.6f), D2D1::Point2F(cx + s*0.1f, cy + s*0.3f), brush.Get(), stroke);
                break;
            }
            case IconType::Combine: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.5f, cy - s*0.5f, cx + s*0.1f, cy + s*0.1f), brush.Get(), stroke);
                target->DrawRectangle(D2D1::RectF(cx - s*0.1f, cy - s*0.1f, cx + s*0.5f, cy + s*0.5f), brush.Get(), stroke);
                break;
            }
            case IconType::Undo: {
                target->DrawLine(D2D1::Point2F(cx + s*0.4f, cy + s*0.4f), D2D1::Point2F(cx + s*0.4f, cy - s*0.2f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.4f, cy - s*0.2f), D2D1::Point2F(cx - s*0.4f, cy - s*0.2f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy - s*0.2f), D2D1::Point2F(cx - s*0.1f, cy - s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy - s*0.2f), D2D1::Point2F(cx - s*0.1f, cy + s*0.1f), brush.Get(), stroke);
                break;
            }
            case IconType::Redo: {
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy + s*0.4f), D2D1::Point2F(cx - s*0.4f, cy - s*0.2f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy - s*0.2f), D2D1::Point2F(cx + s*0.4f, cy - s*0.2f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.4f, cy - s*0.2f), D2D1::Point2F(cx + s*0.1f, cy - s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.4f, cy - s*0.2f), D2D1::Point2F(cx + s*0.1f, cy + s*0.1f), brush.Get(), stroke);
                break;
            }
            case IconType::ZoomIn: {
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx - s*0.2f, cy - s*0.2f), s*0.3f, s*0.3f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.05f, cy + s*0.05f), D2D1::Point2F(cx + s*0.5f, cy + s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy - s*0.2f), D2D1::Point2F(cx, cy - s*0.2f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.2f, cy - s*0.4f), D2D1::Point2F(cx - s*0.2f, cy), brush.Get(), stroke);
                break;
            }
            case IconType::ZoomOut: {
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx - s*0.2f, cy - s*0.2f), s*0.3f, s*0.3f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.05f, cy + s*0.05f), D2D1::Point2F(cx + s*0.5f, cy + s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy - s*0.2f), D2D1::Point2F(cx, cy - s*0.2f), brush.Get(), stroke);
                break;
            }
            case IconType::AddText: {
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy - s*0.4f), D2D1::Point2F(cx + s*0.4f, cy - s*0.4f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx, cy - s*0.4f), D2D1::Point2F(cx, cy + s*0.4f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.2f, cy + s*0.4f), D2D1::Point2F(cx + s*0.2f, cy + s*0.4f), brush.Get(), stroke);
                break;
            }
            case IconType::Highlight: {
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy + s*0.4f), D2D1::Point2F(cx + s*0.4f, cy + s*0.4f), brush.Get(), stroke * 1.5f);
                target->DrawLine(D2D1::Point2F(cx - s*0.2f, cy + s*0.1f), D2D1::Point2F(cx + s*0.4f, cy - s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.4f, cy - s*0.5f), D2D1::Point2F(cx + s*0.2f, cy - s*0.7f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx + s*0.2f, cy - s*0.7f), D2D1::Point2F(cx - s*0.4f, cy - s*0.1f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy - s*0.1f), D2D1::Point2F(cx - s*0.2f, cy + s*0.1f), brush.Get(), stroke);
                break;
            }
            case IconType::Rectangle: {
                target->DrawRectangle(D2D1::RectF(cx - s*0.4f, cy - s*0.3f, cx + s*0.4f, cy + s*0.3f), brush.Get(), stroke);
                break;
            }
            case IconType::View: {
                // Eye: outer almond + pupil
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx, cy), s*0.5f, s*0.3f), brush.Get(), stroke);
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx, cy), s*0.15f, s*0.15f), brush.Get(), stroke);
                break;
            }
            case IconType::Organize: {
                // Two stacked page rectangles (page management)
                target->DrawRectangle(D2D1::RectF(cx - s*0.45f, cy - s*0.45f, cx + s*0.15f, cy + s*0.35f), brush.Get(), stroke);
                target->DrawRectangle(D2D1::RectF(cx - s*0.15f, cy - s*0.35f, cx + s*0.45f, cy + s*0.45f), brush.Get(), stroke);
                break;
            }
            case IconType::Tools: {
                // Wrench-ish: diagonal handle with a head notch
                target->DrawLine(D2D1::Point2F(cx - s*0.4f, cy + s*0.4f), D2D1::Point2F(cx + s*0.2f, cy - s*0.2f), brush.Get(), stroke * 1.3f);
                target->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(cx + s*0.3f, cy - s*0.3f), s*0.2f, s*0.2f), brush.Get(), stroke);
                break;
            }
            case IconType::Form: {
                // Form: framed box with two field lines and a check
                target->DrawRectangle(D2D1::RectF(cx - s*0.45f, cy - s*0.5f, cx + s*0.45f, cy + s*0.5f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.25f, cy - s*0.15f), D2D1::Point2F(cx + s*0.25f, cy - s*0.15f), brush.Get(), stroke);
                target->DrawLine(D2D1::Point2F(cx - s*0.25f, cy + s*0.15f), D2D1::Point2F(cx + s*0.1f, cy + s*0.15f), brush.Get(), stroke);
                break;
            }
            default: {
                // No fallback dots!
                break;
            }
        }
    }
};

} // namespace controls
