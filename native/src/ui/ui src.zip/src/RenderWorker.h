#pragma once
#include "TileCache.h"
#include <queue>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include "pdf_engine/IDocument.h"

struct RenderTask {
    uint64_t generation;
    TileKey key;
    int startX;
    int startY;
    int width;
    int height;
    float dpiScale = 1.0f; // New DPI scale property
    int priority = 1; // 0 = High (Visible), 1 = Normal, 2 = Low (Thumbnails)

    bool operator<(const RenderTask& other) const {
        return priority > other.priority; // std::priority_queue outputs largest first
    }
};

struct RenderResult {
    uint64_t generation;
    TileKey key;
    std::vector<uint8_t> buffer;
    int width;
    int height;
    float dpiScale = 1.0f;
};

class RenderWorker {
public:
    RenderWorker(HWND hwndNotify, std::shared_ptr<IDocument> doc, int numThreads = 1);
    ~RenderWorker();
    void Enqueue(const RenderTask& task);
    void CancelAll();
    void SetCurrentGeneration(uint64_t gen) { m_currentGeneration = gen; }

private:
    void WorkerThread(int threadIndex);

    HWND m_hwndNotify;
    std::shared_ptr<IDocument> m_doc; // original
    std::vector<std::shared_ptr<IDocument>> m_threadDocs; // clones
    
    std::priority_queue<RenderTask> m_queue;
    std::mutex m_mutex;
    std::condition_variable m_cv;
    std::vector<std::thread> m_threads;
    std::atomic<bool> m_stop{false};
    std::atomic<uint64_t> m_currentGeneration{0};
};
