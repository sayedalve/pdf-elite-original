#include "InteractionManager.h"
#include "AnnotationSelectableObject.h"
#include <cmath>
#include "commands/TextCommands.h"

namespace ui {
namespace interaction {

InteractionManager::InteractionManager() {
    m_selection.onSelectionChanged = [this]() {
        if (onSelectionChanged) onSelectionChanged();
    };
}
InteractionManager::~InteractionManager() {}

void InteractionManager::SetObjects(const std::vector<std::shared_ptr<ISelectableObject>>& objects) {
    m_objects = objects;
    m_selection.Clear();
}

void InteractionManager::AddObject(std::shared_ptr<ISelectableObject> obj) {
    m_objects.push_back(obj);
}

void InteractionManager::AddObjects(const std::vector<std::shared_ptr<ISelectableObject>>& objects) {
    m_objects.insert(m_objects.end(), objects.begin(), objects.end());
}

void InteractionManager::RemoveObject(const std::string& id) {
    auto it = std::remove_if(m_objects.begin(), m_objects.end(), [&](const auto& o) { return !o || o->GetId() == id; });
    m_objects.erase(it, m_objects.end());
}

void InteractionManager::RemoveObjectsForPage(int pageIndex) {
    // Deselect the page's objects BEFORE removing them, iterating the live
    // vector. This used to run the deselect loop over the [it, end) tail left
    // behind by std::remove_if -- but remove_if move-assigns the *kept*
    // elements toward the front, so that tail holds moved-from (null)
    // shared_ptrs, not the removed objects. Dereferencing (*i)->GetId() on a
    // moved-from/null element caused a null-pointer access violation while
    // scrolling a page that had selectable objects out of view. Iterate the
    // intact objects first, then mutate.
    for (const auto& o : m_objects) {
        if (o && o->GetPageIndex() == pageIndex) {
            m_selection.Deselect(o->GetId());
        }
    }
    m_objects.erase(
        std::remove_if(m_objects.begin(), m_objects.end(),
            [&](const auto& o) { return !o || o->GetPageIndex() == pageIndex; }),
        m_objects.end());
}

std::vector<std::shared_ptr<ISelectableObject>> InteractionManager::GetSelection() const {
    return m_selection.GetSelected();
}

void InteractionManager::EnterTextEditMode(std::shared_ptr<TextSelectableObject> obj) {
    if (m_isEditingText) {
        CommitTextEdit();
    }
    m_isEditingText = true;
    m_editingTextObj = obj;
    m_textEditor.SetActive(true);
    
    auto textObj = obj->GetTextObject();
    m_textEditor.SetText(textObj->GetText());
    
    m_textEditor.SetFont(std::wstring(textObj->GetFontName().begin(), textObj->GetFontName().end()), textObj->GetFontSize());
    
    uint8_t r, g, b, a;
    textObj->GetColor(r, g, b, a);
    m_textEditor.SetColor(D2D1::ColorF(r / 255.0f, g / 255.0f, b / 255.0f, a / 255.0f));
    
    m_textEditor.SetBounds(GetObjectBoundsInView(*obj));
    
    // Capture original lines for undo
    m_editingOriginalLines.clear();
    for (const auto& line : m_textEditor.GetLines()) {
        pdf_engine::TextLineData d;
        d.text = line.text;
        d.x = line.x;
        d.y = line.y;
        d.width = line.width;
        d.height = line.height;
        m_editingOriginalLines.push_back(d);
    }
    
    if (invalidateView) invalidateView();
}

void InteractionManager::CommitTextEdit() {
    if (!m_isEditingText || !m_editingTextObj) return;
    
    std::wstring newText = m_textEditor.GetText();
    
    std::vector<pdf_engine::TextLineData> pdfLines;
    for (const auto& line : m_textEditor.GetLines()) {
        pdf_engine::TextLineData d;
        d.text = line.text;
        d.x = line.x;
        d.y = line.y;
        d.width = line.width;
        d.height = line.height;
        pdfLines.push_back(d);
    }
    
    // Create the command
    auto editCmd = std::make_unique<pdf_engine::commands::EditMultilineTextCommand>(
        m_editingTextObj->GetTextObject(),
        m_editingOriginalLines,
        pdfLines
    );
    
    // We execute via the document's CommandStack
    if (onCommandRequested) {
        onCommandRequested(std::move(editCmd));
    } else {
        // Fallback for tests if onCommandRequested is not wired
        m_editingTextObj->GetTextObject()->SetLines(pdfLines);
    }
    
    if (onObjectCommitted) {
        onObjectCommitted(m_editingTextObj, m_editingTextObj->GetBounds(), m_editingTextObj->GetBounds(), false, pdf_engine::LineGeometry());
    }
    
    m_isEditingText = false;
    m_editingTextObj = nullptr;
    m_textEditor.SetActive(false);
    if (invalidateView) invalidateView();
}

void InteractionManager::CancelTextEdit() {
    if (!m_isEditingText) return;
    m_isEditingText = false;
    m_editingTextObj = nullptr;
    m_textEditor.SetActive(false);
    if (invalidateView) invalidateView();
}


void InteractionManager::GetHandleRects(const D2D1_RECT_F& bounds, float scale, D2D1_RECT_F rects[9]) {
    float hw = 4.0f / scale; // handle half-width
    float cx = (bounds.left + bounds.right) / 2.0f;
    float cy = (bounds.top + bounds.bottom) / 2.0f;
    
    // TopLeft, Top, TopRight
    rects[0] = { bounds.left - hw, bounds.top - hw, bounds.left + hw, bounds.top + hw };
    rects[1] = { cx - hw, bounds.top - hw, cx + hw, bounds.top + hw };
    rects[2] = { bounds.right - hw, bounds.top - hw, bounds.right + hw, bounds.top + hw };
    // Right
    rects[3] = { bounds.right - hw, cy - hw, bounds.right + hw, cy + hw };
    // BottomRight, Bottom, BottomLeft
    rects[4] = { bounds.right - hw, bounds.bottom - hw, bounds.right + hw, bounds.bottom + hw };
    rects[5] = { cx - hw, bounds.bottom - hw, cx + hw, bounds.bottom + hw };
    rects[6] = { bounds.left - hw, bounds.bottom - hw, bounds.left + hw, bounds.bottom + hw };
    // Left
    rects[7] = { bounds.left - hw, cy - hw, bounds.left + hw, cy + hw };
    // Rotation (above top)
    rects[8] = { cx - hw, bounds.top - 20.0f / scale - hw, cx + hw, bounds.top - 20.0f / scale + hw };
}

D2D1_RECT_F InteractionManager::GetObjectBoundsInView(const ISelectableObject& obj) {
    Rect b = obj.GetBounds();
    double vl, vt, vr, vb;
    if (pageToView) {
        pageToView(b.left, b.top, obj.GetPageIndex(), vl, vt);
        pageToView(b.right, b.bottom, obj.GetPageIndex(), vr, vb);
        return D2D1::RectF(static_cast<float>(vl), static_cast<float>(vt), static_cast<float>(vr), static_cast<float>(vb));
    }
    return D2D1::RectF(0,0,0,0);
}

HandleType InteractionManager::HitTestHandles(double vx, double vy, float scale) {
    for (auto& obj : m_selection.GetSelected()) {
        D2D1_RECT_F bounds = GetObjectBoundsInView(*obj);
        D2D1_RECT_F rects[9];
        GetHandleRects(bounds, scale, rects);
        
        for (int i = 0; i < 9; ++i) {
            if (vx >= rects[i].left && vx <= rects[i].right && vy >= rects[i].top && vy <= rects[i].bottom) {
                return static_cast<HandleType>(i + 1);
            }
        }
    }
    return HandleType::None;
}

std::shared_ptr<ISelectableObject> InteractionManager::HitTestObjects(double px, double py, int pageIndex) {
    for (auto it = m_objects.rbegin(); it != m_objects.rend(); ++it) {
        auto& obj = *it;
        if (obj->GetPageIndex() != pageIndex) continue;
        if (obj->HitTest(px, py)) {
            return obj;
        }
    }
    return nullptr;
}

HitResult InteractionManager::OnLButtonDown(double x, double y, bool shiftPressed) {
    if (m_isEditingText) {
        // If clicking inside the text editor bounds, pass it to the editor
        D2D1_RECT_F b = m_textEditor.GetBounds();
        if (x >= b.left && x <= b.right && y >= b.top && y <= b.bottom) {
            m_textEditor.OnLButtonDown(x, y, shiftPressed);
            if (invalidateView) invalidateView();
            return HitResult::Object;
        } else {
            // Clicked outside, commit text edit
            CommitTextEdit();
        }
    }

    HandleType handle = HitTestHandles(x, y, 1.0f); // TODO: actual scale needed for accurate handle hit test
    if (handle != HandleType::None) {
        m_drag.active = true;
        m_drag.handle = handle;
        m_drag.startX = x;
        m_drag.startY = y;
        m_drag.hasOriginalLineGeometry = false;
        // Find which object owns the handle (assuming single selection for resize)
        if (!m_selection.GetSelected().empty()) {
            auto obj = m_selection.GetSelected().front();
            m_drag.objectId = obj->GetId();
            m_drag.originalBounds = obj->GetBounds();
            m_drag.originalRotation = obj->GetRotation();
            
            auto annotObj = std::dynamic_pointer_cast<AnnotationSelectableObject>(obj);
            if (annotObj && annotObj->GetAnnotation()->GetType() == pdf_engine::AnnotationType::Line) {
                if (annotObj->GetAnnotation()->GetLineGeometry(m_drag.originalLineGeometry)) {
                    m_drag.hasOriginalLineGeometry = true;
                }
            }
        }
        return HitResult::Handle;
    }

    double px = 0, py = 0;
    int pageIndex = -1;
    if (viewToPage) viewToPage(x, y, px, py, pageIndex);
    
    auto hitObj = HitTestObjects(px, py, pageIndex);
    if (hitObj) {
        if (shiftPressed) {
            m_selection.ToggleSelect(hitObj);
        } else {
            if (!m_selection.IsSelected(hitObj->GetId())) {
                m_selection.Select(hitObj);
            }
            m_drag.active = true;
            m_drag.handle = HandleType::None;
            m_drag.startX = x;
            m_drag.startY = y;
            m_drag.hasOriginalLineGeometry = false;
            m_drag.objectId = hitObj->GetId();
            m_drag.originalBounds = hitObj->GetBounds();
            
            auto annotObj = std::dynamic_pointer_cast<AnnotationSelectableObject>(hitObj);
            if (annotObj && annotObj->GetAnnotation()->GetType() == pdf_engine::AnnotationType::Line) {
                if (annotObj->GetAnnotation()->GetLineGeometry(m_drag.originalLineGeometry)) {
                    m_drag.hasOriginalLineGeometry = true;
                }
            }
        }
        if (invalidateView) invalidateView();
        return HitResult::Object;
    }

    return HitResult::None;
}

void InteractionManager::StartMarquee(double x, double y, bool shiftPressed) {
    if (!shiftPressed) {
        m_selection.Clear();
    }
    m_drag.active = true;
    m_drag.isMarquee = true;
    m_drag.handle = HandleType::None;
    m_drag.startX = x;
    m_drag.startY = y;
    m_drag.marqueeRect = D2D1::RectF((float)x, (float)y, (float)x, (float)y);
    if (invalidateView) invalidateView();
}

bool InteractionManager::OnMouseMove(double x, double y) {
    if (m_isEditingText) {
        // Pass mouse move to editor
        // We'll need coordinates mapped to editor bounds? 
        // For now not strictly needed unless selecting text
    }

    if (m_drag.active) {
        if (m_drag.isMarquee) {
            m_drag.marqueeRect.left = (float)std::min(m_drag.startX, x);
            m_drag.marqueeRect.right = (float)std::max(m_drag.startX, x);
            m_drag.marqueeRect.top = (float)std::min(m_drag.startY, y);
            m_drag.marqueeRect.bottom = (float)std::max(m_drag.startY, y);
        } else {
            UpdateDrag(x, y);
        }
        if (invalidateView) invalidateView();
        return true;
    }
    
    // Hover logic could go here
    auto handle = HitTestHandles(x, y, 1.0f);
    if (handle != m_hoverHandle) {
        m_hoverHandle = handle;
        if (invalidateView) invalidateView();
        return true;
    }
    
    return false;
}

void InteractionManager::UpdateDrag(double x, double y) {
    if (m_drag.objectId.empty()) return;
    auto it = std::find_if(m_selection.GetSelected().begin(), m_selection.GetSelected().end(), 
        [&](auto& o) { return o->GetId() == m_drag.objectId; });
    if (it == m_selection.GetSelected().end()) return;
    auto obj = *it;

    double dx = x - m_drag.startX; (void)dx;
    double dy = y - m_drag.startY; (void)dy;

    double dpx = 0, dpy = 0;
    // We need to convert view delta to page delta
    if (viewToPage) {
        double px1, py1, px2, py2;
        int pageIndex;
        viewToPage(m_drag.startX, m_drag.startY, px1, py1, pageIndex);
        viewToPage(x, y, px2, py2, pageIndex);
        dpx = px2 - px1;
        dpy = py2 - py1;
    }

    auto annotObj = std::dynamic_pointer_cast<AnnotationSelectableObject>(obj);

    Rect newBounds = m_drag.originalBounds;

    if (m_drag.handle == HandleType::None) { // Move
        newBounds.left += (float)dpx;
        newBounds.right += (float)dpx;
        newBounds.top += (float)dpy;
        newBounds.bottom += (float)dpy;
    } else if (m_drag.handle == HandleType::Rotation) {
        obj->SetRotation(m_drag.originalRotation + dpx); 
        return;
    } else {
        if (m_drag.handle == HandleType::Right || m_drag.handle == HandleType::TopRight || m_drag.handle == HandleType::BottomRight) {
            newBounds.right += (float)dpx;
        }
        if (m_drag.handle == HandleType::Left || m_drag.handle == HandleType::TopLeft || m_drag.handle == HandleType::BottomLeft) {
            newBounds.left += (float)dpx;
        }
        if (m_drag.handle == HandleType::Bottom || m_drag.handle == HandleType::BottomLeft || m_drag.handle == HandleType::BottomRight) {
            newBounds.bottom += (float)dpy;
        }
        if (m_drag.handle == HandleType::Top || m_drag.handle == HandleType::TopLeft || m_drag.handle == HandleType::TopRight) {
            newBounds.top += (float)dpy;
        }
    }
    
    // Applying to lines
    if (annotObj && annotObj->GetAnnotation()->GetType() == pdf_engine::AnnotationType::Line) {
        if (m_drag.hasOriginalLineGeometry) {
            pdf_engine::LineGeometry geom = m_drag.originalLineGeometry;
            
            if (m_drag.handle == HandleType::None) {
                geom.start.x += (float)dpx;
                geom.start.y += (float)dpy;
                geom.end.x += (float)dpx;
                geom.end.y += (float)dpy;
            } else if (m_drag.handle == HandleType::TopLeft) { // Start point
                geom.start.x += (float)dpx;
                geom.start.y += (float)dpy;
            } else if (m_drag.handle == HandleType::BottomRight) { // End point
                geom.end.x += (float)dpx;
                geom.end.y += (float)dpy;
            }
            annotObj->GetAnnotation()->SetLineGeometry(geom);
        }
    }
    
    obj->SetBounds(newBounds);
}

bool InteractionManager::OnLButtonUp(double x, double y) {
    (void)x;
    (void)y;
    if (m_drag.active) {
        if (m_drag.isMarquee) {
            // Check intersection
            for (auto& obj : m_objects) {
                D2D1_RECT_F b = GetObjectBoundsInView(*obj);
                if (b.right >= m_drag.marqueeRect.left && b.left <= m_drag.marqueeRect.right &&
                    b.bottom >= m_drag.marqueeRect.top && b.top <= m_drag.marqueeRect.bottom) {
                    m_selection.AddSelect(obj);
                }
            }
        } else if (!m_drag.objectId.empty()) {
            if (onObjectCommitted) {
                auto it = std::find_if(m_objects.begin(), m_objects.end(), [&](auto& obj) { return obj->GetId() == m_drag.objectId; });
                if (it != m_objects.end()) {
                    onObjectCommitted(*it, m_drag.originalBounds, (*it)->GetBounds(), m_drag.hasOriginalLineGeometry, m_drag.originalLineGeometry);
                }
            }
        }
        m_drag.active = false;
        m_drag.isMarquee = false;
        m_drag.hasOriginalLineGeometry = false;
        if (invalidateView) invalidateView();
        return true;
    }
    return false;
}

bool InteractionManager::OnKeyDown(WPARAM wParam, bool shiftPressed, bool ctrlPressed) {
    if (m_isEditingText) {
        if (wParam == VK_ESCAPE) {
            CancelTextEdit();
            return true;
        }
        if (wParam == VK_RETURN && !shiftPressed) {
            CommitTextEdit();
            return true;
        }
        bool handled = m_textEditor.OnKeyDown(wParam, shiftPressed, ctrlPressed);
        if (handled && invalidateView) invalidateView();
        return handled;
    }

    if (wParam == VK_ESCAPE) {
        m_selection.Clear();
        if (invalidateView) invalidateView();
        return true;
    }
    if (wParam == VK_DELETE) {
        if (onDeleteRequested) {
            onDeleteRequested(m_selection.GetSelected());
        }
        m_selection.Clear();
        if (invalidateView) invalidateView();
        return true;
    }
    // Arrow keys for movement
    if (wParam == VK_LEFT || wParam == VK_RIGHT || wParam == VK_UP || wParam == VK_DOWN) {
        if (!m_selection.GetSelected().empty()) {
            double dpx = 0, dpy = 0;
            double amount = shiftPressed ? 10.0 : 1.0;
            if (wParam == VK_LEFT) dpx = -amount;
            if (wParam == VK_RIGHT) dpx = amount;
            if (wParam == VK_UP) dpy = -amount;
            if (wParam == VK_DOWN) dpy = amount;
            
            for (auto& obj : m_selection.GetSelected()) {
                Rect b = obj->GetBounds();
                b.left += dpx; b.right += dpx;
                b.top += dpy; b.bottom += dpy;
                obj->SetBounds(b);
                
                auto annotObj = std::dynamic_pointer_cast<AnnotationSelectableObject>(obj);
                if (annotObj && annotObj->GetAnnotation()->GetType() == pdf_engine::AnnotationType::Line) {
                    pdf_engine::LineGeometry geom;
                    if (annotObj->GetAnnotation()->GetLineGeometry(geom)) {
                        geom.start.x += (float)dpx; geom.start.y += (float)dpy;
                        geom.end.x += (float)dpx; geom.end.y += (float)dpy;
                        annotObj->GetAnnotation()->SetLineGeometry(geom);
                    }
                }
            }
            if (invalidateView) invalidateView();
            return true;
        }
    }
    return false;
}

bool InteractionManager::OnChar(WPARAM wParam) {
    if (m_isEditingText) {
        bool handled = m_textEditor.OnChar(wParam);
        if (handled && invalidateView) invalidateView();
        return handled;
    }
    return false;
}

void InteractionManager::Render(ID2D1RenderTarget* renderTarget, float scale) {
    ID2D1SolidColorBrush* brush = nullptr;
    ID2D1SolidColorBrush* fillBrush = nullptr;
    renderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.5f, 1.0f, 1.0f), &brush);
    renderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.5f, 1.0f, 0.2f), &fillBrush);

    ID2D1SolidColorBrush* handleBrush = nullptr;
    renderTarget->CreateSolidColorBrush(D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f), &handleBrush);
    ID2D1SolidColorBrush* strokeBrush = nullptr;
    renderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.5f, 1.0f, 1.0f), &strokeBrush);

    for (auto& obj : m_selection.GetSelected()) {
        auto annotObj = std::dynamic_pointer_cast<AnnotationSelectableObject>(obj);
        bool isLine = annotObj && annotObj->GetAnnotation()->GetType() == pdf_engine::AnnotationType::Line;
        
        if (isLine) {
            pdf_engine::LineGeometry geom;
            if (annotObj->GetAnnotation()->GetLineGeometry(geom)) {
                if (pageToView) {
                    double startVX, startVY, endVX, endVY;
                    pageToView(geom.start.x, geom.start.y, obj->GetPageIndex(), startVX, startVY);
                    pageToView(geom.end.x, geom.end.y, obj->GetPageIndex(), endVX, endVY);
                    
                    // Only draw handles
                    float hs = 4.0f / scale;
                    D2D1_RECT_F startHandle = { static_cast<float>(startVX) - hs, static_cast<float>(startVY) - hs, static_cast<float>(startVX) + hs, static_cast<float>(startVY) + hs };
                    D2D1_RECT_F endHandle = { static_cast<float>(endVX) - hs, static_cast<float>(endVY) - hs, static_cast<float>(endVX) + hs, static_cast<float>(endVY) + hs };
                    
                    renderTarget->FillRectangle(startHandle, handleBrush);
                    renderTarget->DrawRectangle(startHandle, strokeBrush, 1.0f / scale);
                    
                    renderTarget->FillRectangle(endHandle, handleBrush);
                    renderTarget->DrawRectangle(endHandle, strokeBrush, 1.0f / scale);
                }
            }
        } else {
            D2D1_RECT_F b = GetObjectBoundsInView(*obj);
            renderTarget->DrawRectangle(b, brush, 1.0f / scale);
            bool isActive = (m_drag.active && m_drag.objectId == obj->GetId());
            DrawHandles(renderTarget, b, scale, false, isActive);
        }
    }

    if (m_isEditingText) {
        m_textEditor.SetBounds(GetObjectBoundsInView(*m_editingTextObj));
        m_textEditor.Render(renderTarget);
    }

    if (m_drag.active && m_drag.isMarquee) {
        renderTarget->FillRectangle(m_drag.marqueeRect, fillBrush);
        renderTarget->DrawRectangle(m_drag.marqueeRect, brush, 1.0f / scale);
    }

    if (brush) brush->Release();
    if (fillBrush) fillBrush->Release();
    if (handleBrush) handleBrush->Release();
    if (strokeBrush) strokeBrush->Release();
}

void InteractionManager::DrawHandles(ID2D1RenderTarget* renderTarget, const D2D1_RECT_F& rect, float scale, bool rotatable, bool isActive) {
    (void)isActive;
    ID2D1SolidColorBrush* handleBrush = nullptr;
    renderTarget->CreateSolidColorBrush(D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f), &handleBrush);
    ID2D1SolidColorBrush* strokeBrush = nullptr;
    renderTarget->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.5f, 1.0f, 1.0f), &strokeBrush);

    D2D1_RECT_F rects[9];
    GetHandleRects(rect, scale, rects);

    int count = rotatable ? 9 : 8;
    for (int i = 0; i < count; ++i) {
        renderTarget->FillRectangle(rects[i], handleBrush);
        renderTarget->DrawRectangle(rects[i], strokeBrush, 1.0f / scale);
    }

    if (rotatable) {
        // Draw line connecting rotation handle
        D2D1_POINT_2F p1 = { (rect.left + rect.right) / 2.0f, rect.top };
        D2D1_POINT_2F p2 = { (rect.left + rect.right) / 2.0f, rects[8].bottom };
        renderTarget->DrawLine(p1, p2, strokeBrush, 1.0f / scale);
    }

    if (handleBrush) handleBrush->Release();
    if (strokeBrush) strokeBrush->Release();
}

} // namespace interaction
} // namespace ui

namespace ui {
namespace interaction {
HCURSOR InteractionManager::GetCursor() const {
    if (m_isEditingText) {
        return LoadCursor(nullptr, IDC_IBEAM);
    }
    if (m_hoverHandle != HandleType::None || m_drag.active) {
        HandleType ht = m_drag.active ? m_drag.handle : m_hoverHandle;
        switch (ht) {
            case HandleType::TopLeft:
            case HandleType::BottomRight:
                return LoadCursor(nullptr, IDC_SIZENWSE);
            case HandleType::TopRight:
            case HandleType::BottomLeft:
                return LoadCursor(nullptr, IDC_SIZENESW);
            case HandleType::Top:
            case HandleType::Bottom:
                return LoadCursor(nullptr, IDC_SIZENS);
            case HandleType::Left:
            case HandleType::Right:
                return LoadCursor(nullptr, IDC_SIZEWE);
            case HandleType::Rotation:
                return LoadCursor(nullptr, IDC_SIZEALL);
            default: break;
        }
    }
    return nullptr;
}



}
}


