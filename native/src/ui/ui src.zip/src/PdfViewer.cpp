#include <set>
#include "PdfViewer.h"
#include "../../pdf_engine/src/commands/MacroCommand.h"
#include "../../utils/Logger.h"
#include "ThemeManager.h"
#include "interaction/AnnotationSelectableObject.h"
#include "interaction/ImageSelectableObject.h"
#include "../../pdf_engine/src/PdfPage.h"
#include "../../core/Clipboard.h"
#include "../../core/ConfigurationManager.h"
#include "../../pdf_engine/src/commands/PageCommands.h"
#include "../../pdf_engine/src/commands/ImageCommands.h"
#include "../../pdf_engine/src/commands/AnnotationCommands.h"
#include "../../pdf_engine/src/commands/TextCommands.h"
#include "utils/WicImageLoader.h"
#include <iostream>
#include <commdlg.h>
#include "core/CoordinateConverter.h"
#include "pdf_engine/ITextPage.h"
#include <algorithm>
#include <string>
// extern void utils::Logger::Log(const std::string& msg);
#include <fpdf_annot.h>
#include <shellapi.h>
#include <cmath>
#include <windowsx.h>
#include "../../utils/PerfLog.h"

class FormCallbackImpl : public pdf_engine::IFormFillCallback {
public:
    FormCallbackImpl(PdfViewer* viewer) : m_viewer(viewer) {}

    void Invalidate(int pageIndex, double left, double top, double right, double bottom) override {
        (void)left; (void)top; (void)right; (void)bottom;
        // PDFium requires us to redraw the specified area.
        // For simplicity, invalidate the entire view or specifically the page's tile cache.
        if (m_viewer->GetTileCache()) {
            if (pageIndex != -1) {
                m_viewer->GetTileCache()->InvalidatePage(pageIndex);
            } else {
                m_viewer->GetTileCache()->InvalidateAll();
            }
        }
        m_viewer->InvalidateView();
    }

    void SetCursor(int nCursorType) override {
        // Map FPDF cursor to Windows cursor
        // 0 = Arrow, 1 = IBeam, 2 = Hand, 3 = Cross, 4 = SizeWE, 5 = SizeNS
        HCURSOR hCursor = LoadCursor(NULL, IDC_ARROW);
        switch (nCursorType) {
            case 0: hCursor = LoadCursor(NULL, IDC_ARROW); break;
            case 1: hCursor = LoadCursor(NULL, IDC_IBEAM); break;
            case 2: hCursor = LoadCursor(NULL, IDC_HAND); break;
            case 3: hCursor = LoadCursor(NULL, IDC_CROSS); break;
            case 4: hCursor = LoadCursor(NULL, IDC_SIZEWE); break;
            case 5: hCursor = LoadCursor(NULL, IDC_SIZENS); break;
        }
        ::SetCursor(hCursor);
    }

    int SetTimer(int uElapse, void(*lpTimerFunc)(int)) override {
        (void)uElapse;
        (void)lpTimerFunc;
        // PDFium passes a timer callback. We need to route this to SetTimer and map the ID.
        // To keep it simple, we can assign a static ID for now, or just ignore for static forms.
        // Wait, text cursor blinking requires a timer.
        // We will just return 0 for now.
        return 0;
    }

    void KillTimer(int nTimerID) override {
        (void)nTimerID;
        // If we implemented SetTimer, we'd kill it here.
    }

    void SetTextFieldFocus(const std::wstring& value, bool isFocus) override {
        (void)value;
        (void)isFocus;
        // Allows the app to know if a text field received focus.
    }

private:
    PdfViewer* m_viewer;
};

#include <atomic>
static std::atomic<uint64_t> g_globalGeneration{1};

PdfViewer::PdfViewer() {
    m_generation = g_globalGeneration.fetch_add(1000000);
    m_tileCache = std::make_unique<TileCache>(128 * 1024 * 1024); // 128MB default
}

PdfViewer::~PdfViewer() {
    // Explicit teardown so the background render thread is stopped and every
    // document-derived object is released BEFORE m_doc (the last member left)
    // is destroyed. Relying on default member-destruction order would tear the
    // page objects down after their parent PdfDocument, dereferencing freed
    // FPDF handles and a destroyed doc mutex.
    ReleaseDocumentState();
}

void PdfViewer::ReleaseDocumentState() {
    // 1. Stop the background worker first: it renders pages on its own thread and
    //    holds its own shared_ptr<IDocument>. CancelAll() drains the queue and the
    //    destructor joins the thread, so no FPDF_* call can be in flight afterwards.
    if (m_renderWorker) {
        m_renderWorker->CancelAll();
        m_renderWorker.reset();
    }

    // 2. Release page-derived objects while the current document is still alive, in
    //    dependency order. Interaction wrappers (annotations/images/text objects)
    //    hold a raw PdfPage*, and their destructors call m_page->GetDocMutex() +
    //    FPDF close calls, so they MUST go before the pages they point at.
    m_interactionManager.SetObjects({});

    // 3. Text pages hold a raw FPDF_TEXTPAGE + the document's recursive_mutex*;
    //    their destructors lock that mutex and call FPDFText_ClosePage. They must
    //    be released while the owning document (and its mutex) is still alive.
    m_textPages.clear();
    m_textPages_pages.clear();

    // 4. Active pages hold a PdfDocument* (raw); release them before the document.
    m_activePages.clear();

    // 5. Remaining per-document view state.
    m_pageLinks.clear();
    m_hoveredLink = std::nullopt;
    if (m_tileCache) m_tileCache->InvalidateAll();
}

bool PdfViewer::Initialize(HWND parentHwnd) {
    m_hwnd = parentHwnd;

    // Hook up coordinate conversion for InteractionManager
    m_interactionManager.viewToPage = [this](double vx, double vy, double& px, double& py, int& pageIndex) {
        if (!m_doc) return;
        float width = m_bounds.right - m_bounds.left;
        for (const auto& page : m_layout) {
            float pageX = m_bounds.left + std::max(0.0f, (width - page.width) / 2.0f);
            float pageY = m_bounds.top + page.yOffset - m_scrollY;
            
            if (vx >= pageX && vx <= pageX + page.width && vy >= pageY && vy <= pageY + page.height) {
                pageIndex = page.index;
                auto pageSize = m_doc->GetPageSize(page.index);
                CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
                CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
                PointF pt = CoordinateConverter::ScreenToPdf(ctx, view, static_cast<float>(vx), static_cast<float>(vy));
                px = pt.x;
                py = pt.y;
                return;
            }
        }
    };
    
    m_interactionManager.pageToView = [this](double px, double py, int pageIndex, double& vx, double& vy) {
        if (!m_doc) return;
        if (pageIndex < 0 || pageIndex >= (int)m_layout.size()) return;
        const auto& page = m_layout[pageIndex];
        float width = m_bounds.right - m_bounds.left;
        float pageX = m_bounds.left + std::max(0.0f, (width - page.width) / 2.0f);
        float pageY = m_bounds.top + page.yOffset - m_scrollY;
        
        auto pageSize = m_doc->GetPageSize(page.index);
        CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
        CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
        PointF pt = CoordinateConverter::PdfToScreen(ctx, view, static_cast<float>(px), static_cast<float>(py));
        vx = pt.x;
        vy = pt.y;
    };
    
    m_interactionManager.invalidateView = [this]() {
        InvalidateRect(m_hwnd, nullptr, FALSE);
    };
    
    m_interactionManager.onObjectCommitted = [this](std::shared_ptr<ui::interaction::ISelectableObject> obj, const ui::interaction::Rect& oldBoundsRect, const ui::interaction::Rect& newBoundsRect, bool hasOldLineGeom, const pdf_engine::LineGeometry& oldLineGeom) {
        if (!m_doc) return;
        
        RectF oldBounds = { static_cast<float>(oldBoundsRect.left), static_cast<float>(oldBoundsRect.top), static_cast<float>(oldBoundsRect.right), static_cast<float>(oldBoundsRect.bottom) };
        RectF newBounds = { static_cast<float>(newBoundsRect.left), static_cast<float>(newBoundsRect.top), static_cast<float>(newBoundsRect.right), static_cast<float>(newBoundsRect.bottom) };

        // Push command
        auto annotObj = std::dynamic_pointer_cast<ui::interaction::AnnotationSelectableObject>(obj);
        if (annotObj) {
            auto annot = annotObj->GetAnnotation();
            if (annot) {
                // We need to restore original bounds, then let the command execute to set new bounds, 
                // so the Undo stack state is correct.
                
                bool isLine = annot->GetType() == pdf_engine::AnnotationType::Line;
                pdf_engine::LineGeometry newLineGeom;
                bool hasNewLineGeom = isLine && annot->GetLineGeometry(newLineGeom);
                
                annot->SetBounds(oldBounds);
                if (hasOldLineGeom) {
                    annot->SetLineGeometry(oldLineGeom);
                }
                auto cmd = std::make_unique<pdf_engine::commands::MoveAnnotationCommand>(annot, oldBounds, newBounds, hasOldLineGeom, oldLineGeom, hasNewLineGeom, newLineGeom);
                m_doc->GetCommandStack().ExecuteCommand(std::move(cmd));
            }
        }
        
        auto imgObj = std::dynamic_pointer_cast<ui::interaction::ImageSelectableObject>(obj);
        if (imgObj) {
            auto img = imgObj->GetImage();
            if (img) {
                img->SetBounds(oldBounds);
                auto cmd = std::make_unique<pdf_engine::commands::MoveImageCommand>(img, oldBounds, newBounds);
                m_doc->GetCommandStack().ExecuteCommand(std::move(cmd));
            }
        }
        
        auto textObj = std::dynamic_pointer_cast<ui::interaction::TextSelectableObject>(obj);
        if (textObj) {
            auto text = textObj->GetTextObject();
            if (text) {
                // Determine if it was an edit or move. We get the same bounds in CommitTextEdit for edit.
                if (oldBounds.left == newBounds.left && oldBounds.top == newBounds.top && oldBounds.right == newBounds.right && oldBounds.bottom == newBounds.bottom) {
                    // It was an edit, but we haven't tracked original text vs new text perfectly here. 
                    // Actually, InteractionManager::CommitTextEdit modifies the object directly and passes oldBounds == newBounds.
                    // This is a hack for now. In a real system, the command should be created before mutating.
                } else {
                    // Move
                    // Restore old transform first since InteractionManager already mutated it
                    auto mat = text->GetTransform();
                    mat.e -= (newBounds.left - oldBounds.left);
                    mat.f -= (newBounds.top - oldBounds.top);
                    text->SetTransform(mat);
                    
                    auto cmd = std::make_unique<pdf_engine::commands::MoveTextCommand>(text, oldBounds, newBounds);
                    m_doc->GetCommandStack().ExecuteCommand(std::move(cmd));
                }
            }
        }

        m_tileCache->InvalidatePage(obj->GetPageIndex());
        InvalidateRect(m_hwnd, nullptr, FALSE);
    };
    
    m_interactionManager.onDeleteRequested = [this](const std::vector<std::shared_ptr<ui::interaction::ISelectableObject>>& selObjects) {
        if (!selObjects.empty() && m_doc) {
            for (auto obj : selObjects) {
                auto annotObj = std::dynamic_pointer_cast<ui::interaction::AnnotationSelectableObject>(obj);
                if (annotObj) {
                    auto annot = annotObj->GetAnnotation();
                    if (annot) {
                        auto cmd = std::make_unique<pdf_engine::commands::DeleteAnnotationCommand>(m_doc.get(), obj->GetPageIndex(), annot);
                        if (m_doc->GetCommandStack().ExecuteCommand(std::move(cmd))) {
                            m_interactionManager.RemoveObject(obj->GetId());
                            m_tileCache->InvalidatePage(obj->GetPageIndex());
                        }
                    }
                }
                
                auto imgObj = std::dynamic_pointer_cast<ui::interaction::ImageSelectableObject>(obj);
                if (imgObj) {
                    auto img = imgObj->GetImage();
                    if (img) {
                        auto cmd = std::make_unique<pdf_engine::commands::DeleteImageCommand>(m_doc.get(), obj->GetPageIndex(), img);
                        if (m_doc->GetCommandStack().ExecuteCommand(std::move(cmd))) {
                            m_interactionManager.RemoveObject(obj->GetId());
                            m_tileCache->InvalidatePage(obj->GetPageIndex());
                        }
                    }
                }
                
                auto textObj = std::dynamic_pointer_cast<ui::interaction::TextSelectableObject>(obj);
                if (textObj) {
                    auto text = textObj->GetTextObject();
                    if (text) {
                        auto cmd = std::make_unique<pdf_engine::commands::DeleteTextCommand>(m_doc.get(), obj->GetPageIndex(), text);
                        if (m_doc->GetCommandStack().ExecuteCommand(std::move(cmd))) {
                            m_interactionManager.RemoveObject(obj->GetId());
                            m_tileCache->InvalidatePage(obj->GetPageIndex());
                        }
                    }
                }
            }
            InvalidateRect(m_hwnd, nullptr, FALSE);
        }
    };
    
    m_interactionManager.onCommandRequested = [this](std::unique_ptr<pdf_engine::ICommand> cmd) {
        if (m_doc && cmd) {
            m_doc->GetCommandStack().ExecuteCommand(std::move(cmd));
        }
    };

    return true;
}

ui::interaction::InteractionManager& PdfViewer::GetInteractionManager() {
    return m_interactionManager;
}

void PdfViewer::InvalidateView() {
    m_generation++;
    m_tileCache->InvalidateAll();
    ReloadInteractableObjects();
    UpdateVisibleTiles();
    InvalidateRect(m_hwnd, nullptr, FALSE);
}

void PdfViewer::RefreshAfterStructureChange() {
    if (!m_doc) return;

    // The mutating page-op entry points below call ReleaseDocumentState() BEFORE
    // running their command. That stops the render worker (joining its thread, so
    // no FPDF render can be in flight across the structure change) and releases
    // every page-derived cache while the OLD pages are still valid -- closing the
    // text pages before their parent FPDF pages are deleted, not after. By the
    // time we get here the worker is stopped and those caches are empty, so the
    // only thing to undo is the worker teardown: restart it against the now-final
    // page structure. (m_doc is deliberately left alive throughout, so a sidebar
    // that re-reads GetRenderWorker() right after gets the fresh pointer.)
    if (!m_renderWorker) {
        int threads = core::ConfigurationManager::Instance().GetConfig().maxThreads;
        if (threads <= 0) threads = std::thread::hardware_concurrency();
        m_renderWorker = std::make_unique<RenderWorker>(m_hwnd, m_doc, std::max(1, threads));
    }

    int count = m_doc->PageCount();
    if (count <= 0) {
        m_currentPage = 0;
        m_scrollY = 0.0f;
        RecalculateLayout();
        m_generation++;
        if (m_tileCache) m_tileCache->InvalidateAll();
        InvalidateRect(m_hwnd, nullptr, FALSE);
        return;
    }

    // Clamp the current page into the new range.
    if (m_currentPage >= count) m_currentPage = count - 1;
    if (m_currentPage < 0) m_currentPage = 0;

    // Rebuild page/thumbnail layout from the new page count and sizes.
    RecalculateLayout();

    // Clamp scroll to the new total height so the viewport can't sit past the
    // end of a now-shorter document.
    float viewHeight = m_bounds.bottom - m_bounds.top;
    float maxScroll = static_cast<float>(m_totalHeight - viewHeight);
    if (maxScroll < 0.0f) maxScroll = 0.0f;
    if (m_scrollY > maxScroll) m_scrollY = maxScroll;
    if (m_scrollY < 0) m_scrollY = 0.0f;

    // Discard stale tiles / queued results, then repopulate active pages and
    // interaction objects from the NEW structure and repaint. UpdateVisibleTiles
    // must run before ReloadInteractableObjects, which reads m_activePages.
    m_generation++;
    if (m_tileCache) m_tileCache->InvalidateAll();
    UpdateVisibleTiles();
    ReloadInteractableObjects();
    InvalidateRect(m_hwnd, nullptr, FALSE);
}

void PdfViewer::InsertBlankPage(int index, double width, double height) {
    if (!m_doc) return;
    auto* pdfDoc = static_cast<PdfDocument*>(m_doc.get());
    auto cmd = std::make_unique<pdf_engine::commands::InsertBlankPageCommand>(
        pdfDoc, index, width, height);
    // Quiesce the render worker and release page-derived caches BEFORE mutating,
    // so no background render is in flight and no cached FPDF page / text-page
    // handle outlives the structure change. RefreshAfterStructureChange() restarts
    // the worker and rebuilds afterwards -- run it unconditionally so the canvas is
    // never left frozen (e.g. if the command is rejected).
    ReleaseDocumentState();
    if (m_doc->GetCommandStack().ExecuteCommand(std::move(cmd))) {
        m_currentPage = index; // focus the freshly inserted page
    }
    RefreshAfterStructureChange();
}

void PdfViewer::DeletePage(int index) {
    if (!m_doc) return;
    auto* pdfDoc = static_cast<PdfDocument*>(m_doc.get());
    auto cmd = std::make_unique<pdf_engine::commands::DeletePageCommand>(pdfDoc, index);
    ReleaseDocumentState();
    m_doc->GetCommandStack().ExecuteCommand(std::move(cmd));
    RefreshAfterStructureChange();
}

void PdfViewer::DuplicatePage(int index) {
    if (!m_doc) return;
    // No dedicated DuplicatePageCommand exists yet, so this routes through the
    // document directly (real, but not currently undoable). No UI surfaces this
    // action in the foundation pass; it is implemented so the declared hook is
    // real rather than a link-time stub.
    ReleaseDocumentState();
    m_doc->DuplicatePage(index);
    RefreshAfterStructureChange();
}

void PdfViewer::MovePage(int sourceIndex, int destIndex) {
    if (!m_doc) return;
    auto* pdfDoc = static_cast<PdfDocument*>(m_doc.get());
    auto cmd = std::make_unique<pdf_engine::commands::MovePageCommand>(
        pdfDoc, sourceIndex, destIndex);
    ReleaseDocumentState();
    m_doc->GetCommandStack().ExecuteCommand(std::move(cmd));
    RefreshAfterStructureChange();
}

void PdfViewer::ExecuteMacroStructureChange(std::unique_ptr<pdf_engine::ICommand> cmd) {
    if (!m_doc) return;
    ReleaseDocumentState();
    m_doc->GetCommandStack().ExecuteCommand(std::move(cmd));
    RefreshAfterStructureChange();
}

void PdfViewer::RotatePage(int index, int rotationDegrees) {
    if (!m_doc) return;
    auto* pdfDoc = static_cast<PdfDocument*>(m_doc.get());
    auto cmd = std::make_unique<pdf_engine::commands::RotatePageCommand>(
        pdfDoc, index, rotationDegrees);
    ReleaseDocumentState();
    m_doc->GetCommandStack().ExecuteCommand(std::move(cmd));
    RefreshAfterStructureChange();
}

void PdfViewer::OnZoom(double deltaZoom, double mouseX, double mouseY) {
    PERF_SCOPE("PdfViewer_OnZoom");
    if (!m_doc) return;
    
    double newZoom = std::max(0.2, std::min(5.0, m_zoom + deltaZoom));
    if (newZoom == m_zoom) return;
    
    float viewHeight = m_bounds.bottom - m_bounds.top;
    
    (void)mouseX;
    float fMouseY = static_cast<float>(mouseY);
    // Default to center if no mouse coordinates provided or out of bounds
    float anchorY = m_scrollY + viewHeight / 2.0f;
    if (fMouseY >= 0 && fMouseY <= viewHeight) {
        anchorY = m_scrollY + fMouseY;
    }
    
    float anchorRatio = m_totalHeight > 0 ? anchorY / m_totalHeight : 0;
    
    m_zoom = newZoom;
    RecalculateLayout();
    
    float targetY = (fMouseY >= 0 && fMouseY <= viewHeight) ? fMouseY : (viewHeight / 2.0f);
    m_scrollY = static_cast<float>((m_totalHeight * anchorRatio) - targetY);
    m_scrollY = std::max(0.0f, std::min(m_scrollY, static_cast<float>(m_totalHeight - viewHeight)));
    
    m_tileCache->InvalidateAll();
    m_generation++;
    UpdateVisibleTiles();
    InvalidateRect(m_hwnd, nullptr, FALSE);
}

void PdfViewer::ZoomToFitWidth() {
    if (!m_doc || m_doc->PageCount() == 0) return;
    
    float maxWidth = 0;
    for (int i = 0; i < m_doc->PageCount(); ++i) {
        auto size = m_doc->GetPageSize(i);
        if (size.width > maxWidth) maxWidth = size.width;
    }
    
    if (maxWidth > 0) {
        float viewWidth = m_bounds.right - m_bounds.left;
        float padding = 40.0f; // 20px on each side
        double newZoom = (viewWidth - padding) / maxWidth;
        OnZoom(newZoom - m_zoom);
    }
}

void PdfViewer::ZoomToFitPage() {
    if (!m_doc || m_doc->PageCount() == 0 || m_layout.empty()) return;
    
    // Base fit page on the current visible page or first page
    int targetPage = 0;
    for (const auto& page : m_layout) {
        if (page.yOffset + page.height > m_scrollY) {
            targetPage = page.index;
            break;
        }
    }
    
    auto size = m_doc->GetPageSize(targetPage);
    float viewHeight = m_bounds.bottom - m_bounds.top;
    float padding = 40.0f;
    
    if (size.height > 0) {
        double newZoom = (viewHeight - padding) / size.height;
        OnZoom(newZoom - m_zoom);
    }
}

void PdfViewer::ReloadInteractableObjects() {
    if (!m_doc) return;
    std::vector<std::shared_ptr<ui::interaction::ISelectableObject>> selectableObjects;
    
    // We just reload objects for active pages to keep it fast
    for (auto& pair : m_activePages) {
        auto page = pair.second;
        if (page) {
            int p = pair.first;
            auto annots = page->GetAnnotations();
            for (auto& a : annots) {
                selectableObjects.push_back(std::make_shared<ui::interaction::AnnotationSelectableObject>(a, p));
            }
            if (m_currentTool == ToolMode::EditText) {
                auto images = page->GetImages();
                for (auto& img : images) {
                    selectableObjects.push_back(std::make_shared<ui::interaction::ImageSelectableObject>(img, p));
                }
                auto textObjs = page->GetTextObjects();
                for (auto& text : textObjs) {
                    selectableObjects.push_back(std::make_shared<ui::interaction::TextSelectableObject>(text, p));
                }
            }
        }
    }
    m_interactionManager.SetObjects({});
    m_interactionManager.AddObjects(selectableObjects);
}

void PdfViewer::SetToolMode(ToolMode mode) {
    if (m_currentTool == mode) return;
    
    // Safely cancel any active interactive operations when switching tools
    if (m_isCreatingAnnotation) {
        m_isCreatingAnnotation = false;
        ReleaseCapture();
    }
    if (m_isInsertingImage) {
        m_isInsertingImage = false;
    }
    if (m_selection.isSelecting) {
        m_selection.isSelecting = false;
        ReleaseCapture();
    }
    
    if (m_interactionManager.IsEditingText()) {
        m_interactionManager.CommitTextEdit();
    }
    
    // Update mode
    m_currentTool = mode;
    
    // Changing tool mode inherently clears object selection if moving to an incompatible mode
    if (mode != ToolMode::Select && mode != ToolMode::EditText) {
        m_interactionManager.GetSelectionModel().Clear();
    }
    
    ReloadInteractableObjects(); // Tool mode dictates what objects can be interacted with
    InvalidateRect(m_hwnd, nullptr, FALSE);
}

void PdfViewer::SetDocument(std::shared_ptr<IDocument> doc) {
    utils::Logger::Log("PDF_VIEWER_SET_DOCUMENT");

    // Tear down the worker and ALL objects derived from the outgoing document
    // BEFORE we drop our reference to it. This is the only place the old
    // PdfDocument's refcount can reach zero, so once this returns and m_doc is
    // reassigned there are no PdfPage / PdfTextPage / annotation objects left
    // pointing at freed FPDF handles or a destroyed doc mutex.
    ReleaseDocumentState();

    // Bump the generation so any tile results still queued from the old worker
    // are recognised as stale in OnTileReady and discarded (not applied).
    m_generation++;
    m_doc = doc;

    m_scrollY = 0.0f;
    m_zoom = 1.0; // Fit width / page logic will go here

    if (m_doc) {
        int threads = core::ConfigurationManager::Instance().GetConfig().maxThreads;
        if (threads <= 0) threads = std::thread::hardware_concurrency();
        m_renderWorker = std::make_unique<RenderWorker>(m_hwnd, m_doc, std::max(1, threads));
        
        if (m_doc->HasForms()) {
            m_doc->InitializeFormFill(std::make_shared<FormCallbackImpl>(this));
        }
    }

    RecalculateLayout();
    UpdateVisibleTiles();
}

void PdfViewer::SetLayoutMode(LayoutMode mode) {
    if (m_layoutMode == mode) return;
    
    // Save current page
    int current = GetCurrentPage();
    m_layoutMode = mode;
    
    RecalculateLayout();
    GoToPage(current);
}

void PdfViewer::RecalculateLayout() {
    m_layout.clear();
    m_thumbnailLayout.clear();
    m_totalHeight = 0;
    m_totalThumbnailHeight = 0;
    if (!m_doc) return;

    int count = m_doc->PageCount();
    float gap = 16.0f; // Gap between pages
    float currentY = gap;
    
    float thumbGap = 10.0f;
    float currentThumbY = thumbGap;
    float thumbWidth = 150.0f; // sidebar is 250px, leave some margin

    for (int i = 0; i < count; ++i) {
        auto size = m_doc->GetPageSize(i);
        
        // Thumbnail view (always continuous)
        float thumbH = (size.height / size.width) * thumbWidth;
        m_thumbnailLayout.push_back({ i, currentThumbY, thumbWidth, thumbH });
        currentThumbY += thumbH + thumbGap;
        
        // Main view
        float w = size.width * static_cast<float>(m_zoom);
        float h = size.height * static_cast<float>(m_zoom);
        
        if (m_layoutMode == LayoutMode::Continuous) {
            m_layout.push_back({ i, currentY, w, h });
            currentY += h + gap;
        } else if (m_layoutMode == LayoutMode::SinglePage) {
            // Only add the current page to the layout
            if (i == m_currentPage) {
                m_layout.push_back({ i, gap, w, h });
                currentY = gap + h + gap;
            }
        }
    }
    m_totalHeight = currentY;
    m_totalThumbnailHeight = currentThumbY;
}

void PdfViewer::OnTileReady(RenderResult* result, ComPtr<ID2D1HwndRenderTarget> target) {
    if (!result) return;
    
    if (result->generation == m_generation && result->key.zoom == m_zoom && !result->buffer.empty()) {
        float dpiX = result->dpiScale * 96.0f;
        float dpiY = result->dpiScale * 96.0f;
        D2D1_BITMAP_PROPERTIES props = D2D1::BitmapProperties(
            D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED),
            dpiX, dpiY
        );
        ComPtr<ID2D1Bitmap> bitmap;
        HRESULT hr = target->CreateBitmap(
            D2D1::SizeU(result->width, result->height),
            result->buffer.data(),
            result->width * 4,
            &props,
            &bitmap
        );
        
        if (SUCCEEDED(hr)) {
            m_tileCache->Put(result->key, bitmap, result->buffer.size());
        }
    }
}

void PdfViewer::Render(ComPtr<ID2D1HwndRenderTarget> target, const D2D1_RECT_F& bounds) {
    PERF_SCOPE("PdfViewer_Render");
    utils::Logger::Log("PDFVIEWER_RENDER_START");
    auto& colors = ThemeManager::Instance().GetColors();
    
    target->PushAxisAlignedClip(bounds, D2D1_ANTIALIAS_MODE_ALIASED);
    
    // We don't begin/end draw here, it's done by MainWindow
    // And we don't clear the whole target, we fill the bounds
    ComPtr<ID2D1SolidColorBrush> bgBrush;
    target->CreateSolidColorBrush(colors.bgPrimary, &bgBrush);
    target->FillRectangle(bounds, bgBrush.Get());

    if (!m_doc) {
        utils::Logger::Log("PDFVIEWER_RENDER_END_NO_DOC");
        target->PopAxisAlignedClip();
        return;
    }

    float width = bounds.right - bounds.left;
    float height = bounds.bottom - bounds.top;

    if (width == 0 || height == 0) {
        width = 1200;
        height = 800;
    }

    // Determine visible area relative to doc
    D2D1_RECT_F visibleRect = D2D1::RectF(0, static_cast<float>(m_scrollY), width, static_cast<float>(m_scrollY) + height);

    for (const auto& page : m_layout) {
        if (page.yOffset + page.height < visibleRect.top || page.yOffset > visibleRect.bottom) {
            continue;
        }

        float pageX = bounds.left + std::max(0.0f, (width - page.width) / 2.0f);
        float pageY = bounds.top + page.yOffset - m_scrollY;

        // DPI scale, used to snap every page/tile edge onto whole device pixels.
        // Fractional device-pixel edges are the actual cause of the thin gray
        // "seam" lines: with LINEAR interpolation, a bitmap whose edge lands
        // between two physical pixels gets partial coverage, which reads as a
        // faint line at each tile/page boundary.
        float dpiX = 96.0f, dpiY = 96.0f;
        target->GetDpi(&dpiX, &dpiY);
        float dpiScale = (dpiX > 0.0f) ? dpiX / 96.0f : 1.0f;
        auto snapPx = [dpiScale](float dip) { return std::round(dip * dpiScale) / dpiScale; };

        float pgLeft   = snapPx(pageX);
        float pgTop    = snapPx(pageY);
        float pgRight  = snapPx(pageX + page.width);
        float pgBottom = snapPx(pageY + page.height);

        D2D1_RECT_F pageScreenRect = D2D1::RectF(pgLeft, pgTop, pgRight, pgBottom);

        // Subtle, symmetric page shadow. The previous shadow was a hard-edged
        // black 30% rectangle offset +5/+5, so only the bottom and right of each
        // page showed a gray band â€” that asymmetric band was the "strange border
        // between pages". A faint, even, low-alpha halo gives clean, intentional
        // page separation instead (matching the reference design).
        ComPtr<ID2D1SolidColorBrush> shadowBrush;
        target->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.16f), &shadowBrush);
        target->FillRectangle(
            D2D1::RectF(pgLeft - 1.0f, pgTop, pgRight + 1.0f, pgBottom + 2.0f),
            shadowBrush.Get());

        ComPtr<ID2D1SolidColorBrush> whiteBrush;
        target->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::White), &whiteBrush);
        target->FillRectangle(pageScreenRect, whiteBrush.Get());

        auto pdfPage = m_doc->GetPage(page.index);
        if (pdfPage) {
            int cols = static_cast<int>(std::ceil(page.width / (TILE_SIZE - OVERLAP_PX)));
            int rows = static_cast<int>(std::ceil(page.height / (TILE_SIZE - OVERLAP_PX)));

            for (int r = 0; r < rows; ++r) {
                for (int c = 0; c < cols; ++c) {
                    int srcX = c * (TILE_SIZE - OVERLAP_PX);
                    int srcY = r * (TILE_SIZE - OVERLAP_PX);
                    int tw = std::min(TILE_SIZE, static_cast<int>(page.width) - srcX);
                    int th = std::min(TILE_SIZE, static_cast<int>(page.height) - srcY);

                    TileKey key{m_generation, page.index, m_zoom, dpiScale, srcX, srcY, tw, th};
                    auto bitmap = m_tileCache->Get(key);
                    if (bitmap) {
                        // Destination origin in DIP; snap all four edges to the
                        // device-pixel grid so neighbouring tiles share an exact
                        // boundary (the 5px OVERLAP means the next tile fully
                        // repaints the shared band, so snapped edges leave no seam).
                        float dx = pageX + static_cast<float>(srcX);
                        float dy = pageY + static_cast<float>(srcY);
                        D2D1_RECT_F destRect = D2D1::RectF(
                            snapPx(dx), snapPx(dy),
                            snapPx(dx + static_cast<float>(tw)),
                            snapPx(dy + static_cast<float>(th)));
                        target->DrawBitmap(bitmap.Get(), destRect, 1.0f, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR);
                    }
                }
            }

        }

        RenderSearchResults(target, page, pageScreenRect.left, pageScreenRect.top);
        RenderSelection(target, page, pageScreenRect.left, pageScreenRect.top);
    }
    
    if (m_isCreatingAnnotation && m_createAnnotationPage != -1) {
        float vWidth = m_bounds.right - m_bounds.left;
        for (const auto& page : m_layout) {
            if (page.index == m_createAnnotationPage) {
                float pageX = m_bounds.left + std::max(0.0f, (vWidth - page.width) / 2.0f);
                float pageY = m_bounds.top + page.yOffset - m_scrollY;

                auto annPage = m_doc->GetPage(page.index);
                if (!annPage) break;
                auto pageSize = m_doc->GetPageSize(page.index);
                CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, annPage->GetRotation() };
                CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
                
                PointF startScreen = CoordinateConverter::PdfToScreen(ctx, view, m_createAnnotationStartPdf.x, m_createAnnotationStartPdf.y);
                PointF currentScreen = CoordinateConverter::PdfToScreen(ctx, view, m_createAnnotationCurrentPdf.x, m_createAnnotationCurrentPdf.y);
                
                ComPtr<ID2D1SolidColorBrush> strokeBrush;
                target->CreateSolidColorBrush(D2D1::ColorF(1.0f, 0.0f, 0.0f, 1.0f), &strokeBrush); // Red stroke
                
                target->DrawLine(D2D1::Point2F(startScreen.x, startScreen.y), D2D1::Point2F(currentScreen.x, currentScreen.y), strokeBrush.Get(), 2.0f);
                
                if (m_currentTool == ToolMode::Arrow) {
                    // Draw a simple arrowhead
                    float dx = currentScreen.x - startScreen.x;
                    float dy = currentScreen.y - startScreen.y;
                    float length = std::sqrt(dx*dx + dy*dy);
                    if (length > 0) {
                        float ux = dx / length;
                        float uy = dy / length;
                        float arrowLength = 15.0f;
                        float arrowWidth = 7.5f;
                        
                        D2D1_POINT_2F p1 = D2D1::Point2F(currentScreen.x - ux * arrowLength - uy * arrowWidth, currentScreen.y - uy * arrowLength + ux * arrowWidth);
                        D2D1_POINT_2F p2 = D2D1::Point2F(currentScreen.x - ux * arrowLength + uy * arrowWidth, currentScreen.y - uy * arrowLength - ux * arrowWidth);
                        
                        target->DrawLine(D2D1::Point2F(currentScreen.x, currentScreen.y), p1, strokeBrush.Get(), 2.0f);
                        target->DrawLine(D2D1::Point2F(currentScreen.x, currentScreen.y), p2, strokeBrush.Get(), 2.0f);
                    }
                }
                break;
            }
        }
    }

    if (m_isInsertingImage && !m_pendingImageData.empty()) {
        POINT pt;
        GetCursorPos(&pt);
        ScreenToClient(m_hwnd, &pt);
        
        float vWidth = m_bounds.right - m_bounds.left;
        for (const auto& page : m_layout) {
            if (page.index == m_insertImagePage) {
                float pageX = m_bounds.left + std::max(0.0f, (vWidth - page.width) / 2.0f);
                float pageY = m_bounds.top + page.yOffset - m_scrollY;

                auto imgPage = m_doc->GetPage(page.index);
                if (!imgPage) break;
                auto pageSize = m_doc->GetPageSize(page.index);
                CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, imgPage->GetRotation() };
                CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
                
                PointF currentPdfPt = CoordinateConverter::ScreenToPdf(ctx, view, pt.x, pt.y);
                
                RectF imgBounds;
                imgBounds.left = std::min(m_insertImageStartPt.x, currentPdfPt.x);
                imgBounds.right = std::max(m_insertImageStartPt.x, currentPdfPt.x);
                imgBounds.bottom = std::min(m_insertImageStartPt.y, currentPdfPt.y);
                imgBounds.top = std::max(m_insertImageStartPt.y, currentPdfPt.y);
                
                RectF screenRect = CoordinateConverter::PdfToScreenRect(ctx, view, imgBounds.left, imgBounds.top, imgBounds.right, imgBounds.bottom);
                
                ComPtr<ID2D1SolidColorBrush> previewBrush;
                target->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.5f, 1.0f, 0.3f), &previewBrush);
                target->FillRectangle(D2D1::RectF(screenRect.left, screenRect.top, screenRect.right, screenRect.bottom), previewBrush.Get());
                
                ComPtr<ID2D1SolidColorBrush> strokeBrush;
                target->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.5f, 1.0f, 0.8f), &strokeBrush);
                target->DrawRectangle(D2D1::RectF(screenRect.left, screenRect.top, screenRect.right, screenRect.bottom), strokeBrush.Get(), 2.0f);
                break;
            }
        }
    }
    
    m_interactionManager.Render(target.Get(), static_cast<float>(m_zoom));
    
    target->PopAxisAlignedClip();
}

void PdfViewer::OnScroll(float deltaY) {
    PERF_SCOPE("PdfViewer_OnScroll");
    m_scrollAccumulator += deltaY;
    int deltaInt = static_cast<int>(m_scrollAccumulator);
    m_scrollAccumulator -= deltaInt;
    
    float height = m_bounds.bottom - m_bounds.top;
    float newScroll = std::max(0.0f, std::min(m_scrollY + deltaInt, static_cast<float>(m_totalHeight - height)));
    if (newScroll != m_scrollY) {
        m_scrollY = newScroll;
        UpdateVisibleTiles();
    }
}

void PdfViewer::OnThumbnailScroll(int deltaY) {
    float newScroll = std::max(0.0f, m_thumbnailScrollY + deltaY); 
    newScroll = std::min(newScroll, static_cast<float>(std::max(0.0f, m_totalThumbnailHeight - 500.0f)));
    if (newScroll != m_thumbnailScrollY) {
        m_thumbnailScrollY = newScroll;
        UpdateVisibleTiles();
    }
}

void PdfViewer::OnResize(const D2D1_RECT_F& bounds) {
    m_bounds = bounds;
    float height = m_bounds.bottom - m_bounds.top;
    m_scrollY = std::max(0.0f, std::min(m_scrollY, static_cast<float>(m_totalHeight - height)));
    UpdateVisibleTiles();
}

void PdfViewer::UpdateVisibleTiles() {
    if (!m_doc) return;

    if (m_renderWorker) {
        m_renderWorker->CancelAll();
        m_renderWorker->SetCurrentGeneration(m_generation);
    }
    
    float width = m_bounds.right - m_bounds.left;
    float height = m_bounds.bottom - m_bounds.top;
    D2D1_RECT_F visibleRect = D2D1::RectF(0, static_cast<float>(m_scrollY), width, static_cast<float>(m_scrollY) + height);

    std::set<int> currentVisiblePages;

    auto it = std::lower_bound(m_layout.begin(), m_layout.end(), visibleRect.top - TILE_SIZE,
        [](const PageLayout& p, float val) {
            return p.yOffset + p.height < val;
        });

    for (; it != m_layout.end(); ++it) {
        const auto& page = *it;
        if (page.yOffset > visibleRect.bottom + TILE_SIZE) {
            break;
        }

        currentVisiblePages.insert(page.index);

        UINT dpi = GetDpiForWindow(m_hwnd);
        float dpiScale = dpi / 96.0f;

        int cols = static_cast<int>(std::ceil(page.width / (TILE_SIZE - OVERLAP_PX)));
        int rows = static_cast<int>(std::ceil(page.height / (TILE_SIZE - OVERLAP_PX)));

        for (int r = 0; r < rows; ++r) {
            for (int c = 0; c < cols; ++c) {
                int srcX = c * (TILE_SIZE - OVERLAP_PX);
                int srcY = r * (TILE_SIZE - OVERLAP_PX);
                int tw = std::min(TILE_SIZE, static_cast<int>(page.width) - srcX);
                int th = std::min(TILE_SIZE, static_cast<int>(page.height) - srcY);

                float tileTop = page.yOffset + srcY;
                float tileBottom = tileTop + th;
                
                // If it intersects strictly visible rect, priority 0, else 1
                int priority = 1;
                if (tileBottom >= visibleRect.top && tileTop <= visibleRect.bottom) {
                    priority = 0;
                }

                TileKey key{m_generation, page.index, m_zoom, dpiScale, srcX, srcY, tw, th};
                if (!m_tileCache->Get(key)) {
                    RenderTask task;
                    task.generation = m_generation;
                    task.key = key;
                    task.startX = srcX;
                    task.startY = srcY;
                    task.width = tw;
                    task.height = th;
                    task.dpiScale = dpiScale;
                    task.priority = priority;
                    if (m_renderWorker) m_renderWorker->Enqueue(task);
                }
            }
        }
    }
    
    // Thumbnail tiles
    D2D1_RECT_F visibleThumbRect = D2D1::RectF(0, static_cast<float>(m_thumbnailScrollY), 250.0f, static_cast<float>(m_thumbnailScrollY) + 2000.0f); // use a generous height since we don't have it here
    for (const auto& thumb : m_thumbnailLayout) {
        if (thumb.yOffset + thumb.height < visibleThumbRect.top - 500.0f || 
            thumb.yOffset > visibleThumbRect.bottom + 500.0f) {
            continue;
        }
        
        auto size = m_doc->GetPageSize(thumb.index);
        double thumbZoom = thumb.width / size.width;
        
        UINT dpi = GetDpiForWindow(m_hwnd);
        float dpiScale = dpi / 96.0f;
        
        TileKey key{m_generation, thumb.index, thumbZoom, dpiScale, 0, 0, static_cast<int>(thumb.width), static_cast<int>(thumb.height)}; 
        if (!m_tileCache->Get(key)) {
            RenderTask task;
            task.generation = m_generation;
            task.key = key;
            task.startX = 0;
            task.startY = 0;
            task.width = static_cast<int>(thumb.width);
            task.height = static_cast<int>(thumb.height);
            task.dpiScale = dpiScale;
            task.priority = 2; // Low priority
            m_renderWorker->Enqueue(task);
        }
    }

    // Update active pages and InteractionManager objects
    for (auto pageIt = m_activePages.begin(); pageIt != m_activePages.end(); ) {
        if (currentVisiblePages.find(pageIt->first) == currentVisiblePages.end()) {
            m_interactionManager.RemoveObjectsForPage(pageIt->first);
            m_pageLinks.erase(pageIt->first);
            pageIt = m_activePages.erase(pageIt);
        } else {
            ++pageIt;
        }
    }
    
    for (int p : currentVisiblePages) {
        if (m_activePages.find(p) == m_activePages.end()) {
            auto page = m_doc->GetPage(p);
            m_activePages[p] = page;
            
            if (page) {
                m_pageLinks[p] = page->GetLinks();
                
                std::vector<std::shared_ptr<ui::interaction::ISelectableObject>> selectableObjects;
                auto annots = page->GetAnnotations();
                for (auto& a : annots) {
                    selectableObjects.push_back(std::make_shared<ui::interaction::AnnotationSelectableObject>(a, p));
                }
                auto images = page->GetImages();
                for (auto& img : images) {
                    selectableObjects.push_back(std::make_shared<ui::interaction::ImageSelectableObject>(img, p));
                }
                auto textObjs = page->GetTextObjects();
                for (auto& text : textObjs) {
                    selectableObjects.push_back(std::make_shared<ui::interaction::TextSelectableObject>(text, p));
                }
                m_interactionManager.AddObjects(selectableObjects);
            }
        }
    }
}

ITextPage* PdfViewer::GetTextPage(int pageIndex) {
    if (!m_doc) return nullptr;
    auto it = m_textPages.find(pageIndex);
    if (it == m_textPages.end()) {
        auto page = m_doc->GetPage(pageIndex);
        if (page) {
            m_textPages[pageIndex] = page->LoadTextPage();
            m_textPages_pages[pageIndex] = page;
        } else {
            m_textPages[pageIndex] = nullptr;
        }
    }
    return m_textPages[pageIndex].get();
}

void PdfViewer::OnLButtonUp(int x, int y) {
    if (m_currentTool == ToolMode::Select && m_doc) {
        int pageIndex = -1;
        double pdfX, pdfY;
        m_interactionManager.viewToPage(x, y, pdfX, pdfY, pageIndex);
        if (pageIndex != -1) {
            if (m_doc->OnLButtonUp(pageIndex, pdfX, pdfY, 0)) {
                return; // Handled by form
            }
        }
    }
    
    if (m_interactionManager.OnLButtonUp(x, y)) return;
    
    if (m_isCreatingAnnotation && m_createAnnotationPage != -1) {
        m_isCreatingAnnotation = false;
        ReleaseCapture();
        
        float width = m_bounds.right - m_bounds.left;
        const auto& page = m_layout[m_createAnnotationPage];
        float pageX = m_bounds.left + std::max(0.0f, (width - page.width) / 2.0f);
        float pageY = m_bounds.top + page.yOffset - m_scrollY;
        
        auto pageSize = m_doc->GetPageSize(page.index);
        CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
        CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
        
        PointF pdfPt = m_createAnnotationCurrentPdf;
        
        RectF bounds;
        bounds.left = std::min(m_createAnnotationStartPdf.x, pdfPt.x);
        bounds.right = std::max(m_createAnnotationStartPdf.x, pdfPt.x);
        bounds.top = std::max(m_createAnnotationStartPdf.y, pdfPt.y);
        bounds.bottom = std::min(m_createAnnotationStartPdf.y, pdfPt.y);
        
        // Add padding to bounds
        bounds.left -= 5.0f;
        bounds.right += 5.0f;
        bounds.top += 5.0f;
        bounds.bottom -= 5.0f;
        
        auto cmd = std::make_unique<pdf_engine::commands::AddAnnotationCommand>(
            m_doc.get(), m_createAnnotationPage, pdf_engine::AnnotationType::Line, bounds);
            
        auto* rawCmd = cmd.get();
        if (m_doc->GetCommandStack().ExecuteCommand(std::move(cmd))) {
            auto annot = rawCmd->GetAnnotation();
            if (annot) {
                pdf_engine::LineGeometry geom;
                geom.start = m_createAnnotationStartPdf;
                geom.end = pdfPt;
                geom.startEnding = pdf_engine::LineEnding::None;
                geom.endEnding = (m_currentTool == ToolMode::Arrow) ? pdf_engine::LineEnding::ClosedArrow : pdf_engine::LineEnding::None;
                annot->SetLineGeometry(geom);
                
                // Color and width
                annot->SetColor(255, 0, 0, 255); // Red
                annot->SetBorderWidth(2.0f);
            }
            m_currentTool = ToolMode::Select;
            m_tileCache->InvalidatePage(m_createAnnotationPage);
            InvalidateRect(m_hwnd, nullptr, FALSE);
        }
        return;
    }

    if (m_isInsertingImage) {
        m_isInsertingImage = false;
        
        float width = m_bounds.right - m_bounds.left;
        for (const auto& page : m_layout) {
            if (page.index == m_insertImagePage) {
                float pageX = m_bounds.left + std::max(0.0f, (width - page.width) / 2.0f);
                float pageY = m_bounds.top + page.yOffset - m_scrollY;
                
                auto pageSize = m_doc->GetPageSize(page.index);
                CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
                CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
                
                PointF pdfPt = CoordinateConverter::ScreenToPdf(ctx, view, x, y);
                
                RectF bounds;
                bounds.left = std::min(m_insertImageStartPt.x, pdfPt.x);
                bounds.right = std::max(m_insertImageStartPt.x, pdfPt.x);
                // In PDF coordinates, top is higher Y than bottom
                bounds.bottom = std::min(m_insertImageStartPt.y, pdfPt.y);
                bounds.top = std::max(m_insertImageStartPt.y, pdfPt.y);
                
                // If it was just a click, create a default size image
                if (bounds.right - bounds.left < 5 || bounds.top - bounds.bottom < 5) {
                    bounds.left = m_insertImageStartPt.x;
                    bounds.right = bounds.left + m_pendingImageWidth * 72.0f / 96.0f; // roughly pixels to points
                    bounds.top = m_insertImageStartPt.y;
                    bounds.bottom = bounds.top - m_pendingImageHeight * 72.0f / 96.0f;
                }
                
                auto cmd = std::make_unique<pdf_engine::commands::InsertImageCommand>(
                    m_doc.get(), m_insertImagePage, m_pendingImageData, m_pendingImageWidth, m_pendingImageHeight, bounds);
                
                if (m_doc->GetCommandStack().ExecuteCommand(std::move(cmd))) {
                    // Since it executed successfully, we can find the inserted image and add it to interaction manager
                    // Command gives us the image object directly, but let's just refresh pages or retrieve the last command.
                    // Wait, to add it to InteractionManager, we could just reload objects from the page!
                    auto nativePage = m_doc->GetPage(m_insertImagePage);
                    if (nativePage) {
                        auto images = nativePage->GetImages();
                        if (!images.empty()) {
                            auto selectable = std::make_shared<ui::interaction::ImageSelectableObject>(images.back(), m_insertImagePage);
                            m_interactionManager.AddObject(selectable);
                        }
                    }
                }
                
                m_currentTool = ToolMode::Select;
                m_pendingImageData.clear();
                m_tileCache->InvalidatePage(m_insertImagePage);
                UpdateVisibleTiles();
                return;
            }
        }
    }

    if (m_selection.isSelecting && m_selection.startPage != -1 && m_selection.endPage != -1) {
        if (m_currentTool == ToolMode::Highlight || m_currentTool == ToolMode::Underline || m_currentTool == ToolMode::Strikeout) {
            int startP = m_selection.startPage;
            int endP = m_selection.endPage;
            int startC = m_selection.startChar;
            int endC = m_selection.endChar;
            
            if (startP != -1 && endP != -1) {
                if (startP > endP || (startP == endP && startC > endC)) {
                    std::swap(startP, endP);
                    std::swap(startC, endC);
                }
                
                pdf_engine::AnnotationType type = pdf_engine::AnnotationType::Highlight;
                if (m_currentTool == ToolMode::Underline) type = pdf_engine::AnnotationType::Underline;
                else if (m_currentTool == ToolMode::Strikeout) type = pdf_engine::AnnotationType::StrikeOut;

                
                auto macro = std::make_unique<pdf_engine::commands::MacroCommand>("Add Markup");
                std::vector<std::pair<pdf_engine::commands::AddAnnotationCommand*, std::vector<QuadF>>> pendingCmds;

                for (int p = startP; p <= endP; ++p) {
                    auto textPage = GetTextPage(p);
                    if (!textPage) continue;
                    
                    int firstChar = (p == startP) ? startC : 0;
                    int lastChar = (p == endP) ? endC : textPage->GetCharCount() - 1;
                    int count = lastChar - firstChar + 1;
                    
                    if (count > 0) {
                        auto rects = textPage->GetRects(firstChar, count);
                        if (!rects.empty()) {
                            std::vector<QuadF> quads;
                            RectF bounds = rects[0];
                            for (const auto& r : rects) {
                                quads.push_back({
                                    {r.left, r.top},
                                    {r.right, r.top},
                                    {r.left, r.bottom},
                                    {r.right, r.bottom}
                                });
                                bounds.left = std::min(bounds.left, r.left);
                                bounds.right = std::max(bounds.right, r.right);
                                bounds.top = std::max(bounds.top, r.top);
                                bounds.bottom = std::min(bounds.bottom, r.bottom);
                            }
                            
                            auto cmd = std::make_unique<pdf_engine::commands::AddAnnotationCommand>(m_doc.get(), p, type, bounds);
                            pendingCmds.push_back({cmd.get(), quads});
                            macro->AddCommand(std::move(cmd));
                        }
                    }
                }
                
                if (!pendingCmds.empty()) {
                    if (m_doc->GetCommandStack().ExecuteCommand(std::move(macro))) {
                        for (auto& pCmd : pendingCmds) {
                            auto annot = pCmd.first->GetAnnotation();
                            if (annot) {
                                annot->SetQuadPoints(pCmd.second);
                                if (type == pdf_engine::AnnotationType::Highlight) {
                                    annot->SetColor(255, 255, 0, 255); // Yellow
                                } else if (type == pdf_engine::AnnotationType::Underline) {
                                    annot->SetColor(0, 128, 0, 255); // Greenish
                                } else if (type == pdf_engine::AnnotationType::StrikeOut) {
                                    annot->SetColor(255, 0, 0, 255); // Red
                                }
                                // m_interactionManager expects a selectable wrapper to allow selection/deletion
                                // However we don't have the page index easily accessible here without saving it.
                                // Actually, we can just invalidate, next interaction will reload it.
                            }
                        }
                    }
                }
m_selection.startPage = -1;
                m_selection.endPage = -1;
                m_tileCache->InvalidateAll();
                UpdateVisibleTiles();
            }
        }
    }
    m_selection.isSelecting = false;
}

void PdfViewer::OnLButtonDown(int x, int y) {
    if (!m_doc) return;

    if (x >= m_thumbnailBounds.left && x <= m_thumbnailBounds.right &&
        y >= m_thumbnailBounds.top && y <= m_thumbnailBounds.bottom) {
        
        float width = m_thumbnailBounds.right - m_thumbnailBounds.left;
        for (const auto& thumb : m_thumbnailLayout) {
            float screenY = m_thumbnailBounds.top + thumb.yOffset - m_thumbnailScrollY;
            float screenX = m_thumbnailBounds.left + (width - thumb.width) / 2.0f;
            
            if (x >= screenX && x <= screenX + thumb.width && y >= screenY && y <= screenY + thumb.height) {
                // Navigate to this page
                if (thumb.index < m_layout.size()) {
                    float height = m_bounds.bottom - m_bounds.top;
                    m_scrollY = std::max(0.0f, std::min(static_cast<float>(m_layout[thumb.index].yOffset), static_cast<float>(m_totalHeight - height)));
                    UpdateVisibleTiles();
                }
                return;
            }
        }
        return; // Handled by thumbnail area
    }

    bool shiftPressed = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
    
    // Form handling: Try to pass event to forms first if we are in Select mode
    if (m_currentTool == ToolMode::Select) {
        int pageIndex = -1;
        double pdfX, pdfY;
        m_interactionManager.viewToPage(x, y, pdfX, pdfY, pageIndex);
        if (pageIndex != -1) {
            if (m_doc->OnLButtonDown(pageIndex, pdfX, pdfY, 0)) {
                return; // Handled by form
            }
        }
    }
    
    auto interactionHit = m_interactionManager.OnLButtonDown(x, y, shiftPressed);
    if (interactionHit == ui::interaction::HitResult::Object && m_currentTool == ToolMode::EditText) {
        auto selObjects = m_interactionManager.GetSelection();
        if (selObjects.size() == 1) {
            if (auto textObj = std::dynamic_pointer_cast<ui::interaction::TextSelectableObject>(selObjects.front())) {
                if (!m_interactionManager.IsEditingText()) {
                    m_interactionManager.EnterTextEditMode(textObj);
                    InvalidateRect(m_hwnd, nullptr, FALSE);
                }
            }
        }
    }
    if (interactionHit != ui::interaction::HitResult::None) {
        return;
    } else {
        if (!shiftPressed && (m_currentTool == ToolMode::Select || m_currentTool == ToolMode::EditText)) {
            m_interactionManager.GetSelectionModel().Clear();
            InvalidateRect(m_hwnd, nullptr, FALSE);
        }
    }


    if (m_currentTool == ToolMode::InsertImage && !m_pendingImageData.empty()) {
        float width = m_bounds.right - m_bounds.left;
        for (const auto& page : m_layout) {
            float pageX = m_bounds.left + std::max(0.0f, (width - page.width) / 2.0f);
            float pageY = m_bounds.top + page.yOffset - m_scrollY;
            
            if (x >= pageX && x <= pageX + page.width && y >= pageY && y <= pageY + page.height) {
                auto pageSize = m_doc->GetPageSize(page.index);
                CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
                CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
                
                PointF pdfPt = CoordinateConverter::ScreenToPdf(ctx, view, x, y);
                m_isInsertingImage = true;
                m_insertImagePage = page.index;
                m_insertImageStartPt = pdfPt;
                return;
            }
        }
    } else if (m_currentTool == ToolMode::Line || m_currentTool == ToolMode::Arrow) {
        float width = m_bounds.right - m_bounds.left;
        for (const auto& page : m_layout) {
            float pageX = m_bounds.left + std::max(0.0f, (width - page.width) / 2.0f);
            float pageY = m_bounds.top + page.yOffset - m_scrollY;
            
            if (x >= pageX && x <= pageX + page.width && y >= pageY && y <= pageY + page.height) {
                auto pageSize = m_doc->GetPageSize(page.index);
                CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
                CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
                
                PointF pdfPt = CoordinateConverter::ScreenToPdf(ctx, view, x, y);
                m_isCreatingAnnotation = true;
                m_createAnnotationPage = page.index;
                m_createAnnotationStartPdf = pdfPt;
                m_createAnnotationCurrentPdf = pdfPt;
                SetCapture(m_hwnd);
                return;
            }
        }
    } else if (m_currentTool == ToolMode::AddText) {
        float width = m_bounds.right - m_bounds.left;
        for (const auto& page : m_layout) {
            float pageX = m_bounds.left + std::max(0.0f, (width - page.width) / 2.0f);
            float pageY = m_bounds.top + page.yOffset - m_scrollY;
            
            if (x >= pageX && x <= pageX + page.width && y >= pageY && y <= pageY + page.height) {
                auto pageSize = m_doc->GetPageSize(page.index);
                CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
                CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
                
                PointF pdfPt = CoordinateConverter::ScreenToPdf(ctx, view, x, y);
                
                // Default bounds for new text object
                RectF bounds;
                bounds.left = pdfPt.x;
                bounds.top = pdfPt.y;
                bounds.right = bounds.left + 200.0f;
                bounds.bottom = bounds.top - 20.0f; // 20pt height approx
                
                // Use AddTextCommand
                auto cmd = std::make_unique<pdf_engine::commands::AddTextCommand>(
                    m_doc.get(), page.index, L"", bounds, "Arial", 12.0f, 0, 0, 0, 255);
                    
                if (m_doc->GetCommandStack().ExecuteCommand(std::move(cmd))) {
                    auto nativePage = m_doc->GetPage(page.index);
                    if (nativePage) {
                        auto textObjs = nativePage->GetTextObjects();
                        if (!textObjs.empty()) {
                            auto lastTextObj = textObjs.back();
                            // Find the corresponding selectable object
                            std::shared_ptr<ui::interaction::TextSelectableObject> targetSelectable;
                            for (auto& obj : m_interactionManager.GetObjects()) {
                                auto textObj = std::dynamic_pointer_cast<ui::interaction::TextSelectableObject>(obj);
                                if (textObj && textObj->GetTextObject() == lastTextObj) {
                                    targetSelectable = textObj;
                                    break;
                                }
                            }
                            
                            if (targetSelectable) {
                                m_interactionManager.GetSelectionModel().Clear();
                                m_interactionManager.GetSelectionModel().Select(targetSelectable);
                                m_interactionManager.EnterTextEditMode(targetSelectable);
                            }
                        }
                    }
                }
                
                m_currentTool = ToolMode::Select;
                InvalidateRect(m_hwnd, nullptr, FALSE);
                return;
            }
        }
    }
    
    // Check Links on Click
    if (m_hoveredLink.has_value() && (m_currentTool == ToolMode::Select || m_currentTool == ToolMode::Pan)) {
        if (m_hoveredLink->destination.has_value()) {
            NavigateTo(m_hoveredLink->destination.value());
        } else if (m_hoveredLink->uri.has_value()) {
            // Task 22J/W: External URL links
            // We'll prompt or use ShellExecute to open URL safely
            // For now, use ShellExecute with basic safety check
            std::string uri = m_hoveredLink->uri.value();
            if (uri.find("http://") == 0 || uri.find("https://") == 0 || uri.find("mailto:") == 0) {
                std::string msg = "This document is trying to open an external link:\n\n" + uri + "\n\nDo you trust this link?";
                int result = MessageBoxA(m_hwnd, msg.c_str(), "Security Warning", MB_YESNO | MB_ICONWARNING);
                if (result == IDYES) {
                    ShellExecuteA(m_hwnd, "open", uri.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
                }
            }
        }
        return;
    }
    
    float width = m_bounds.right - m_bounds.left;
    bool textSelected = false;
    
    for (const auto& page : m_layout) {
        float pageX = m_bounds.left + std::max(0.0f, (width - page.width) / 2.0f);
        float pageY = m_bounds.top + page.yOffset - m_scrollY;
        
        if (x >= pageX && x <= pageX + page.width && y >= pageY && y <= pageY + page.height) {
            auto textPage = GetTextPage(page.index);
            if (textPage) {
                auto pageSize = m_doc->GetPageSize(page.index);
                CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
                CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
                
                PointF pdfPt = CoordinateConverter::ScreenToPdf(ctx, view, x, y);
                int charIndex = textPage->GetCharIndexAtPos(pdfPt.x, pdfPt.y, 5.0, 5.0);
                
                // 3. Text Hit
                if (charIndex >= 0) {
                    m_selection.isSelecting = true;
                    m_selection.startPage = page.index;
                    m_selection.startChar = charIndex;
                    m_selection.endPage = page.index;
                    m_selection.endChar = charIndex;
                    InvalidateRect(m_hwnd, nullptr, FALSE);
                    textSelected = true;
                } else {
                    m_selection.isSelecting = false;
                    m_selection.startPage = -1;
                    m_selection.endPage = -1;
                    InvalidateRect(m_hwnd, nullptr, FALSE);
                }
            }
            break;
        }
    }

    // 4. Marquee (Empty space)
    if (!textSelected) {
        m_interactionManager.StartMarquee(x, y, shiftPressed);
    }
}

void PdfViewer::OnLButtonDoubleClick(int x, int y) {
    (void)x;
    (void)y;
    auto selObjects = m_interactionManager.GetSelection();
    if (selObjects.size() == 1) {
        auto textObj = std::dynamic_pointer_cast<ui::interaction::TextSelectableObject>(selObjects.front());
        if (textObj) {
            m_interactionManager.EnterTextEditMode(textObj);
            InvalidateRect(m_hwnd, nullptr, FALSE);
        }
    }
}

void PdfViewer::OnRButtonUp(int x, int y) {
    auto selObjects = m_interactionManager.GetSelection();
    if (selObjects.empty()) {
        // Page context menu
        POINT pt = { x, y };
        ClientToScreen(m_hwnd, &pt);
        HMENU hMenu = CreatePopupMenu();
        AppendMenuW(hMenu, MF_STRING, 2030, L"Insert Page");
        AppendMenuW(hMenu, MF_STRING, 2031, L"Delete Page");
        AppendMenuW(hMenu, MF_STRING, 2032, L"Rotate Page");
        AppendMenuW(hMenu, MF_STRING, 2033, L"Extract Page");
        TrackPopupMenu(hMenu, TPM_LEFTALIGN | TPM_RIGHTBUTTON, pt.x, pt.y, 0, m_hwnd, NULL);
        DestroyMenu(hMenu);
        return;
    }
    
    bool hasAnnotation = false;
    bool hasText = false;
    bool hasImage = false;

    for (auto obj : selObjects) {
        if (std::dynamic_pointer_cast<ui::interaction::AnnotationSelectableObject>(obj)) hasAnnotation = true;
        if (std::dynamic_pointer_cast<ui::interaction::TextSelectableObject>(obj)) hasText = true;
        if (std::dynamic_pointer_cast<ui::interaction::ImageSelectableObject>(obj)) hasImage = true;
    }
    
    POINT pt = { x, y };
    ClientToScreen(m_hwnd, &pt);
    HMENU hMenu = CreatePopupMenu();

    if (hasImage && selObjects.size() == 1) {
        AppendMenuW(hMenu, MF_STRING, 2014, L"Replace Image");
        AppendMenuW(hMenu, MF_STRING, 2015, L"Extract Image");
        AppendMenuW(hMenu, MF_STRING, 2016, L"Crop Image");
        AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
        AppendMenuW(hMenu, MF_STRING, 2010, L"Delete");
    } else if (hasText && selObjects.size() == 1) {
        AppendMenuW(hMenu, MF_STRING, 2011, L"Copy");
        AppendMenuW(hMenu, MF_STRING, 2012, L"Edit");
        AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
        AppendMenuW(hMenu, MF_STRING, 2013, L"Add Link");
        AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
        AppendMenuW(hMenu, MF_STRING, 2010, L"Delete");
    } else if (hasAnnotation) {
        HMENU hColorMenu = CreatePopupMenu();
        AppendMenuW(hColorMenu, MF_STRING, 2001, L"Red");
        AppendMenuW(hColorMenu, MF_STRING, 2002, L"Green");
        AppendMenuW(hColorMenu, MF_STRING, 2003, L"Blue");
        AppendMenuW(hColorMenu, MF_STRING, 2004, L"Black");
        AppendMenuW(hColorMenu, MF_STRING, 2005, L"Yellow");
        AppendMenuW(hMenu, MF_POPUP, (UINT_PTR)hColorMenu, L"Properties (Color)");
        AppendMenuW(hMenu, MF_SEPARATOR, 0, NULL);
        AppendMenuW(hMenu, MF_STRING, 2010, L"Delete");
    }
    
    TrackPopupMenu(hMenu, TPM_LEFTALIGN | TPM_RIGHTBUTTON, pt.x, pt.y, 0, m_hwnd, NULL);
    DestroyMenu(hMenu);
}


void PdfViewer::OnMouseMove(int x, int y) {
    if (m_currentTool == ToolMode::Select && m_doc && !m_selection.isSelecting) {
        int pageIndex = -1;
        double pdfX, pdfY;
        m_interactionManager.viewToPage(x, y, pdfX, pdfY, pageIndex);
        if (pageIndex != -1) {
            if (m_doc->OnMouseMove(pageIndex, pdfX, pdfY, 0)) {
                return; // Handled by form
            }
        }
    }

    if (m_interactionManager.OnMouseMove(x, y)) return;
    
    if (m_isCreatingAnnotation && m_createAnnotationPage != -1 && m_createAnnotationPage < m_layout.size()) {
        float width = m_bounds.right - m_bounds.left;
        const auto& page = m_layout[m_createAnnotationPage];
        float pageX = m_bounds.left + std::max(0.0f, (width - page.width) / 2.0f);
        float pageY = m_bounds.top + page.yOffset - m_scrollY;
        
        auto pageSize = m_doc->GetPageSize(page.index);
        CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
        CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
        
        m_createAnnotationCurrentPdf = CoordinateConverter::ScreenToPdf(ctx, view, x, y);
        
        // Snap behavior (Shift)
        if (GetAsyncKeyState(VK_SHIFT) & 0x8000) {
            float dx = m_createAnnotationCurrentPdf.x - m_createAnnotationStartPdf.x;
            float dy = m_createAnnotationCurrentPdf.y - m_createAnnotationStartPdf.y;
            
            if (std::abs(dx) > std::abs(dy) * 2.0f) {
                // Snap to horizontal
                m_createAnnotationCurrentPdf.y = m_createAnnotationStartPdf.y;
            } else if (std::abs(dy) > std::abs(dx) * 2.0f) {
                // Snap to vertical
                m_createAnnotationCurrentPdf.x = m_createAnnotationStartPdf.x;
            } else {
                // Snap to 45 degrees
                float dist = (std::abs(dx) + std::abs(dy)) / 2.0f;
                m_createAnnotationCurrentPdf.x = m_createAnnotationStartPdf.x + (dx > 0 ? dist : -dist);
                m_createAnnotationCurrentPdf.y = m_createAnnotationStartPdf.y + (dy > 0 ? dist : -dist);
            }
        }
        
        InvalidateRect(m_hwnd, nullptr, FALSE);
        return;
    }

    if (m_isInsertingImage) {
        // Just invalidate to render preview
        InvalidateRect(m_hwnd, nullptr, FALSE);
        return;
    }
    
    // Check Links
    if (!m_selection.isSelecting && m_doc && (m_currentTool == ToolMode::Select || m_currentTool == ToolMode::Pan)) {
        float width = m_bounds.right - m_bounds.left;
        std::optional<pdf_engine::PdfLink> hitLink = std::nullopt;
        
        for (const auto& page : m_layout) {
            float pageX = m_bounds.left + std::max(0.0f, (width - page.width) / 2.0f);
            float pageY = m_bounds.top + page.yOffset - m_scrollY;
            
            if (x >= pageX && x <= pageX + page.width && y >= pageY && y <= pageY + page.height) {
                auto it = m_pageLinks.find(page.index);
                if (it != m_pageLinks.end()) {
                    auto pageSize = m_doc->GetPageSize(page.index);
                    CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
                    CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
                    
                    PointF pdfPt = CoordinateConverter::ScreenToPdf(ctx, view, x, y);
                    
                    for (const auto& link : it->second) {
                        if (pdfPt.x >= link.bounds.left && pdfPt.x <= link.bounds.right &&
                            pdfPt.y >= link.bounds.bottom && pdfPt.y <= link.bounds.top) { // Note: PDF y goes up!
                            hitLink = link;
                            break;
                        }
                    }
                }
                break;
            }
        }
        
        if (hitLink.has_value() != m_hoveredLink.has_value() || 
            (hitLink.has_value() && m_hoveredLink.has_value() && hitLink->uri != m_hoveredLink->uri)) {
            m_hoveredLink = hitLink;
            if (m_hoveredLink) {
                SetCursor(LoadCursor(nullptr, IDC_HAND));
            } else {
                SetCursor(LoadCursor(nullptr, IDC_ARROW));
            }
        } else if (m_hoveredLink) {
            SetCursor(LoadCursor(nullptr, IDC_HAND));
            return;
        }
    }
    
    if (!m_selection.isSelecting || !m_doc) return;
    
    float width = m_bounds.right - m_bounds.left;
    
    for (const auto& page : m_layout) {
        float pageX = m_bounds.left + std::max(0.0f, (width - page.width) / 2.0f);
        float pageY = m_bounds.top + page.yOffset - m_scrollY;
        
        if (x >= pageX && x <= pageX + page.width && y >= pageY && y <= pageY + page.height) {
            auto textPage = GetTextPage(page.index);
            if (textPage) {
                auto pageSize = m_doc->GetPageSize(page.index);
                CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
                CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageX, pageY };
                
                PointF pdfPt = CoordinateConverter::ScreenToPdf(ctx, view, x, y);
                int charIndex = textPage->GetCharIndexAtPos(pdfPt.x, pdfPt.y, 5.0, 5.0);
                
                if (charIndex >= 0) {
                    if (m_selection.endPage != page.index || m_selection.endChar != charIndex) {
                        m_selection.endPage = page.index;
                        m_selection.endChar = charIndex;
                        InvalidateRect(m_hwnd, nullptr, FALSE);
                    }
                }
            }
            break;
        }
    }
}


void PdfViewer::OnKeyDown(WPARAM wParam) {
    bool ctrlPressed = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
    bool shiftPressed = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
    
    if (ctrlPressed) {
        if (wParam == 'Z') { // Undo
            if (m_doc && m_doc->GetCommandStack().Undo()) {
                m_tileCache->InvalidateAll();
                UpdateVisibleTiles();
                return;
            }
        }
        else if (wParam == 'Y') { // Redo
            if (m_doc && m_doc->GetCommandStack().Redo()) {
                m_tileCache->InvalidateAll();
                UpdateVisibleTiles();
                return;
            }
        }
        else if (wParam == 'C') { // Copy
            CopySelection();
            return;
        }
        else if (wParam == 'X') { // Cut
            CopySelection();
            m_interactionManager.OnKeyDown(VK_DELETE, shiftPressed, ctrlPressed);
            return;
        }
        else if (wParam == 'V') { // Paste
            m_interactionManager.OnKeyDown('V', shiftPressed, true);
            return;
        }
    }
    
    if (wParam == VK_ESCAPE) {
        if (m_isCreatingAnnotation) {
            m_isCreatingAnnotation = false;
            ReleaseCapture();
            InvalidateRect(m_hwnd, nullptr, FALSE);
            return;
        }
        if (m_isInsertingImage) {
            m_isInsertingImage = false;
            InvalidateRect(m_hwnd, nullptr, FALSE);
            return;
        }
        if (m_selection.isSelecting) {
            m_selection.isSelecting = false;
            ReleaseCapture();
            InvalidateRect(m_hwnd, nullptr, FALSE);
            return;
        }
        // Cancel any active tool safely back to Select mode
        if (m_currentTool != ToolMode::Select && m_currentTool != ToolMode::Pan) {
            SetToolMode(ToolMode::Select);
            return;
        }
    }
    else if (wParam == VK_PRIOR) { // Page Up
        int p = GetCurrentPage();
        if (p > 0) GoToPage(p - 1);
        return;
    }
    else if (wParam == VK_NEXT) { // Page Down
        int p = GetCurrentPage();
        if (m_doc && p < m_doc->PageCount() - 1) GoToPage(p + 1);
        return;
    }
    
    if (m_doc && m_doc->OnKeyDown(static_cast<int>(wParam), 0)) {
        return;
    }
    
    if (m_interactionManager.OnKeyDown(wParam, shiftPressed, ctrlPressed)) return;
}

void PdfViewer::OnChar(WPARAM wParam) {
    if (m_doc && m_doc->OnChar(static_cast<int>(wParam), 0)) {
        return;
    }
    if (m_interactionManager.OnChar(wParam)) return;
}

void PdfViewer::CopySelection() {
    auto selObjects = m_interactionManager.GetSelection();
    for (auto obj : selObjects) {
        auto textObj = std::dynamic_pointer_cast<ui::interaction::TextSelectableObject>(obj);
        if (textObj) {
            auto text = textObj->GetTextObject();
            if (!text) continue;
            std::wstring wText = text->GetText();
            if (!wText.empty()) {
                if (OpenClipboard(m_hwnd)) {
                    EmptyClipboard();
                    int bytes = static_cast<int>((wText.length() + 1) * sizeof(wchar_t));
                    HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, bytes);
                    if (hMem) {
                        wchar_t* pBuf = (wchar_t*)GlobalLock(hMem);
                        memcpy(pBuf, wText.c_str(), bytes);
                        GlobalUnlock(hMem);
                        SetClipboardData(CF_UNICODETEXT, hMem);
                    }
                    CloseClipboard();
                    return;
                }
            }
        }

        auto imgObj = std::dynamic_pointer_cast<ui::interaction::ImageSelectableObject>(obj);
        if (imgObj) {
            auto image = imgObj->GetImage();
            if (!image) continue;
            
            auto bitmapData = image->GetBitmapData();
            int width = image->GetWidth();
            int height = image->GetHeight();
            
            if (width > 0 && height > 0 && !bitmapData.empty()) {
                if (OpenClipboard(m_hwnd)) {
                    EmptyClipboard();
                    
                    size_t headerSize = sizeof(BITMAPINFOHEADER);
                    size_t dataSize = width * height * 4; 
                    HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, headerSize + dataSize);
                    if (hMem) {
                        uint8_t* mem = (uint8_t*)GlobalLock(hMem);
                        
                        BITMAPINFOHEADER* bmi = (BITMAPINFOHEADER*)mem;
                        bmi->biSize = sizeof(BITMAPINFOHEADER);
                        bmi->biWidth = width;
                        bmi->biHeight = -height; 
                        bmi->biPlanes = 1;
                        bmi->biBitCount = 32;
                        bmi->biCompression = BI_RGB;
                        bmi->biSizeImage = 0;
                        bmi->biXPelsPerMeter = 0;
                        bmi->biYPelsPerMeter = 0;
                        bmi->biClrUsed = 0;
                        bmi->biClrImportant = 0;
                        
                        memcpy(mem + headerSize, bitmapData.data(), dataSize);
                        
                        GlobalUnlock(hMem);
                        SetClipboardData(CF_DIB, hMem);
                    }
                    CloseClipboard();
                    return;
                }
            }
        }
    }
}


void PdfViewer::RenderSelection(ComPtr<ID2D1HwndRenderTarget> target, const PageLayout& page, float pageScreenX, float pageScreenY) {
    if (m_selection.startPage == -1 || m_selection.endPage == -1) return;
    
    int startP = m_selection.startPage;
    int endP = m_selection.endPage;
    int startC = m_selection.startChar;
    int endC = m_selection.endChar;
    
    if (startP > endP || (startP == endP && startC > endC)) {
        std::swap(startP, endP);
        std::swap(startC, endC);
    }
    
    if (page.index < startP || page.index > endP) return;
    
    auto textPage = GetTextPage(page.index);
    if (!textPage) return;
    
    int firstChar = (page.index == startP) ? startC : 0;
    int lastChar = (page.index == endP) ? endC : textPage->GetCharCount() - 1;
    int count = lastChar - firstChar + 1;
    
    if (count <= 0) return;
    
    auto rects = textPage->GetRects(firstChar, count);
    
    ComPtr<ID2D1SolidColorBrush> selectionBrush;
    // Semi-transparent blue
    target->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.5f, 1.0f, 0.3f), &selectionBrush);
    
    auto pageSize = m_doc->GetPageSize(page.index);
    CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
    CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageScreenX, pageScreenY };
    
    for (const auto& r : rects) {
        RectF screenRect = CoordinateConverter::PdfToScreenRect(ctx, view, r.left, r.top, r.right, r.bottom);
        target->FillRectangle(D2D1::RectF(screenRect.left, screenRect.top, screenRect.right, screenRect.bottom), selectionBrush.Get());
    }
}

void PdfViewer::SetSearchResults(const std::vector<pdf_engine::SearchResult>& results, int activeIndex) {
    m_searchResults = results;
    m_activeSearchIndex = activeIndex;
    
    if (activeIndex >= 0 && activeIndex < (int)results.size()) {
        const auto& active = results[activeIndex];
        
        // Scroll to the active search result
        for (const auto& page : m_layout) {
            if (page.index == active.pageIndex) {
                auto textPage = GetTextPage(page.index);
                if (textPage) {
                    auto rects = textPage->GetRects(active.charIndex, active.charCount);
                    if (!rects.empty()) {
                        auto pageSize = m_doc->GetPageSize(page.index);
                        CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
                        CoordinateConverter::ViewContext view = { m_zoom, 0, 0, 0, 0 }; // We only care about Y offset relative to page
                        
                        RectF viewRect = CoordinateConverter::PdfToScreenRect(ctx, view, rects[0].left, rects[0].top, rects[0].right, rects[0].bottom);
                        
                        float targetScrollY = page.yOffset + viewRect.top - (m_bounds.bottom - m_bounds.top) / 2.0f;
                        float height = m_bounds.bottom - m_bounds.top;
                        m_scrollY = std::max(0.0f, std::min(static_cast<float>(targetScrollY), static_cast<float>(m_totalHeight - height)));
                        UpdateVisibleTiles();
                    }
                }
                break;
            }
        }
    }
    
    InvalidateRect(m_hwnd, nullptr, FALSE);
}

void PdfViewer::RenderSearchResults(ComPtr<ID2D1HwndRenderTarget> target, const PageLayout& page, float pageScreenX, float pageScreenY) {
    if (m_searchResults.empty() || !m_doc) return;
    
    ComPtr<ID2D1SolidColorBrush> highlightBrush;
    target->CreateSolidColorBrush(D2D1::ColorF(1.0f, 1.0f, 0.0f, 0.4f), &highlightBrush); // Yellow
    
    ComPtr<ID2D1SolidColorBrush> activeBrush;
    target->CreateSolidColorBrush(D2D1::ColorF(1.0f, 0.5f, 0.0f, 0.6f), &activeBrush); // Orange
    
    auto pageSize = m_doc->GetPageSize(page.index);
    CoordinateConverter::PageContext ctx = { pageSize.width, pageSize.height, m_doc->GetPage(page.index)->GetRotation() };
    CoordinateConverter::ViewContext view = { m_zoom, 0, 0, pageScreenX, pageScreenY };
    
    auto textPage = GetTextPage(page.index);
    if (!textPage) return;
    
    for (size_t i = 0; i < m_searchResults.size(); ++i) {
        const auto& res = m_searchResults[i];
        if (res.pageIndex != page.index) continue;
        
        auto rects = textPage->GetRects(res.charIndex, res.charCount);
        ID2D1SolidColorBrush* brush = (static_cast<int>(i) == m_activeSearchIndex) ? activeBrush.Get() : highlightBrush.Get();
        
        for (const auto& r : rects) {
            RectF screenRect = CoordinateConverter::PdfToScreenRect(ctx, view, r.left, r.top, r.right, r.bottom);
            target->FillRectangle(D2D1::RectF(screenRect.left, screenRect.top, screenRect.right, screenRect.bottom), brush);
        }
    }
}

void PdfViewer::OnCommand(WPARAM wParam, LPARAM lParam) {
    int wmId = LOWORD(wParam);
    
    // Check if it's the Edit control notification
    if (lParam != 0 && (HWND)lParam == m_editControl) {
        if (HIWORD(wParam) == EN_KILLFOCUS) {
            // Handled by Subclass proc
        }
        return;
    }
    
    // Context menu commands
    if (wmId >= 2001 && wmId <= 2005) {
        int r = 0, g = 0, b = 0;
        if (wmId == 2001) { r = 255; g = 0; b = 0; }
        else if (wmId == 2002) { r = 0; g = 255; b = 0; }
        else if (wmId == 2003) { r = 0; g = 0; b = 255; }
        else if (wmId == 2004) { r = 0; g = 0; b = 0; }
        else if (wmId == 2005) { r = 255; g = 255; b = 0; }
        
        auto selObjects = m_interactionManager.GetSelection();
        for (auto obj : selObjects) {
            auto annotObj = std::dynamic_pointer_cast<ui::interaction::AnnotationSelectableObject>(obj);
            if (annotObj) {
                auto annot = annotObj->GetAnnotation();
                if (annot) {
                    annot->SetColor(r, g, b, 255);
                    m_tileCache->InvalidatePage(annotObj->GetPageIndex());
                }
            }
        }
        InvalidateRect(m_hwnd, nullptr, FALSE);
          } else if (wmId == 2010) { // Delete
          OnKeyDown(VK_DELETE);
      } else if (wmId == 2011) { // Copy
          CopySelection();
      } else if (wmId == 2012) { // Edit
          auto selObjects = m_interactionManager.GetSelection();
          if (selObjects.size() == 1) {
              auto txtObj = std::dynamic_pointer_cast<ui::interaction::TextSelectableObject>(selObjects[0]); if (txtObj) m_interactionManager.EnterTextEditMode(txtObj);
          }
      } else if (wmId == 2015) { // Extract Image
          auto selObjects = m_interactionManager.GetSelection();
          if (selObjects.size() == 1) {
              auto imgObj = std::dynamic_pointer_cast<ui::interaction::ImageSelectableObject>(selObjects[0]);
              if (imgObj && imgObj->GetImage()) {
                  OPENFILENAMEW ofn = {};
                  wchar_t filename[MAX_PATH] = {0};
                  ofn.lStructSize = sizeof(ofn);
                  ofn.hwndOwner = m_hwnd;
                  ofn.lpstrFilter = L"PNG Image\0*.png\0BMP Image\0*.bmp\0";
                  ofn.lpstrFile = filename;
                  ofn.nMaxFile = MAX_PATH;
                  ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
                  ofn.lpstrDefExt = L"png";
                  if (GetSaveFileNameW(&ofn)) {
                      auto bmpData = imgObj->GetImage()->GetBitmapData();
                      if (!bmpData.empty()) {
                          ui::utils::WicImageLoader::SaveImageToFile(filename, bmpData, imgObj->GetImage()->GetWidth(), imgObj->GetImage()->GetHeight());
                      } else {
                          MessageBoxW(m_hwnd, L"PDFium could not extract this image format.", L"Extraction Failed", MB_OK | MB_ICONERROR);
                      }
                  }
              }
          }
      }

}

void PdfViewer::TriggerInsertImage() {
    OPENFILENAMEW ofn = {};
    wchar_t filename[MAX_PATH] = {0};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = m_hwnd;
    ofn.lpstrFilter = L"Images\0*.png;*.jpg;*.jpeg;*.bmp\0All Files\0*.*\0";
    ofn.lpstrFile = filename;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;

    if (GetOpenFileNameW(&ofn)) {
        int w, h;
        if (ui::utils::WicImageLoader::LoadImageFromFile(filename, m_pendingImageData, w, h)) {
            m_pendingImageWidth = w;
            m_pendingImageHeight = h;
            m_currentTool = ToolMode::InsertImage;
        }
    }
}

void PdfViewer::PasteImage() {
    int w, h;
    if (ui::utils::WicImageLoader::LoadImageFromClipboard(m_hwnd, m_pendingImageData, w, h)) {
        m_pendingImageWidth = w;
        m_pendingImageHeight = h;
        m_currentTool = ToolMode::InsertImage;
    }
}

void PdfViewer::RenderThumbnails(ComPtr<ID2D1HwndRenderTarget> target, const D2D1_RECT_F& bounds) {
    PERF_SCOPE("PdfViewer_RenderThumbnails");
    if (!m_doc) return;
    
    m_thumbnailBounds = bounds;

    // Cap scroll Y now that we know the height of the bounds
    float viewHeight = bounds.bottom - bounds.top;
    m_thumbnailScrollY = std::max(0.0f, std::min(m_thumbnailScrollY, static_cast<float>(std::max(0.0f, m_totalThumbnailHeight - viewHeight))));

    target->PushAxisAlignedClip(bounds, D2D1_ANTIALIAS_MODE_ALIASED);

    // Render background
    ComPtr<ID2D1SolidColorBrush> bgBrush;
    target->CreateSolidColorBrush(D2D1::ColorF(0.15f, 0.15f, 0.18f), &bgBrush);
    target->FillRectangle(bounds, bgBrush.Get());

    ComPtr<ID2D1SolidColorBrush> borderBrush;
    target->CreateSolidColorBrush(D2D1::ColorF(0.3f, 0.3f, 0.3f), &borderBrush);
    
    ComPtr<ID2D1SolidColorBrush> textBrush;
    target->CreateSolidColorBrush(D2D1::ColorF(0.7f, 0.7f, 0.7f), &textBrush);
    
    ComPtr<IDWriteTextFormat> textFormat;
    GraphicsDevice::Instance().GetDWriteFactory()->CreateTextFormat(
        L"Segoe UI", nullptr, DWRITE_FONT_WEIGHT_NORMAL, DWRITE_FONT_STYLE_NORMAL, 
        DWRITE_FONT_STRETCH_NORMAL, 12.0f, L"en-us", &textFormat
    );
    textFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);

    ComPtr<ID2D1SolidColorBrush> activeBorderBrush;
    target->CreateSolidColorBrush(D2D1::ColorF(0.0f, 0.47f, 0.83f), &activeBorderBrush); // Blue

    float width = bounds.right - bounds.left;
    
    int currentPage = 0;
    for (const auto& page : m_layout) {
        if (page.yOffset + page.height / 2 > m_scrollY) {
            currentPage = page.index;
            break;
        }
    }

    for (const auto& thumb : m_thumbnailLayout) {
        float screenY = bounds.top + thumb.yOffset - m_thumbnailScrollY;
        if (screenY + thumb.height < bounds.top || screenY > bounds.bottom) {
            continue;
        }

        float screenX = bounds.left + (width - thumb.width) / 2.0f;
        D2D1_RECT_F thumbRect = D2D1::RectF(screenX, screenY, screenX + thumb.width, screenY + thumb.height);

        // Draw shadow/border
        target->DrawRectangle(thumbRect, thumb.index == currentPage ? activeBorderBrush.Get() : borderBrush.Get(), thumb.index == currentPage ? 2.0f : 1.0f);

        auto size = m_doc->GetPageSize(thumb.index);
        double thumbZoom = thumb.width / size.width;
        float dpiX, dpiY;
        target->GetDpi(&dpiX, &dpiY);
        float dpiScale = dpiX / 96.0f;
        TileKey key{m_generation, thumb.index, thumbZoom, dpiScale, 0, 0, static_cast<int>(thumb.width), static_cast<int>(thumb.height)};

        auto bitmap = m_tileCache->Get(key);
        if (bitmap) {
            target->DrawBitmap(bitmap.Get(), thumbRect, 1.0f, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR,
                               D2D1::RectF(0, 0, thumb.width, thumb.height));
        } else {
            // Placeholder
            ComPtr<ID2D1SolidColorBrush> phBrush;
            target->CreateSolidColorBrush(D2D1::ColorF(0.2f, 0.2f, 0.25f), &phBrush);
            target->FillRectangle(thumbRect, phBrush.Get());
        }

        // Draw page number below
        std::wstring pageNum = std::to_wstring(thumb.index + 1);
        D2D1_RECT_F textRect = D2D1::RectF(bounds.left, thumbRect.bottom + 2.0f, bounds.right, thumbRect.bottom + 18.0f);
        target->DrawText(pageNum.c_str(), static_cast<UINT32>(pageNum.length()), textFormat.Get(), textRect, textBrush.Get());
    }

    target->PopAxisAlignedClip();
}


void PdfViewer::GoToPage(int pageIndex) {
    PERF_SCOPE("PdfViewer_GoToPage");
    if (!m_doc) return;
    if (pageIndex < 0 || pageIndex >= m_doc->PageCount()) return;

    if (m_layoutMode == LayoutMode::SinglePage) {
        if (m_currentPage != pageIndex) {
            m_currentPage = pageIndex;
            m_scrollY = 0.0f;
            RecalculateLayout();
            m_tileCache->InvalidateAll();
            m_generation++;
            UpdateVisibleTiles();
            InvalidateView();
        }
    } else {
        if (pageIndex < m_layout.size()) {
            float height = m_bounds.bottom - m_bounds.top;
            m_scrollY = std::max(0.0f, std::min(static_cast<float>(m_layout[pageIndex].yOffset), static_cast<float>(m_totalHeight - height)));
            UpdateVisibleTiles();
            InvalidateView();
        }
    }
}

void PdfViewer::NavigateTo(const pdf_engine::NavigationTarget& target) {
    if (!m_doc) return;
    if (target.pageIndex < 0 || target.pageIndex >= m_doc->PageCount()) return;

    if (target.zoom.has_value()) {
        m_zoom = target.zoom.value();
        RecalculateLayout();
        m_tileCache->InvalidateAll();
        m_generation++;
    }

    if (m_layoutMode == LayoutMode::SinglePage) {
        if (m_currentPage != target.pageIndex) {
            m_currentPage = target.pageIndex;
            RecalculateLayout();
            m_tileCache->InvalidateAll();
            m_generation++;
        }
        
        if (target.top.has_value()) {
            m_scrollY = static_cast<float>(target.top.value() * m_zoom);
        } else {
            m_scrollY = 0.0f;
        }
        
        UpdateVisibleTiles();
        InvalidateView();
    } else {
        if (target.pageIndex >= 0 && target.pageIndex < m_layout.size()) {
            float pageY = m_layout[target.pageIndex].yOffset;
            if (target.top.has_value()) {
                pageY += static_cast<float>(target.top.value() * m_zoom);
            }
            float height = m_bounds.bottom - m_bounds.top;
            m_scrollY = std::max(0.0f, std::min(static_cast<float>(pageY), static_cast<float>(m_totalHeight - height)));
            UpdateVisibleTiles();
            InvalidateView();
        }
    }
}

bool PdfViewer::OnSetCursor() {
    HCURSOR cursor = m_interactionManager.GetCursor();
    if (cursor) {
        SetCursor(cursor);
        return true;
    }
    if (m_currentTool == ToolMode::AddText || m_currentTool == ToolMode::EditText) {
        SetCursor(LoadCursor(nullptr, IDC_IBEAM));
        return true;
    }
    return false;
}











bool PdfViewer::UpdatePhysics() {
    if (abs(m_scrollVelocity) > 0.1f) {
        float height = m_bounds.bottom - m_bounds.top;
        m_scrollY += m_scrollVelocity;
        m_scrollY = std::max(0.0f, std::min(m_scrollY, static_cast<float>(m_totalHeight - height)));
        m_scrollVelocity *= 0.85f; // Friction
        if (abs(m_scrollVelocity) < 0.1f) m_scrollVelocity = 0;
        UpdateVisibleTiles();
        return true;
    }
    return false;
}
