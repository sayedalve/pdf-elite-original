#include "DocumentView.h"
#include "../NativeDesignSystem.h"
#include "../controls/IconButton.h"
#include "../controls/SearchBox.h"
#include <string>
#include "../../../utils/Logger.h"

namespace views {

DocumentView::DocumentView() {
    SetBackgroundColor(design::Colors::Background);
    
    // Left Sidebar (Thumbnails)
    m_leftSidebar = std::make_shared<components::ThumbnailViewer>();
    m_leftSidebar->SetBackgroundColor(design::Colors::SurfaceElevated);
    
    // Top Bar (Application level window chrome)
    m_topBar = std::make_shared<framework::Panel>();
    m_topBar->SetBackgroundColor(design::Colors::Background);
    
    auto homeBtn = std::make_shared<controls::IconButton>(L"", controls::IconType::Home);
    homeBtn->SetColors(design::Colors::Background, design::Colors::ControlHover, design::Colors::AccentPrimary);
    homeBtn->SetShowText(false);
    homeBtn->SetOnClick([this]() {
        if (onHomeRequest) onHomeRequest();
    });
    
    m_topBar->AddChild(homeBtn);

    m_tabBar = std::make_shared<components::TabBar>();
    m_topBar->AddChild(m_tabBar);

    // Left vertical mode rail (Home / Comment / Edit / Convert / View / ...)
    m_modeRail = std::make_shared<components::ModeRail>();

    // Top Toolbar
    m_toolbar = std::make_shared<components::Toolbar>();
    m_toolbar->SetBackgroundColor(design::Colors::Surface);

    // PDF Canvas
    m_pdfCanvasContainer = std::make_shared<framework::Panel>();
    m_pdfCanvasContainer->SetBackgroundColor(design::Colors::Background);

    // Right Rail (formerly Status Bar)
    m_statusBar = std::make_shared<components::StatusBar>();
    m_statusBar->SetBackgroundColor(design::Colors::Surface);

    m_propertiesPanel = std::make_shared<components::PropertiesPanel>();
    m_propertiesPanel->SetVisible(false); // Hidden by default
    
    AddChild(m_topBar);
    AddChild(m_modeRail);
    AddChild(m_toolbar);
    AddChild(m_leftSidebar);
    AddChild(m_pdfCanvasContainer);
    AddChild(m_statusBar);
    AddChild(m_propertiesPanel);
}

void DocumentView::Layout(const D2D1_RECT_F& bounds) {
    UIElement::Layout(bounds);
    
    float topBarHeight = design::Metrics::TopbarHeight;
    float toolbarHeight = design::Metrics::ToolbarHeight;
    float modeRailWidth = design::Metrics::SidebarWidth;
    float rightRailWidth = design::Metrics::RightRailWidth;
    float panelWidth = 240.0f; // Panel width if open
    
    // Top Bar (Tabs + Window Controls)
    D2D1_RECT_F topBounds = {bounds.left, bounds.top, bounds.right, bounds.top + topBarHeight};
    m_topBar->Layout(topBounds);
    
    auto& topChildren = m_topBar->GetChildren();
    if (topChildren.size() >= 2) {
        // Home Button (Child 0)
        topChildren[0]->Layout({bounds.left, bounds.top, bounds.left + modeRailWidth, bounds.top + topBarHeight});
        // TabBar (Child 1)
        topChildren[1]->Layout({bounds.left + modeRailWidth, bounds.top, bounds.right - 140.0f, bounds.top + topBarHeight}); 
    }

    // Mode Rail (Left vertical rail)
    float contentLeft = bounds.left + modeRailWidth;
    D2D1_RECT_F railBounds = {bounds.left, bounds.top + topBarHeight, contentLeft, bounds.bottom};
    m_modeRail->Layout(railBounds);

    // Toolbar (Below Top Bar, Right of Mode Rail)
    D2D1_RECT_F tbBounds = {contentLeft, bounds.top + topBarHeight, bounds.right, bounds.top + topBarHeight + toolbarHeight};
    m_toolbar->Layout(tbBounds);

    // Right Rail (Right of canvas, Below Toolbar)
    D2D1_RECT_F rrBounds = {bounds.right - rightRailWidth, bounds.top + topBarHeight + toolbarHeight, bounds.right, bounds.bottom};
    m_statusBar->Layout(rrBounds);

    // PDF Canvas area & Right panels
    float canvasRight = rrBounds.left;
    
    // In the target UI, thumbnails and properties are right-docked panels attached to the right rail.
    // For now we position m_leftSidebar (Thumbnail Viewer) on the right.
    if (m_leftSidebar->IsVisible()) {
        canvasRight -= panelWidth;
        D2D1_RECT_F lsBounds = {canvasRight, bounds.top + topBarHeight + toolbarHeight, rrBounds.left, bounds.bottom};
        m_leftSidebar->Layout(lsBounds);
    } else {
        m_leftSidebar->Layout({0,0,0,0});
    }

    if (m_propertiesPanel->IsVisible()) {
        canvasRight -= design::Layout::RightPanelWidth;
        D2D1_RECT_F propsBounds = {canvasRight, bounds.top + topBarHeight + toolbarHeight, canvasRight + design::Layout::RightPanelWidth, bounds.bottom};
        m_propertiesPanel->Layout(propsBounds);
    }
    
    D2D1_RECT_F canvasBounds = {contentLeft, bounds.top + topBarHeight + toolbarHeight, canvasRight, bounds.bottom};
    m_pdfCanvasContainer->Layout(canvasBounds);
}

void DocumentView::Render(Microsoft::WRL::ComPtr<ID2D1RenderTarget> target) {
    utils::Logger::Log("DOCUMENTVIEW_RENDER_START");
    Panel::Render(target);
    
    // Draw borders
    Microsoft::WRL::ComPtr<ID2D1SolidColorBrush> borderBrush;
    target->CreateSolidColorBrush(design::Colors::BorderSubtle, &borderBrush);

    // Sidebar right border
    target->DrawLine(
        D2D1::Point2F(m_leftSidebar->GetBounds().right, m_leftSidebar->GetBounds().top),
        D2D1::Point2F(m_leftSidebar->GetBounds().right, m_leftSidebar->GetBounds().bottom),
        borderBrush.Get(), 1.0f
    );

    utils::Logger::Log("DOCUMENTVIEW_RENDER_END");
}

} // namespace views
