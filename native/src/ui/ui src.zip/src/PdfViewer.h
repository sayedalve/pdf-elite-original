#pragma once
#include <windows.h>
#include <memory>
#include <vector>
#include "GraphicsDevice.h"
#include "TileCache.h"
#include "RenderWorker.h"
#include "pdf_engine/IDocument.h"
#include "../../pdf_engine/src/SearchEngine.h"
#include "interaction/InteractionManager.h"
#include <map>

struct PageLayout {
    int index;
    float yOffset; // Scaled offset from the top
    float width;   // Scaled width
    float height;  // Scaled height
};

#include "pdf_engine/IAnnotation.h"

enum class ToolMode {
    Select,
    Pan,
    Highlight,
    Underline,
    Strikeout,
    Rectangle,
    Ellipse,
    Line,
    Arrow,
    Ink,
    FreeText,
    StickyNote,
    InsertImage,
    AddText,
    AddImage,
    EditText
};

enum class LayoutMode {
    Continuous,
    SinglePage
};

class PdfViewer {
public:
    PdfViewer();
    ~PdfViewer();

    bool Initialize(HWND parentHwnd);
    void Render(ComPtr<ID2D1HwndRenderTarget> target, const D2D1_RECT_F& bounds);
    
    // Core document API
    void SetDocument(std::shared_ptr<IDocument> doc);
    std::shared_ptr<IDocument> GetDocument() const { return m_doc; }
    ToolMode GetToolMode() const { return m_currentTool; }
    void SetToolMode(ToolMode mode);

    // Interaction access
    ui::interaction::InteractionManager& GetInteractionManager();
    TileCache* GetTileCache() { return m_tileCache.get(); }
    void ReloadInteractableObjects();
    void InvalidateView();
    
    // Page Operations UI Hooks
    void InsertBlankPage(int index, double width, double height);
    void DeletePage(int index);
    void DuplicatePage(int index);
    void MovePage(int sourceIndex, int destIndex);
    void RotatePage(int index, int rotationDegrees);
    void ExecuteMacroStructureChange(std::unique_ptr<pdf_engine::ICommand> cmd);
    
    void TriggerInsertImage();
    void PasteImage();
    
    void OnScroll(float deltaY);
    void OnThumbnailScroll(int deltaY);
    void OnZoom(double deltaZoom, double mouseX = -1, double mouseY = -1);
    void ZoomToFitWidth();
    void ZoomToFitPage();
    double GetZoom() const { return m_zoom; }
    void OnResize(const D2D1_RECT_F& bounds);
    
    void GoToPage(int pageIndex);
    void NavigateTo(const pdf_engine::NavigationTarget& target);
    RenderWorker* GetRenderWorker() { return m_renderWorker.get(); }
    int GetCurrentPage() const {
        if (m_layoutMode == LayoutMode::SinglePage) return m_currentPage;
        for (const auto& page : m_layout) {
            if (page.yOffset + page.height / 2 > m_scrollY) {
                return page.index;
            }
        }
        if (!m_layout.empty()) return m_layout.back().index;
        return 0;
    }
    
    LayoutMode GetLayoutMode() const { return m_layoutMode; }
    void SetLayoutMode(LayoutMode mode);

    void RenderThumbnails(ComPtr<ID2D1HwndRenderTarget> target, const D2D1_RECT_F& bounds);

    bool UpdatePhysics();
    void OnLButtonDown(int x, int y);
    void OnLButtonUp(int x, int y);
    void OnLButtonDoubleClick(int x, int y);
    void OnRButtonUp(int x, int y);
    void OnMouseMove(int x, int y);
    bool OnSetCursor();
    void OnKeyDown(WPARAM wParam);
    void OnChar(WPARAM wParam);
    void OnCommand(WPARAM wParam, LPARAM lParam);
    void CopySelection();
    
    void SetSearchResults(const std::vector<pdf_engine::SearchResult>& results, int activeIndex);
    
    void OnTileReady(RenderResult* result, ComPtr<ID2D1HwndRenderTarget> target);

private:
    void UpdateVisibleTiles();
    void RecalculateLayout();

    // Rebuilds view state after a structural change to the document (page
    // added / removed / moved / rotated) WITHOUT recreating the render worker
    // or re-initialising forms, so the existing worker (and any sidebar holding
    // a pointer to it) stays valid. Clamps the current page, rebuilds the page
    // layout, invalidates cached tiles and interaction objects, and repaints.
    void RefreshAfterStructureChange();

    // Tears down the render worker and every object derived from the current
    // document (interaction wrappers, text pages, active pages, links) in an
    // order that never lets a PdfPage / PdfTextPage / annotation outlive its
    // parent PdfDocument. Safe to call with no document loaded.
    void ReleaseDocumentState();

    ITextPage* GetTextPage(int pageIndex);
    void RenderSelection(ComPtr<ID2D1HwndRenderTarget> target, const PageLayout& page, float pageScreenX, float pageScreenY);
    void RenderSearchResults(ComPtr<ID2D1HwndRenderTarget> target, const PageLayout& page, float pageScreenX, float pageScreenY);

    HWND m_hwnd;
    std::shared_ptr<IDocument> m_doc;
    
    std::unique_ptr<TileCache> m_tileCache;
    std::unique_ptr<RenderWorker> m_renderWorker;

    std::vector<PageLayout> m_layout;
    float m_totalHeight = 0;
    
    std::vector<PageLayout> m_thumbnailLayout;
    float m_totalThumbnailHeight = 0;
    float m_thumbnailScrollY = 0;
    D2D1_RECT_F m_thumbnailBounds = {0,0,0,0};

    int m_scrollX = 0;
    float m_scrollY = 0;
    float m_scrollVelocity = 0;
    float m_scrollAccumulator = 0.0f;
    double m_zoom = 1.0;
    uint64_t m_generation = 0;
    D2D1_RECT_F m_bounds = {0, 0, 0, 0};
    
    const int TILE_SIZE = 768;
    const int OVERLAP_PX = 5;

    struct SelectionState {
        bool isSelecting = false;
        int startPage = -1;
        int startChar = -1;
        int endPage = -1;
        int endChar = -1;
    } m_selection;
    
    std::map<int, std::unique_ptr<ITextPage>> m_textPages;
    std::map<int, std::shared_ptr<IPage>> m_textPages_pages;
    std::map<int, std::shared_ptr<IPage>> m_activePages;
    
    std::vector<pdf_engine::SearchResult> m_searchResults;
    int m_activeSearchIndex = -1;
    
    ui::interaction::InteractionManager m_interactionManager;
    
    // Text Annotation state
    HWND m_editControl = nullptr;
    WNDPROC m_oldEditProc = nullptr;
    ToolMode m_editTool = ToolMode::Select;
    int m_editPageIndex = -1;
    PointF m_editStartPt = {0,0};
    
    // Image insertion state
    bool m_isInsertingImage = false;
    int m_insertImagePage = -1;
    PointF m_insertImageStartPt;
    std::vector<uint8_t> m_pendingImageData;
    UINT m_pendingImageWidth = 0;
    UINT m_pendingImageHeight = 0;

    // Links
    std::map<int, std::vector<pdf_engine::PdfLink>> m_pageLinks;
    std::optional<pdf_engine::PdfLink> m_hoveredLink;
    
    // Annotation creation state (for Line, Arrow, Rectangle etc)
    bool m_isCreatingAnnotation = false;
    int m_createAnnotationPage = -1;
    PointF m_createAnnotationStartPdf;
    PointF m_createAnnotationCurrentPdf;

    // Tool state
    ToolMode m_currentTool = ToolMode::Select;
    
    LayoutMode m_layoutMode = LayoutMode::Continuous;
    int m_currentPage = 0;
};


