#include "SearchBar.h"
#include <commctrl.h>
#include <windowsx.h>

#pragma comment(lib, "comctl32.lib")

#define ID_EDIT 101
#define ID_NEXT 102
#define ID_PREV 103
#define ID_CLOSE 104

SearchBar::SearchBar() : m_className(L"PdfEliteSearchBar") {}

SearchBar::~SearchBar() {
    if (m_hwnd) DestroyWindow(m_hwnd);
}

bool SearchBar::Create(HWND parentHwnd) {
    m_parentHwnd = parentHwnd;
    
    WNDCLASS wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = GetModuleHandle(nullptr);
    wc.lpszClassName = m_className.c_str();
    wc.hbrBackground = (HBRUSH)GetStockObject(NULL_BRUSH); // Transparent or match top bar
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    RegisterClass(&wc);

    // Create a child window within the parent
    m_hwnd = CreateWindowEx(
        0, m_className.c_str(), L"",
        WS_CHILD | WS_CLIPSIBLINGS,
        0, 0, 350, 40,
        parentHwnd, nullptr, GetModuleHandle(nullptr), this
    );

    if (!m_hwnd) return false;

    // Create child controls
    m_editHwnd = CreateWindowEx(
        WS_EX_CLIENTEDGE, L"EDIT", L"",
        WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
        0, 4, 180, 24,
        m_hwnd, (HMENU)ID_EDIT, GetModuleHandle(nullptr), nullptr
    );
    
    SetWindowSubclass(m_editHwnd, EditSubclassProc, 0, (DWORD_PTR)this);

    m_labelHwnd = CreateWindowEx(
        0, L"STATIC", L"0/0",
        WS_CHILD | WS_VISIBLE | SS_CENTERIMAGE | SS_RIGHT,
        185, 4, 50, 24,
        m_hwnd, nullptr, GetModuleHandle(nullptr), nullptr
    );

    m_prevBtn = CreateWindowEx(
        0, L"BUTTON", L"<",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        240, 4, 24, 24,
        m_hwnd, (HMENU)ID_PREV, GetModuleHandle(nullptr), nullptr
    );

    m_nextBtn = CreateWindowEx(
        0, L"BUTTON", L">",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        268, 4, 24, 24,
        m_hwnd, (HMENU)ID_NEXT, GetModuleHandle(nullptr), nullptr
    );

    m_closeBtn = CreateWindowEx(
        0, L"BUTTON", L"X",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        296, 4, 24, 24,
        m_hwnd, (HMENU)ID_CLOSE, GetModuleHandle(nullptr), nullptr
    );

    HFONT hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
    SendMessage(m_editHwnd, WM_SETFONT, (WPARAM)hFont, FALSE);
    SendMessage(m_labelHwnd, WM_SETFONT, (WPARAM)hFont, FALSE);
    SendMessage(m_prevBtn, WM_SETFONT, (WPARAM)hFont, FALSE);
    SendMessage(m_nextBtn, WM_SETFONT, (WPARAM)hFont, FALSE);
    SendMessage(m_closeBtn, WM_SETFONT, (WPARAM)hFont, FALSE);

    return true;
}

void SearchBar::Show() {
    if (m_hwnd) ShowWindow(m_hwnd, SW_SHOWNA);
}

void SearchBar::SetBounds(int x, int y, int width, int height) {
    if (m_hwnd) {
        SetWindowPos(m_hwnd, nullptr, x, y, width, height, SWP_NOZORDER | SWP_NOACTIVATE);
    }
}

void SearchBar::Hide() {
    if (m_hwnd) ShowWindow(m_hwnd, SW_HIDE);
}

bool SearchBar::IsVisible() const {
    return m_hwnd && IsWindowVisible(m_hwnd);
}

void SearchBar::SetFocus() {
    if (m_editHwnd) ::SetFocus(m_editHwnd);
}

void SearchBar::SetResultCount(int count, int current) {
    if (m_labelHwnd) {
        std::wstring text = std::to_wstring(current) + L"/" + std::to_wstring(count);
        SetWindowText(m_labelHwnd, text.c_str());
    }
}

LRESULT CALLBACK SearchBar::EditSubclassProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData) {
    UNREFERENCED_PARAMETER(uIdSubclass);
    SearchBar* pThis = reinterpret_cast<SearchBar*>(dwRefData);
    if (uMsg == WM_KEYDOWN) {
        if (wParam == VK_RETURN) {
            if (GetKeyState(VK_SHIFT) & 0x8000) {
                if (pThis->m_onPrev) pThis->m_onPrev();
            } else {
                if (pThis->m_onNext) pThis->m_onNext();
            }
            return 0;
        } else if (wParam == VK_ESCAPE) {
            if (pThis->m_onClose) pThis->m_onClose();
            return 0;
        }
    } else if (uMsg == WM_CHAR && wParam == VK_RETURN) {
        return 0; // prevent ding sound
    } else if (uMsg == WM_KEYUP) {
        // Trigger search on typing
        wchar_t buf[256];
        GetWindowText(hWnd, buf, 256);
        if (pThis->m_onSearch && wParam != VK_RETURN && wParam != VK_ESCAPE && wParam != VK_SHIFT) {
            pThis->m_onSearch(buf);
        }
    }
    return DefSubclassProc(hWnd, uMsg, wParam, lParam);
}

LRESULT CALLBACK SearchBar::WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    SearchBar* pThis = nullptr;
    if (uMsg == WM_NCCREATE) {
        CREATESTRUCT* pCreate = reinterpret_cast<CREATESTRUCT*>(lParam);
        pThis = reinterpret_cast<SearchBar*>(pCreate->lpCreateParams);
        SetWindowLongPtr(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(pThis));
        pThis->m_hwnd = hwnd;
    } else {
        pThis = reinterpret_cast<SearchBar*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
    }
    if (pThis) return pThis->HandleMessage(uMsg, wParam, lParam);
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

LRESULT SearchBar::HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_COMMAND: {
        int wmId = LOWORD(wParam);
        if (wmId == ID_NEXT && m_onNext) m_onNext();
        else if (wmId == ID_PREV && m_onPrev) m_onPrev();
        else if (wmId == ID_CLOSE && m_onClose) m_onClose();
        return 0;
    }
    }
    return DefWindowProc(m_hwnd, uMsg, wParam, lParam);
}
