#pragma once
#include <d2d1_1.h>
#include <dwrite_3.h>
#include <wrl/client.h>

namespace design {

struct Colors {
    static constexpr D2D1_COLOR_F Background = {11/255.0f, 13/255.0f, 18/255.0f, 1.0f}; // #0B0D12
    static constexpr D2D1_COLOR_F Workspace = {11/255.0f, 13/255.0f, 18/255.0f, 1.0f}; // #0B0D12
    static constexpr D2D1_COLOR_F Surface = {17/255.0f, 19/255.0f, 26/255.0f, 1.0f}; // #11131A
    static constexpr D2D1_COLOR_F SurfaceElevated = {23/255.0f, 26/255.0f, 35/255.0f, 1.0f}; // #171A23
    static constexpr D2D1_COLOR_F SurfaceHover = {30/255.0f, 34/255.0f, 47/255.0f, 1.0f}; // #1E222F
    static constexpr D2D1_COLOR_F SurfaceActiveTab = {38/255.0f, 42/255.0f, 62/255.0f, 1.0f}; // #262A3E
    static constexpr D2D1_COLOR_F SurfacePressed = {35/255.0f, 39/255.0f, 52/255.0f, 1.0f};
    
    static constexpr D2D1_COLOR_F Control = {30/255.0f, 34/255.0f, 47/255.0f, 1.0f}; 
    static constexpr D2D1_COLOR_F ControlHover = {255/255.0f, 255/255.0f, 255/255.0f, 0.06f}; 
    static constexpr D2D1_COLOR_F ControlPressed = {255/255.0f, 255/255.0f, 255/255.0f, 0.03f}; 
    static constexpr D2D1_COLOR_F ControlActive = {59/255.0f, 91/255.0f, 255/255.0f, 0.25f}; // #3B5BFF with 25% opacity
    
    static constexpr D2D1_COLOR_F AccentPrimary = {59/255.0f, 91/255.0f, 255/255.0f, 1.0f}; // #3B5BFF
    static constexpr D2D1_COLOR_F AccentHover = {79/255.0f, 125/255.0f, 255/255.0f, 1.0f}; // #4F7DFF
    static constexpr D2D1_COLOR_F AccentPressed = {40/255.0f, 70/255.0f, 200/255.0f, 1.0f};
    
    static constexpr D2D1_COLOR_F TextPrimary = {245/255.0f, 246/255.0f, 247/255.0f, 1.0f}; // #F5F6F7
    static constexpr D2D1_COLOR_F TextSecondary = {139/255.0f, 143/255.0f, 163/255.0f, 1.0f}; // #8B8FA3
    static constexpr D2D1_COLOR_F TextMuted = {92/255.0f, 96/255.0f, 117/255.0f, 1.0f}; // #5C6075
    static constexpr D2D1_COLOR_F TextDisabled = {139/255.0f, 143/255.0f, 163/255.0f, 0.5f};
    
    static constexpr D2D1_COLOR_F Border = {255/255.0f, 255/255.0f, 255/255.0f, 0.12f};
    static constexpr D2D1_COLOR_F BorderSubtle = {255/255.0f, 255/255.0f, 255/255.0f, 0.06f};
    static constexpr D2D1_COLOR_F BorderStrong = {255/255.0f, 255/255.0f, 255/255.0f, 0.18f};
    static constexpr D2D1_COLOR_F Focus = {59/255.0f, 130/255.0f, 246/255.0f, 0.5f};
    
    static constexpr D2D1_COLOR_F Success = {52/255.0f, 211/255.0f, 153/255.0f, 1.0f};
    static constexpr D2D1_COLOR_F Warning = {251/255.0f, 146/255.0f, 60/255.0f, 1.0f};
    static constexpr D2D1_COLOR_F Error = {248/255.0f, 113/255.0f, 113/255.0f, 1.0f};
};

struct Spacing {
    static constexpr float XSmall = 4.0f;
    static constexpr float Small = 8.0f;
    static constexpr float Medium1 = 12.0f;
    static constexpr float Medium2 = 16.0f;
    static constexpr float Large1 = 20.0f;
    static constexpr float Large2 = 24.0f;
    static constexpr float XLarge = 32.0f;
    static constexpr float XXLarge = 40.0f;
    static constexpr float XXXLarge = 48.0f;
};

struct Radius {
    static constexpr float R4 = 4.0f;
    static constexpr float R6 = 6.0f;
    static constexpr float R8 = 8.0f;
    static constexpr float R10 = 10.0f;
    static constexpr float R12 = 12.0f;
    static constexpr float R16 = 16.0f;
};

struct Metrics {
    static constexpr float SidebarWidth = 68.0f;
    static constexpr float RightRailWidth = 48.0f;
    static constexpr float TopbarHeight = 44.0f;
    static constexpr float ToolbarHeight = 48.0f;
    static constexpr float ContentPadding = Spacing::Large2;
    static constexpr float SectionGap = Spacing::Large2;
    
    static constexpr float ControlHeightLarge = 40.0f;
    static constexpr float ControlHeightNormal = 32.0f;
    static constexpr float ControlHeightSmall = 24.0f;
    
    static constexpr float IconSizeLarge = 24.0f;
    static constexpr float IconSizeMedium = 20.0f;
    static constexpr float IconSizeSmall = 16.0f;
};

struct TypographySize {
    static constexpr float AppTitle = 24.0f;
    static constexpr float PageTitle = 20.0f;
    static constexpr float SectionHeading = 16.0f;
    static constexpr float Body = 14.0f;
    static constexpr float Secondary = 13.0f;
    static constexpr float Toolbar = 13.0f;
    static constexpr float Navigation = 14.0f;
    static constexpr float Metadata = 12.0f;
    static constexpr float Caption = 11.0f;
    static constexpr float Tooltip = 12.0f;
};

struct Layout {
    static constexpr float TopbarHeight = 44.0f;
    static constexpr float TopBarHeight = 44.0f;
    static constexpr float ContentPadding = 32.0f;
    static constexpr float SectionGap = 24.0f;
    static constexpr float ControlHeightNormal = 32.0f;
    static constexpr float ControlHeightLarge = 40.0f;
    static constexpr float ToolbarHeight = 48.0f;
    static constexpr float SidebarWidth = 68.0f;
    static constexpr float RightRailWidth = 48.0f;
    static constexpr float RightPanelWidth = 280.0f;
    static constexpr float SearchBoxWidth = 320.0f;
    static constexpr float SearchBoxHeight = 32.0f;
    static constexpr float ButtonSizeSmall = 24.0f;
    static constexpr float ButtonSizeNormal = 32.0f;
    static constexpr float ButtonSizeLarge = 40.0f;
    static constexpr float IconSizeSmall = 16.0f;
    static constexpr float IconSizeNormal = 20.0f;
    static constexpr float IconSizeLarge = 24.0f;
};

class FontManager {
public:
    static FontManager& Instance();
    
    void Initialize(IDWriteFactory* writeFactory);
    
    IDWriteTextFormat* GetAppTitle() const { return m_appTitle.Get(); }
    IDWriteTextFormat* GetPageTitle() const { return m_pageTitle.Get(); }
    IDWriteTextFormat* GetSectionHeading() const { return m_sectionHeading.Get(); }
    IDWriteTextFormat* GetBody() const { return m_body.Get(); }
    IDWriteTextFormat* GetSecondary() const { return m_secondary.Get(); }
    IDWriteTextFormat* GetToolbar() const { return m_toolbar.Get(); }
    IDWriteTextFormat* GetNavigation() const { return m_navigation.Get(); }
    IDWriteTextFormat* GetMetadata() const { return m_metadata.Get(); }
    IDWriteTextFormat* GetCaption() const { return m_caption.Get(); }
    IDWriteTextFormat* GetTooltip() const { return m_tooltip.Get(); }

private:
    FontManager() = default;
    
    Microsoft::WRL::ComPtr<IDWriteTextFormat> m_appTitle;
    Microsoft::WRL::ComPtr<IDWriteTextFormat> m_pageTitle;
    Microsoft::WRL::ComPtr<IDWriteTextFormat> m_sectionHeading;
    Microsoft::WRL::ComPtr<IDWriteTextFormat> m_body;
    Microsoft::WRL::ComPtr<IDWriteTextFormat> m_secondary;
    Microsoft::WRL::ComPtr<IDWriteTextFormat> m_toolbar;
    Microsoft::WRL::ComPtr<IDWriteTextFormat> m_navigation;
    Microsoft::WRL::ComPtr<IDWriteTextFormat> m_metadata;
    Microsoft::WRL::ComPtr<IDWriteTextFormat> m_caption;
    Microsoft::WRL::ComPtr<IDWriteTextFormat> m_tooltip;
};

} // namespace design
