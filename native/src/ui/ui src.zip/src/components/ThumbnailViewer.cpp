﻿#include "ThumbnailViewer.h"
#include "../RenderWorker.h"
#include "../NativeDesignSystem.h"
#include <algorithm>
#include <string>

namespace components {

ThumbnailViewer::ThumbnailViewer() {
    SetBackgroundColor(design::Colors::SurfaceElevated);
}

void ThumbnailViewer::SetDocument(std::shared_ptr<IDocument> doc, RenderWorker* worker) {
    m_doc = doc;
    m_worker = worker;
    m_scrollY = 0.0f;
    m_activePage = 0;
    m_selectedPages.clear();
    m_generation++;
    m_cache.InvalidateAll();
    m_thumbs.clear();
    if (m_doc) {
        UpdateLayoutParams();
    }
}

void ThumbnailViewer::SetActivePage(int pageIndex) {
    if (m_activePage != pageIndex) {
        m_activePage = pageIndex;
        m_selectedPages.clear();
        m_selectedPages.insert(pageIndex);
        if (onSelectionChanged) onSelectionChanged(m_selectedPages);
        
        if (m_activePage >= 0 && m_activePage < (int)m_thumbs.size()) {
            auto& t = m_thumbs[m_activePage];
            float viewHeight = GetBounds().bottom - GetBounds().top;
            if (t.bounds.top - m_scrollY < 0) {
                m_scrollY = t.bounds.top - m_padding;
            } else if (t.bounds.bottom - m_scrollY > viewHeight) {
                m_scrollY = t.bounds.bottom - viewHeight + m_padding;
            }
            m_scrollY = std::max(0.0f, std::min(m_scrollY, m_maxScrollY));
        }
    }
}

void ThumbnailViewer::ClearSelection() {
    m_selectedPages.clear();
    if (onSelectionChanged) onSelectionChanged(m_selectedPages);
}

void ThumbnailViewer::UpdateLayoutParams() {
    m_thumbs.clear();
    if (!m_doc) return;
    
    int numPages = m_doc->PageCount();
    float currentY = m_padding;
    float viewWidth = GetBounds().right - GetBounds().left;
    float contentX = (viewWidth - m_thumbnailWidth) / 2.0f;
    if (contentX < m_padding) contentX = m_padding;
    
    for (int i = 0; i < numPages; ++i) {
        auto sz = m_doc->GetPageSize(i);
        float aspect = (sz.height > 0) ? (sz.width / sz.height) : 1.0f;
        float height = m_thumbnailWidth / aspect;
        
        ThumbData td;
        td.pageIndex = i;
        td.height = height;
        td.bounds = { contentX, currentY, contentX + m_thumbnailWidth, currentY + height };
        m_thumbs.push_back(td);
        
        // extra space for page number text
        currentY += height + 24.0f + m_padding;
    }
    
    float viewHeight = GetBounds().bottom - GetBounds().top;
    m_maxScrollY = std::max(0.0f, currentY - viewHeight);
}

void ThumbnailViewer::Layout(const D2D1_RECT_F& bounds) {
    UIElement::Layout(bounds);
    UpdateLayoutParams();
    RequestVisibleThumbnails();
}

void ThumbnailViewer::RequestVisibleThumbnails() {
    if (!m_worker || !m_doc) return;
    
    float viewHeight = GetBounds().bottom - GetBounds().top;
    for (const auto& t : m_thumbs) {
        float top = t.bounds.top - m_scrollY;
        float bottom = t.bounds.bottom - m_scrollY;
        
        if (bottom > -30 && top < viewHeight + 30) { // Slight bleed
            float dpiScale = m_thumbnailWidth / m_doc->GetPageSize(t.pageIndex).width;
            TileKey key;
            key.documentGeneration = m_generation;
            key.pageIndex = t.pageIndex;
            key.zoom = 1.0;
            key.dpiScale = dpiScale;
            key.tileX = 0;
            key.tileY = 0;
            key.tileWidth = static_cast<int>(m_thumbnailWidth);
            key.tileHeight = static_cast<int>(t.height);
            
            if (!m_cache.Get(key)) {
                RenderTask task;
                task.generation = m_generation;
                task.key = key;
                task.startX = 0;
                task.startY = 0;
                task.width = key.tileWidth;
                task.height = key.tileHeight;
                task.dpiScale = dpiScale;
                task.priority = 2; 
                m_worker->Enqueue(task);
            }
        }
    }
}

void ThumbnailViewer::OnTileReady(const RenderResult* result, Microsoft::WRL::ComPtr<ID2D1RenderTarget> target) {
    if (result->generation == m_generation && result->key.zoom == 1.0f && result->key.tileX == 0 && result->key.tileY == 0) {
        ComPtr<ID2D1Bitmap> bitmap;
        D2D1_BITMAP_PROPERTIES props = {};
        props.pixelFormat.format = DXGI_FORMAT_B8G8R8A8_UNORM;
        props.pixelFormat.alphaMode = D2D1_ALPHA_MODE_PREMULTIPLIED;
        props.dpiX = 96.0f;
        props.dpiY = 96.0f;
        target->CreateBitmap(
            D2D1::SizeU(result->width, result->height),
            result->buffer.data(),
            result->width * 4,
            props,
            &bitmap
        );
        m_cache.Put(result->key, bitmap, result->buffer.size());
    }
}

void ThumbnailViewer::OnMouseWheel(float delta) {
    m_scrollY -= delta * 50.0f;
    m_scrollY = std::max(0.0f, std::min(m_scrollY, m_maxScrollY));
    RequestVisibleThumbnails();
}

void ThumbnailViewer::OnMouseDown(float x, float y) {
    (void)x;
    float py = y - GetBounds().top + m_scrollY;
    
    bool ctrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
    bool shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
    
    for (const auto& t : m_thumbs) {
        if (py >= t.bounds.top && py <= t.bounds.bottom) {
            int page = t.pageIndex;
            
            if (ctrl) {
                if (m_selectedPages.count(page)) {
                    m_selectedPages.erase(page);
                } else {
                    m_selectedPages.insert(page);
                    m_activePage = page;
                }
            } else if (shift && !m_selectedPages.empty()) {
                int start = m_activePage;
                int end = page;
                if (start > end) std::swap(start, end);
                m_selectedPages.clear();
                for (int i = start; i <= end; ++i) m_selectedPages.insert(i);
            } else {
                m_selectedPages.clear();
                m_selectedPages.insert(page);
                m_activePage = page;
                if (onPageSelected) onPageSelected(page);
            }
            
            if (onSelectionChanged) onSelectionChanged(m_selectedPages);
            
            m_isDragging = true;
            m_dragSourcePage = page;
            m_dragStartY = py;
            m_dragInsertIndex = -1;
            SetCapture(nullptr); // Just concept, we use mouse moves
            return;
        }
    }
    // Clicked outside
    ClearSelection();
}

int ThumbnailViewer::GetInsertIndexFromY(float py) {
    if (m_thumbs.empty()) return 0;
    if (py < m_thumbs[0].bounds.top) return 0;
    
    for (size_t i = 0; i < m_thumbs.size(); ++i) {
        float midY = m_thumbs[i].bounds.top + m_thumbs[i].height / 2.0f;
        if (py < midY) return static_cast<int>(i);
    }
    return static_cast<int>(m_thumbs.size());
}

void ThumbnailViewer::OnMouseMove(float x, float y) {
    (void)x;
    if (m_isDragging) {
        float py = y - GetBounds().top + m_scrollY;
        if (std::abs(py - m_dragStartY) > 5.0f) {
            m_dragInsertIndex = GetInsertIndexFromY(py);
        }
    }
}

void ThumbnailViewer::OnMouseUp(float x, float y) {
    (void)x;
    (void)y;
    if (m_isDragging) {
        if (m_dragInsertIndex != -1 && m_dragSourcePage != -1) {
            if (onPageMoved) {
                onPageMoved(m_dragSourcePage, m_dragInsertIndex);
            }
        }
        m_isDragging = false;
        m_dragInsertIndex = -1;
    }
}

void ThumbnailViewer::Render(ComPtr<ID2D1RenderTarget> target) {
    Panel::Render(target);
    if (!m_doc) return;
    
    float viewHeight = GetBounds().bottom - GetBounds().top;
    
    ComPtr<ID2D1SolidColorBrush> bgBrush, borderBrush, activeBrush, textBrush;
    target->CreateSolidColorBrush(design::Colors::SurfaceElevated, &bgBrush);
    target->CreateSolidColorBrush(design::Colors::Border, &borderBrush);
    target->CreateSolidColorBrush(design::Colors::AccentPrimary, &activeBrush); 
    target->CreateSolidColorBrush(design::Colors::TextPrimary, &textBrush);
    target->FillRectangle(m_bounds, bgBrush.Get());
    
    auto textFormat = design::FontManager::Instance().GetMetadata();
    if (textFormat) {
        textFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
    }
    
    for (const auto& t : m_thumbs) {
        float top = t.bounds.top - m_scrollY;
        float bottom = t.bounds.bottom - m_scrollY;
        
        if (bottom > -30 && top < viewHeight + 30) {
            D2D1_RECT_F rect = {
                GetBounds().left + t.bounds.left,
                GetBounds().top + top,
                GetBounds().left + t.bounds.right,
                GetBounds().top + bottom
            };
            
            if (m_selectedPages.count(t.pageIndex)) {
                D2D1_RECT_F ringRect = { rect.left - 4, rect.top - 4, rect.right + 4, rect.bottom + 4 };
                target->DrawRectangle(ringRect, activeBrush.Get(), 2.0f);
            }
            
            TileKey key;
            key.documentGeneration = m_generation;
            key.pageIndex = t.pageIndex;
            key.zoom = 1.0;
            key.dpiScale = m_thumbnailWidth / m_doc->GetPageSize(t.pageIndex).width;
            key.tileX = 0;
            key.tileY = 0;
            key.tileWidth = static_cast<int>(m_thumbnailWidth);
            key.tileHeight = static_cast<int>(t.height);
            
            auto bmp = m_cache.Get(key);
            if (bmp) {
                target->DrawBitmap(bmp.Get(), rect);
            } else {
                target->FillRectangle(rect, borderBrush.Get());
            }
            target->DrawRectangle(rect, borderBrush.Get(), 1.0f);
            
            // Draw page number
            std::wstring pageNum = std::to_wstring(t.pageIndex + 1);
            D2D1_RECT_F textRect = { rect.left, rect.bottom + 4.0f, rect.right, rect.bottom + 24.0f };
            target->DrawTextW(pageNum.c_str(), static_cast<UINT32>(pageNum.length()), textFormat, textRect, textBrush.Get());
        }
    }
    
    // Draw drag indicator
    if (m_isDragging && m_dragInsertIndex != -1) {
        float insertY = 0;
        if (m_dragInsertIndex < (int)m_thumbs.size()) {
            insertY = m_thumbs[m_dragInsertIndex].bounds.top - m_padding / 2.0f;
        } else if (!m_thumbs.empty()) {
            insertY = m_thumbs.back().bounds.bottom + 24.0f + m_padding / 2.0f;
        }
        
        insertY = GetBounds().top + insertY - m_scrollY;
        
        if (insertY > GetBounds().top && insertY < GetBounds().bottom) {
            D2D1_POINT_2F p1 = { GetBounds().left + 10, insertY };
            D2D1_POINT_2F p2 = { GetBounds().right - 10, insertY };
            target->DrawLine(p1, p2, activeBrush.Get(), 2.0f);
        }
    }
}

} // namespace components

