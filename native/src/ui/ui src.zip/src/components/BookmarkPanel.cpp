#include "BookmarkPanel.h"
#include <windowsx.h>

namespace components {

BookmarkPanel::BookmarkPanel() {
}

BookmarkPanel::~BookmarkPanel() {
    if (m_hwndTree) DestroyWindow(m_hwndTree);
    if (m_hwndContainer) DestroyWindow(m_hwndContainer);
}

LRESULT CALLBACK BookmarkPanel::ContainerWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    BookmarkPanel* pThis = nullptr;
    if (uMsg == WM_NCCREATE) {
        CREATESTRUCT* pCreate = reinterpret_cast<CREATESTRUCT*>(lParam);
        pThis = reinterpret_cast<BookmarkPanel*>(pCreate->lpCreateParams);
        SetWindowLongPtr(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(pThis));
    } else {
        pThis = reinterpret_cast<BookmarkPanel*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
    }
    
    if (pThis) {
        switch (uMsg) {
        case WM_SIZE:
            if (pThis->m_hwndTree) {
                SetWindowPos(pThis->m_hwndTree, nullptr, 0, 0, LOWORD(lParam), HIWORD(lParam), SWP_NOZORDER);
            }
            return 0;
        case WM_NOTIFY: {
            LPNMHDR lpnmh = (LPNMHDR)lParam;
            if (lpnmh->hwndFrom == pThis->m_hwndTree && lpnmh->code == TVN_SELCHANGEDW) {
                LPNMTREEVIEWW lpnmtv = reinterpret_cast<LPNMTREEVIEWW>(lParam);
                size_t destIndex = static_cast<size_t>(lpnmtv->itemNew.lParam);
                if (destIndex != (size_t)-1 && destIndex < pThis->m_destinations.size()) {
                    if (pThis->m_onNavigate) {
                        pThis->m_onNavigate(pThis->m_destinations[destIndex]);
                    }
                }
            }
            return 0;
        }
        }
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

bool BookmarkPanel::Create(HWND parentHwnd) {
    m_parentHwnd = parentHwnd;
    
    WNDCLASS wc = {0};
    wc.lpfnWndProc = ContainerWndProc;
    wc.hInstance = GetModuleHandle(nullptr);
    wc.lpszClassName = TEXT("BookmarkPanelContainer");
    RegisterClass(&wc); // Safe to fail if already registered
    
    m_hwndContainer = CreateWindowEx(
        0, wc.lpszClassName, TEXT(""),
        WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN,
        0, 0, 100, 100, parentHwnd, nullptr, wc.hInstance, this);
        
    if (!m_hwndContainer) return false;
    
    // Create TreeView control
    m_hwndTree = CreateWindowEx(
        0, WC_TREEVIEWW, TEXT("Tree View"),
        WS_VISIBLE | WS_CHILD | WS_BORDER | TVS_HASLINES | TVS_LINESATROOT | TVS_HASBUTTONS | TVS_SHOWSELALWAYS,
        0, 0, 100, 100, m_hwndContainer, nullptr, wc.hInstance, nullptr);

    return m_hwndTree != nullptr;
}

void BookmarkPanel::Show() {
    if (m_hwndContainer) ShowWindow(m_hwndContainer, SW_SHOW);
}

void BookmarkPanel::Hide() {
    if (m_hwndContainer) ShowWindow(m_hwndContainer, SW_HIDE);
}

void BookmarkPanel::SetBounds(int x, int y, int width, int height) {
    if (m_hwndContainer) {
        SetWindowPos(m_hwndContainer, nullptr, x, y, width, height, SWP_NOZORDER);
    }
}

bool BookmarkPanel::IsVisible() const {
    return m_hwndContainer && IsWindowVisible(m_hwndContainer);
}

void BookmarkPanel::LoadBookmarks(const std::vector<std::unique_ptr<pdf_engine::PdfBookmark>>& bookmarks) {
    if (!m_hwndTree) return;
    
    TreeView_DeleteAllItems(m_hwndTree);
    m_destinations.clear();
    
    PopulateTree(TVI_ROOT, bookmarks);
}

void BookmarkPanel::PopulateTree(HTREEITEM hParent, const std::vector<std::unique_ptr<pdf_engine::PdfBookmark>>& bookmarks) {
    for (const auto& bm : bookmarks) {
        TVITEMW tvi = {0};
        tvi.mask = TVIF_TEXT | TVIF_PARAM;
        tvi.pszText = const_cast<LPWSTR>(bm->title.c_str());
        tvi.cchTextMax = static_cast<int>(bm->title.length());
        
        size_t destIndex = (size_t)-1;
        if (bm->destination) {
            destIndex = m_destinations.size();
            m_destinations.push_back(bm->destination.value());
        }
        tvi.lParam = static_cast<LPARAM>(destIndex);

        TVINSERTSTRUCTW tvins = {0};
        tvins.item = tvi;
        tvins.hInsertAfter = TVI_LAST;
        tvins.hParent = hParent;
        
        HTREEITEM hItem = reinterpret_cast<HTREEITEM>(SendMessageW(m_hwndTree, TVM_INSERTITEMW, 0, reinterpret_cast<LPARAM>(&tvins)));
        
        if (!bm->children.empty()) {
            PopulateTree(hItem, bm->children);
        }
        
        if (bm->expanded) {
            SendMessageW(m_hwndTree, TVM_EXPAND, TVE_EXPAND, reinterpret_cast<LPARAM>(hItem));
        }
    }
}

} // namespace components
