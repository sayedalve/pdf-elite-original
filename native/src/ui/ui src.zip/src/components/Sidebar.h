#pragma once
#include "framework/Panel.h"

namespace components {

class Sidebar : public framework::Panel {
public:
    Sidebar();
};

} // namespace components
