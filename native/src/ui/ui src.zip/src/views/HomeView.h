#pragma once
#include "framework/Panel.h"
#include <functional>
#include "../controls/SearchBox.h"

namespace views {

class HomeView : public framework::Panel {
public:
    HomeView();
    
    void Layout(const D2D1_RECT_F& bounds) override;
    void Render(ComPtr<ID2D1RenderTarget> target) override;

    std::function<void()> onOpenRequest;

private:
    std::shared_ptr<framework::Panel> m_mainContent;
    std::shared_ptr<framework::Panel> m_topBar;
    std::shared_ptr<framework::Panel> m_leftNav;
    
    std::shared_ptr<framework::Panel> m_quickToolsPanel;
    std::shared_ptr<framework::Panel> m_recentFilesPanel;
};

} // namespace views
