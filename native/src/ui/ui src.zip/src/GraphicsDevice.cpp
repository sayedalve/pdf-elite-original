#include "GraphicsDevice.h"
#include "NativeDesignSystem.h"

#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")

GraphicsDevice& GraphicsDevice::Instance() {
    static GraphicsDevice instance;
    return instance;
}

bool GraphicsDevice::Initialize() {
    HRESULT hr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    
    hr = D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, m_d2dFactory.GetAddressOf());
    if (FAILED(hr)) return false;

    hr = DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory), 
        reinterpret_cast<IUnknown**>(m_dwriteFactory.GetAddressOf()));
    if (FAILED(hr)) return false;

    hr = CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER,
        IID_PPV_ARGS(m_wicFactory.GetAddressOf()));
    if (FAILED(hr)) return false;

    design::FontManager::Instance().Initialize(m_dwriteFactory.Get());

    return true;
}

bool GraphicsDevice::CreateRenderTarget(HWND hwnd, int width, int height, ComPtr<ID2D1HwndRenderTarget>& target) {
    if (!m_d2dFactory) return false;

    D2D1_SIZE_U size = D2D1::SizeU(width, height);
    
    D2D1_RENDER_TARGET_PROPERTIES props = D2D1::RenderTargetProperties(
        D2D1_RENDER_TARGET_TYPE_DEFAULT,
        D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED)
    );
    HRESULT hr = m_d2dFactory->CreateHwndRenderTarget(
        props,
        D2D1::HwndRenderTargetProperties(hwnd, size),
        target.GetAddressOf()
    );

    if (SUCCEEDED(hr)) {
        target->SetTextAntialiasMode(D2D1_TEXT_ANTIALIAS_MODE_CLEARTYPE);
    }
    return SUCCEEDED(hr);
}
