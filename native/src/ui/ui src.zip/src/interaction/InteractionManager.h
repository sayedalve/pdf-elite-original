#pragma once
#include "SelectionModel.h"
#include "TextSelectableObject.h"
#include "../controls/TextEditor.h"
#include "pdf_engine/ICommand.h"
#include "pdf_engine/IAnnotation.h"
#include <windows.h>
#include <d2d1.h>
#include <vector>
#include <memory>
#include <functional>
#include <string>
#include <algorithm>

namespace ui {
namespace interaction {

enum class HandleType {
    None, TopLeft, Top, TopRight, Right, BottomRight, Bottom, BottomLeft, Left, Rotation
};

struct DragState {
    bool active = false;
    HandleType handle = HandleType::None;
    std::string objectId;
    double startX, startY;
    Rect originalBounds;
    double originalRotation;
    
    // For Line annotation drag/resize
    bool hasOriginalLineGeometry = false;
    pdf_engine::LineGeometry originalLineGeometry;
    
    bool isMarquee = false;
    D2D1_RECT_F marqueeRect;
};

enum class HitResult {
    None,
    Handle,
    Object
};

class InteractionManager {
public:
    InteractionManager();
    ~InteractionManager();

    // Core state
    void SetObjects(const std::vector<std::shared_ptr<ISelectableObject>>& objects);
    void AddObject(std::shared_ptr<ISelectableObject> obj);
    void AddObjects(const std::vector<std::shared_ptr<ISelectableObject>>& objects);
    void RemoveObject(const std::string& id);
    void RemoveObjectsForPage(int pageIndex);
    SelectionModel& GetSelectionModel() { return m_selection; }
    std::vector<std::shared_ptr<ISelectableObject>> GetSelection() const;
    const std::vector<std::shared_ptr<ISelectableObject>>& GetObjects() const { return m_objects; }
    
    // Input handling
    HitResult OnLButtonDown(double x, double y, bool shiftPressed);
    void StartMarquee(double x, double y, bool shiftPressed);
    bool OnMouseMove(double x, double y);
    bool OnLButtonUp(double x, double y);
    bool OnKeyDown(WPARAM wParam, bool shiftPressed, bool ctrlPressed);
    bool OnChar(WPARAM wParam);

    void Render(ID2D1RenderTarget* renderTarget, float scale);
    
    // Text Editing
    void EnterTextEditMode(std::shared_ptr<TextSelectableObject> obj);
    void CommitTextEdit();
    void CancelTextEdit();
    bool IsEditingText() const { return m_isEditingText; }
    HCURSOR GetCursor() const;

    // Callbacks to convert view to page and back
    std::function<void(double vx, double vy, double& px, double& py, int& pageIndex)> viewToPage;
    std::function<void(double px, double py, int pageIndex, double& vx, double& vy)> pageToView;
    std::function<void()> invalidateView;
    std::function<void(std::shared_ptr<ISelectableObject> obj, const Rect& oldBounds, const Rect& newBounds, bool hasOldLineGeom, const pdf_engine::LineGeometry& oldLineGeom)> onObjectCommitted;
    std::function<void(const std::vector<std::shared_ptr<ISelectableObject>>&)> onDeleteRequested;
    std::function<void(std::unique_ptr<pdf_engine::ICommand>)> onCommandRequested;
    std::function<void()> onSelectionChanged;

private:
    SelectionModel m_selection;
    std::vector<std::shared_ptr<ISelectableObject>> m_objects;
    DragState m_drag;
    HandleType m_hoverHandle = HandleType::None;
    std::string m_hoverObject;
    
    // Text Editing
    ui::controls::TextEditor m_textEditor;
    std::shared_ptr<TextSelectableObject> m_editingTextObj;
    bool m_isEditingText = false;
    std::vector<pdf_engine::TextLineData> m_editingOriginalLines;

    // Helper functions
    HandleType HitTestHandles(double vx, double vy, float scale);
    std::shared_ptr<ISelectableObject> HitTestObjects(double px, double py, int pageIndex);
    D2D1_RECT_F GetObjectBoundsInView(const ISelectableObject& obj);
    void DrawHandles(ID2D1RenderTarget* renderTarget, const D2D1_RECT_F& rect, float scale, bool rotatable, bool isActive);
    void UpdateDrag(double x, double y);
    
    // Geometry helpers
    void GetHandleRects(const D2D1_RECT_F& bounds, float scale, D2D1_RECT_F rects[9]);
};

} // namespace interaction
} // namespace ui

