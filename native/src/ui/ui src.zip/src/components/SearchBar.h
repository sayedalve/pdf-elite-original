#pragma once
#include <windows.h>
#include <string>
#include <functional>

class SearchBar {
public:
    SearchBar();
    ~SearchBar();

    bool Create(HWND parentHwnd);
    void Show();
    void Hide();
    void SetBounds(int x, int y, int width, int height);
    bool IsVisible() const;
    void SetFocus();
    
    void SetResultCount(int count, int current);
    
    void SetOnSearchCallback(std::function<void(const std::wstring&)> cb) { m_onSearch = cb; }
    void SetOnNextCallback(std::function<void()> cb) { m_onNext = cb; }
    void SetOnPrevCallback(std::function<void()> cb) { m_onPrev = cb; }
    void SetOnCloseCallback(std::function<void()> cb) { m_onClose = cb; }

private:
    static LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
    LRESULT HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);

    HWND m_hwnd = nullptr;
    HWND m_parentHwnd = nullptr;
    HWND m_editHwnd = nullptr;
    HWND m_labelHwnd = nullptr;
    HWND m_nextBtn = nullptr;
    HWND m_prevBtn = nullptr;
    HWND m_closeBtn = nullptr;
    
    WNDPROC m_originalEditProc = nullptr;
    static LRESULT CALLBACK EditSubclassProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData);

    std::wstring m_className;
    
    std::function<void(const std::wstring&)> m_onSearch;
    std::function<void()> m_onNext;
    std::function<void()> m_onPrev;
    std::function<void()> m_onClose;
};
