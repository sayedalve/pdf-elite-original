#pragma once
#include "../framework/Panel.h"
#include <functional>
#include <unordered_map>
#include <vector>
#include <string>
#include <memory>
#include "../controls/IconButton.h"
#include "../AppMode.h"

namespace components {

// Mode-aware action toolbar. Every button is created once and kept as a child;
// SetMode() toggles per-button visibility so only the active workspace mode's
// buttons show (and, via Panel's visibility-gated hit-testing, only those can be
// hovered or clicked). Buttons whose backend is not implemented are created
// disabled (greyed, inert) rather than omitted, so the UI communicates intent
// without offering fake functionality.
class Toolbar : public framework::Panel {
public:
    Toolbar();

    void Layout(const D2D1_RECT_F& bounds) override;
    void SetActiveTool(const std::wstring& toolName);

    // Show only the buttons that belong to `mode`, hide the rest, and re-layout.
    void SetMode(app::AppMode mode);
    app::AppMode GetMode() const { return m_mode; }

    std::function<void(const std::wstring&)> onAction;

private:
    struct Btn {
        std::shared_ptr<controls::IconButton> button;
        std::vector<app::AppMode> modes; // modes in which this button is visible
        std::wstring label;              // action name / display text
        bool isText;                     // text-only (variable width) vs icon (fixed)
        int group;                       // layout group; a gap is drawn on change
    };

    std::shared_ptr<controls::IconButton> AddButton(
        const std::wstring& text, controls::IconType icon, bool isText,
        bool enabled, int group, std::vector<app::AppMode> modes);

    void ApplyModeVisibility();

    std::vector<Btn> m_btns;
    std::unordered_map<std::wstring, std::shared_ptr<controls::IconButton>> m_buttons;
    app::AppMode m_mode = app::AppMode::View;
};

} // namespace components
