#include "RenderWorker.h"
#include <string>
#include <windows.h>
#include "../../utils/Logger.h"

#define WM_APP_TILE_READY (WM_APP + 1)

RenderWorker::RenderWorker(HWND hwndNotify, std::shared_ptr<IDocument> doc, int numThreads) 
    : m_hwndNotify(hwndNotify), m_doc(doc) {
    for (int i = 0; i < numThreads; ++i) {
        if (doc) {
            auto clone = doc->Clone();
            if (clone) m_threadDocs.push_back(std::move(clone));
            else m_threadDocs.push_back(doc); // fallback
        }
        m_threads.emplace_back(&RenderWorker::WorkerThread, this, i);
    }
}

RenderWorker::~RenderWorker() {
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_stop = true;
    }
    m_cv.notify_all();
    for (auto& t : m_threads) {
        if (t.joinable()) t.join();
    }
}

void RenderWorker::Enqueue(const RenderTask& task) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_queue.push(task);
    m_cv.notify_one();
}

void RenderWorker::CancelAll() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_queue = std::priority_queue<RenderTask>();
}

void RenderWorker::WorkerThread(int threadIndex) {
    auto localDoc = (threadIndex < static_cast<int>(m_threadDocs.size())) ? m_threadDocs[threadIndex] : m_doc;
    while (true) {
        RenderTask task;
        {
            std::unique_lock<std::mutex> lock(m_mutex);
            m_cv.wait(lock, [this] { return m_stop || !m_queue.empty(); });
            if (m_stop) break;
            task = m_queue.top();
            m_queue.pop();
        }

        // Cancel stale tasks immediately
        if (task.generation < m_currentGeneration) {
            continue;
        }

        if (!localDoc) continue;

        if (task.key.pageIndex == 0) {
            utils::Logger::Log("FIRST_PAGE_RENDER_START");
        }

        auto page = localDoc->GetPage(task.key.pageIndex);
        if (!page) continue;

        int pStartX = static_cast<int>(task.startX * task.dpiScale);
        int pStartY = static_cast<int>(task.startY * task.dpiScale);
        int pWidth = static_cast<int>(task.width * task.dpiScale);
        int pHeight = static_cast<int>(task.height * task.dpiScale);
        
        auto buffer = page->RenderToBitmap(task.key.zoom * task.dpiScale, pStartX, pStartY, pWidth, pHeight);

        if (task.key.pageIndex == 0) {
            utils::Logger::Log("FIRST_PAGE_RENDER_SUCCESS");
        }

        if (m_stop) break;

        auto result = new RenderResult{ task.generation, task.key, std::move(buffer), pWidth, pHeight, task.dpiScale };
        PostMessage(m_hwndNotify, WM_APP_TILE_READY, reinterpret_cast<WPARAM>(result), 0);
    }
}
