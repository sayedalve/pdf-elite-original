#include "ImageSelectableObject.h"

namespace ui {
namespace interaction {

ImageSelectableObject::ImageSelectableObject(std::shared_ptr<pdf_engine::IImage> image, int pageIndex)
    : m_image(image), m_pageIndex(pageIndex) {
}

std::string ImageSelectableObject::GetId() const {
    return m_image->GetId();
}

int ImageSelectableObject::GetPageIndex() const {
    return m_pageIndex;
}

Rect ImageSelectableObject::GetBounds() const {
    auto b = m_image->GetBounds();
    return { b.left, b.top, b.right, b.bottom };
}

void ImageSelectableObject::SetBounds(const Rect& bounds) {
    m_image->SetBounds({ static_cast<float>(bounds.left), static_cast<float>(bounds.top), static_cast<float>(bounds.right), static_cast<float>(bounds.bottom) });
}

double ImageSelectableObject::GetRotation() const {
    return 0.0;
}

void ImageSelectableObject::SetRotation(double /*degrees*/) {
    // Images don't support rotation yet in our engine
}

} // namespace interaction
} // namespace ui
