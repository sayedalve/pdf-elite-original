#include "HomeView.h"
#include <fstream>
#include <iomanip>
#include <sstream>
#include <chrono>
#include "../controls/IconButton.h"
#include "../controls/QuickToolCard.h"
#include "../controls/RecentFileRow.h"
#include "../NativeDesignSystem.h"
#include "../GraphicsDevice.h"
#include "../../../utils/Logger.h"
#include "../../../core/RecentFilesManager.h"

namespace views {

std::wstring FormatFileSize(uint64_t bytes) {
    double size = static_cast<double>(bytes);
    const wchar_t* units[] = { L" B", L" KB", L" MB", L" GB" };
    int unit = 0;
    while (size >= 1024.0 && unit < 3) {
        size /= 1024.0;
        unit++;
    }
    std::wstringstream wss;
    wss << std::fixed << std::setprecision(1) << size << units[unit];
    return wss.str();
}

std::wstring FormatDate(uint64_t ms) {
    if (ms == 0) return L"Unknown";
    auto timePoint = std::chrono::time_point<std::chrono::system_clock>(std::chrono::milliseconds(ms));
    auto t = std::chrono::system_clock::to_time_t(timePoint);
    struct tm tm;
    localtime_s(&tm, &t);
    wchar_t buf[64];
    wcsftime(buf, sizeof(buf), L"%b %d, %Y", &tm);
    return std::wstring(buf);
}

HomeView::HomeView() {
    SetBackgroundColor(design::Colors::Background);
    
    // 1. Top Bar
    m_topBar = std::make_shared<framework::Panel>();
    m_topBar->SetBackgroundColor(design::Colors::Surface);
    
    auto searchBox = std::make_shared<controls::SearchBox>();
    auto btnSettings = std::make_shared<controls::IconButton>(L"", controls::IconType::Settings);
    btnSettings->SetColors(design::Colors::Surface, design::Colors::ControlHover, design::Colors::TextPrimary);

    m_topBar->AddChild(searchBox);
    m_topBar->AddChild(btnSettings);
    
    // 2. Left Navigation
    m_leftNav = std::make_shared<framework::Panel>();
    m_leftNav->SetBackgroundColor(design::Colors::SurfaceElevated);
    
    auto btnOpen = std::make_shared<controls::IconButton>(L"Open PDF", controls::IconType::Open);
    btnOpen->SetColors(design::Colors::AccentPrimary, design::Colors::AccentHover, design::Colors::TextPrimary);
    btnOpen->SetOnClick([this]() {
        utils::Logger::Log("OPEN_BUTTON_CLICK");
        if (onOpenRequest) {
            onOpenRequest();
        }
    });

    auto btnCreate = std::make_shared<controls::IconButton>(L"Create PDF", controls::IconType::Edit);
    btnCreate->SetColors(design::Colors::SurfaceHover, design::Colors::Control, design::Colors::TextPrimary);
    btnCreate->SetEnabled(false);

    auto btnRecent = std::make_shared<controls::IconButton>(L"Recent Files", controls::IconType::Recent);
    btnRecent->SetColors(design::Colors::ControlHover, design::Colors::ControlHover, design::Colors::TextPrimary);

    auto btnStarred = std::make_shared<controls::IconButton>(L"Starred Files", controls::IconType::Star);
    btnStarred->SetEnabled(false);
    
    auto btnFolders = std::make_shared<controls::IconButton>(L"Recent Folders", controls::IconType::Folder);
    btnFolders->SetEnabled(false);
    
    m_leftNav->AddChild(btnOpen);
    m_leftNav->AddChild(btnRecent);
    
    // 3. Main Content
    m_mainContent = std::make_shared<framework::Panel>();
    m_mainContent->SetBackgroundColor(design::Colors::Background);
    
    m_quickToolsPanel = std::make_shared<framework::Panel>();
    
    auto toolEdit = std::make_shared<controls::QuickToolCard>(L"Edit PDF", L"Modify text, images, and pages", controls::IconType::Edit);
    auto toolComment = std::make_shared<controls::QuickToolCard>(L"Add Comments", L"Add sticky notes, highlights", controls::IconType::Comment);
    
    // Wire them to simply trigger Open Request for now since they require a document
    toolEdit->SetOnClick([this]() { if (onOpenRequest) onOpenRequest(); });
    toolComment->SetOnClick([this]() { if (onOpenRequest) onOpenRequest(); });

    m_quickToolsPanel->AddChild(toolEdit);
    m_quickToolsPanel->AddChild(toolComment);

    m_recentFilesPanel = std::make_shared<framework::Panel>();
    
    auto recentFiles = core::RecentFilesManager::Instance().GetRecentFiles();
    for (const auto& rf : recentFiles) {
        m_recentFilesPanel->AddChild(std::make_shared<controls::RecentFileRow>(
            rf.filename, 
            FormatDate(rf.lastAccessed), 
            FormatFileSize(rf.fileSize)
        ));
    }

    m_mainContent->AddChild(m_quickToolsPanel);
    m_mainContent->AddChild(m_recentFilesPanel);

    AddChild(m_topBar);
    AddChild(m_leftNav);
    AddChild(m_mainContent);
}

void HomeView::Layout(const D2D1_RECT_F& bounds) {
    UIElement::Layout(bounds);
    
    float topBarHeight = design::Metrics::TopbarHeight;
    float leftNavWidth = 240.0f; // Home sidebar is wider than the document mode rail
    
    D2D1_RECT_F topBounds = {bounds.left, bounds.top, bounds.right, bounds.top + topBarHeight};
    m_topBar->Layout(topBounds);
    
    auto& topChildren = m_topBar->GetChildren();
    if (topChildren.size() >= 2) {
        // Search Box (Centered)
        float searchW = 400.0f;
        float searchH = 36.0f;
        float searchX = bounds.left + (bounds.right - bounds.left - searchW) / 2.0f;
        float searchY = bounds.top + (topBarHeight - searchH) / 2.0f;
        topChildren[0]->Layout({searchX, searchY, searchX + searchW, searchY + searchH});
        
        // Settings / Profile (Right aligned)
        float settingsW = 36.0f;
        float settingsX = bounds.right - 24.0f - settingsW;
        float settingsY = bounds.top + (topBarHeight - settingsW) / 2.0f;
        topChildren[1]->Layout({settingsX, settingsY, settingsX + settingsW, settingsY + settingsW});
    }
    
    D2D1_RECT_F leftBounds = {bounds.left, bounds.top + topBarHeight, bounds.left + leftNavWidth, bounds.bottom};
    m_leftNav->Layout(leftBounds);
    
    D2D1_RECT_F mainBounds = {bounds.left + leftNavWidth, bounds.top + topBarHeight, bounds.right, bounds.bottom};
    m_mainContent->Layout(mainBounds);
    
    auto& leftChildren = m_leftNav->GetChildren();
    if (leftChildren.size() >= 5) {
        float navY = leftBounds.top + design::Spacing::XXXLarge; // was 60
        // Primary Open
        leftChildren[0]->Layout({leftBounds.left + design::Spacing::Medium2, navY, leftBounds.right - design::Spacing::Medium2, navY + design::Metrics::ControlHeightLarge});
        navY += design::Metrics::ControlHeightLarge + design::Spacing::Small;
        // Secondary Create
        leftChildren[1]->Layout({leftBounds.left + design::Spacing::Medium2, navY, leftBounds.right - design::Spacing::Medium2, navY + design::Metrics::ControlHeightLarge});
        
        navY += design::Metrics::ControlHeightLarge + design::Metrics::SectionGap;
        
        for (int i = 2; i < leftChildren.size(); ++i) {
            leftChildren[i]->Layout({leftBounds.left + design::Spacing::Medium2, navY, leftBounds.right - design::Spacing::Medium2, navY + design::Metrics::ControlHeightNormal});
            navY += design::Metrics::ControlHeightNormal + design::Spacing::XSmall;
        }
    }
    
    // Quick Tools Grid
    D2D1_RECT_F qtBounds = {mainBounds.left + design::Metrics::ContentPadding, 
                            mainBounds.top + 80.0f, 
                            mainBounds.right - design::Metrics::ContentPadding, 
                            mainBounds.top + 360.0f};
    m_quickToolsPanel->Layout(qtBounds);
    
    auto& qtChildren = m_quickToolsPanel->GetChildren();
    float availableW = qtBounds.right - qtBounds.left;
    int cols = 4;
    if (availableW < 800) cols = 3;
    if (availableW < 600) cols = 2;
    
    float gap = design::Spacing::Large1; // 20
    float cardW = (availableW - gap * (cols - 1)) / cols;
    float cardH = 120.0f;
    
    for (size_t i = 0; i < qtChildren.size(); ++i) {
        int col = i % cols;
        int row = static_cast<int>(i / cols);
        float cx = qtBounds.left + col * (cardW + gap);
        float cy = qtBounds.top + row * (cardH + gap);
        qtChildren[i]->Layout({cx, cy, cx + cardW, cy + cardH});
    }

    // Recent Files
    float recentTop = qtBounds.top + ((qtChildren.size() + cols - 1) / cols) * (cardH + gap) + design::Spacing::XXXLarge;
    D2D1_RECT_F rfBounds = {mainBounds.left + design::Metrics::ContentPadding, 
                            recentTop, 
                            mainBounds.right - design::Metrics::ContentPadding, 
                            mainBounds.bottom - design::Metrics::ContentPadding};
    m_recentFilesPanel->Layout(rfBounds);

    auto& rfChildren = m_recentFilesPanel->GetChildren();
    float rfY = rfBounds.top;
    float rowHeight = design::Metrics::ControlHeightLarge + design::Spacing::Medium2; // ~56
    for (auto& child : rfChildren) {
        child->Layout({rfBounds.left, rfY, rfBounds.right, rfY + rowHeight});
        rfY += rowHeight;
    }
}

void HomeView::Render(ComPtr<ID2D1RenderTarget> target) {
    ComPtr<ID2D1SolidColorBrush> bgBrush;
    target->CreateSolidColorBrush(design::Colors::Background, &bgBrush);
    target->FillRectangle(m_bounds, bgBrush.Get());
    
    for (auto& child : m_children) {
        child->Render(target);
    }
    
    ComPtr<ID2D1SolidColorBrush> borderBrush;
    target->CreateSolidColorBrush(design::Colors::BorderSubtle, &borderBrush);
    
    target->DrawLine(
        D2D1::Point2F(m_bounds.left, m_topBar->GetBounds().bottom),
        D2D1::Point2F(m_bounds.right, m_topBar->GetBounds().bottom),
        borderBrush.Get(), 1.0f
    );
    target->DrawLine(
        D2D1::Point2F(m_leftNav->GetBounds().right, m_leftNav->GetBounds().top),
        D2D1::Point2F(m_leftNav->GetBounds().right, m_leftNav->GetBounds().bottom),
        borderBrush.Get(), 1.0f
    );
    
    ComPtr<ID2D1SolidColorBrush> textBrush;
    target->CreateSolidColorBrush(design::Colors::TextPrimary, &textBrush);
    
    auto sectionFormat = design::FontManager::Instance().GetPageTitle();
    
    if (sectionFormat && textBrush) {
        D2D1_RECT_F txtMainBounds = m_mainContent->GetBounds();
        
        D2D1_RECT_F toolsRect = {txtMainBounds.left + design::Metrics::ContentPadding, txtMainBounds.top + design::Spacing::XXLarge, txtMainBounds.right, txtMainBounds.bottom};
        std::wstring toolsTitle = L"Quick Tools";
        target->DrawText(toolsTitle.c_str(), static_cast<UINT32>(toolsTitle.length()), sectionFormat, toolsRect, textBrush.Get());
        
        D2D1_RECT_F recentRect = {txtMainBounds.left + design::Metrics::ContentPadding, m_recentFilesPanel->GetBounds().top - design::Spacing::XXLarge, txtMainBounds.right, txtMainBounds.bottom};
        std::wstring recentTitle = L"Recent Files";
        target->DrawText(recentTitle.c_str(), static_cast<UINT32>(recentTitle.length()), sectionFormat, recentRect, textBrush.Get());
    }
    
    auto logoFormat = design::FontManager::Instance().GetAppTitle();
    
    if (logoFormat && textBrush) {
        D2D1_RECT_F logoRect = {m_leftNav->GetBounds().left + design::Spacing::Large2, m_leftNav->GetBounds().top + design::Spacing::Large1, m_leftNav->GetBounds().right, m_leftNav->GetBounds().bottom};
        std::wstring logoText = L"PDF Elite";
        target->DrawText(logoText.c_str(), static_cast<UINT32>(logoText.length()), logoFormat, logoRect, textBrush.Get());
    }
}

} // namespace views
