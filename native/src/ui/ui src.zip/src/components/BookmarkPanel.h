#pragma once
#include <windows.h>
#include <commctrl.h>
#include <string>
#include <functional>
#include <vector>
#include <memory>
#include "pdf_engine/Navigation.h"

namespace components {

class BookmarkPanel {
public:
    BookmarkPanel();
    ~BookmarkPanel();

    bool Create(HWND parentHwnd);
    void Show();
    void Hide();
    void SetBounds(int x, int y, int width, int height);
    bool IsVisible() const;
    
    void LoadBookmarks(const std::vector<std::unique_ptr<pdf_engine::PdfBookmark>>& bookmarks);
    
    void SetOnNavigateCallback(std::function<void(const pdf_engine::NavigationTarget&)> cb) { m_onNavigate = cb; }
    
    HWND GetHwnd() const { return m_hwndTree; }

private:
    void PopulateTree(HTREEITEM hParent, const std::vector<std::unique_ptr<pdf_engine::PdfBookmark>>& bookmarks);
    
    static LRESULT CALLBACK ContainerWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

    HWND m_parentHwnd = nullptr;
    HWND m_hwndContainer = nullptr;
    HWND m_hwndTree = nullptr;
    std::function<void(const pdf_engine::NavigationTarget&)> m_onNavigate;
    
    std::vector<pdf_engine::NavigationTarget> m_destinations;
};

} // namespace components
