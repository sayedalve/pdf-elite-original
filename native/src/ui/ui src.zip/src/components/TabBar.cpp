#include "TabBar.h"
#include "../NativeDesignSystem.h"
#include "../GraphicsDevice.h"

namespace components {

TabBar::TabBar() {
}

void TabBar::SetTabs(const std::vector<std::wstring>& titles, int activeIndex) {
    m_titles = titles;
    m_activeIndex = activeIndex;
}

void TabBar::EnsureTabFormat() {
    if (m_tabFormat) return;

    auto factory = GraphicsDevice::Instance().GetDWriteFactory();
    if (!factory) return;

    // 13px medium Segoe UI, matching the toolbar type ramp, but leading-aligned
    // and single-line so titles read left-to-right and trim on the right.
    HRESULT hr = factory->CreateTextFormat(
        L"Segoe UI", nullptr,
        DWRITE_FONT_WEIGHT_MEDIUM, DWRITE_FONT_STYLE_NORMAL, DWRITE_FONT_STRETCH_NORMAL,
        design::TypographySize::Toolbar, L"en-us", &m_tabFormat);
    if (FAILED(hr) || !m_tabFormat) { m_tabFormat.Reset(); return; }

    m_tabFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING);
    m_tabFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
    m_tabFormat->SetWordWrapping(DWRITE_WORD_WRAPPING_NO_WRAP);

    // "…" trimming sign so overly long file names are shown as "Beginning_of_na…".
    if (SUCCEEDED(factory->CreateEllipsisTrimmingSign(m_tabFormat.Get(), &m_ellipsisSign))) {
        DWRITE_TRIMMING trimming = {};
        trimming.granularity = DWRITE_TRIMMING_GRANULARITY_CHARACTER;
        m_tabFormat->SetTrimming(&trimming, m_ellipsisSign.Get());
    }
}

void TabBar::Render(Microsoft::WRL::ComPtr<ID2D1RenderTarget> target) {
    auto bounds = GetBounds();

    EnsureTabFormat();

    float x = bounds.left;
    float tabWidth = 150.0f;
    float tabHeight = bounds.bottom - bounds.top; (void)tabHeight;

    for (int i = 0; i < (int)m_titles.size(); ++i) {
        D2D1_RECT_F tabRect = {x, bounds.top + 4.0f, x + tabWidth, bounds.bottom};

        // Draw background
        D2D1_COLOR_F bgColor = design::Colors::Background;
        if (i == m_activeIndex) {
            bgColor = design::Colors::SurfaceActiveTab;
        } else if (i == m_hoverIndex) {
            bgColor = design::Colors::SurfaceHover;
        }

        Microsoft::WRL::ComPtr<ID2D1SolidColorBrush> bgBrush;
        target->CreateSolidColorBrush(bgColor, &bgBrush);

        if (i == m_activeIndex) {
            D2D1_ROUNDED_RECT roundedRect = D2D1::RoundedRect(tabRect, design::Radius::R8, design::Radius::R8);
            target->FillRoundedRectangle(roundedRect, bgBrush.Get());
            // Draw a square bottom to blend into the toolbar below
            D2D1_RECT_F bottomRect = {tabRect.left, tabRect.bottom - design::Radius::R8, tabRect.right, tabRect.bottom};
            target->FillRectangle(bottomRect, bgBrush.Get());
        } else {
            // Keep inactive tabs slightly smaller or just clear backgrounds.
            D2D1_RECT_F bgRect = tabRect;
            bgRect.top += 4.0f; // Padding from top edge
            bgRect.bottom -= 4.0f;
            D2D1_ROUNDED_RECT roundedRect = D2D1::RoundedRect(bgRect, design::Radius::R6, design::Radius::R6);
            target->FillRoundedRectangle(roundedRect, bgBrush.Get());
        }

        // Draw title
        Microsoft::WRL::ComPtr<ID2D1SolidColorBrush> textBrush;
        target->CreateSolidColorBrush(i == m_activeIndex ? design::Colors::TextPrimary : design::Colors::TextSecondary, &textBrush);

        IDWriteTextFormat* textFormat = m_tabFormat ? m_tabFormat.Get()
                                                    : design::FontManager::Instance().GetToolbar();
        if (textFormat) {
            // Title cell: 12px left padding, 10px right padding so the ellipsis
            // never touches the tab edge. Clip to the cell as a hard guarantee
            // that a long name can never bleed past its own tab.
            D2D1_RECT_F textBounds = tabRect;
            textBounds.left += 12.0f;
            textBounds.right -= 10.0f;
            if (textBounds.right < textBounds.left) textBounds.right = textBounds.left;

            target->PushAxisAlignedClip(textBounds, D2D1_ANTIALIAS_MODE_ALIASED);
            target->DrawText(m_titles[i].c_str(), static_cast<UINT32>(m_titles[i].length()),
                textFormat, textBounds, textBrush.Get());
            target->PopAxisAlignedClip();
        }


        x += tabWidth + design::Spacing::Small;
    }
}

void TabBar::OnMouseDown(float x, float y) { (void)y;
    auto bounds = GetBounds();
    float tabWidth = 150.0f;
    
    float currentX = bounds.left;
    for (int i = 0; i < (int)m_titles.size(); ++i) {
        if (x >= currentX && x <= currentX + tabWidth) {
            if (onTabSelected) onTabSelected(i);
            
        }
        currentX += tabWidth + design::Spacing::Small;
    }
    
}

void TabBar::OnMouseMove(float x, float y) { (void)y;
    auto bounds = GetBounds();
    float tabWidth = 150.0f;
    
    int newHover = -1;
    float currentX = bounds.left;
    for (int i = 0; i < (int)m_titles.size(); ++i) {
        if (x >= currentX && x <= currentX + tabWidth) {
            newHover = i;
            break;
        }
        currentX += tabWidth + design::Spacing::Small;
    }
    
    if (newHover != m_hoverIndex) {
        m_hoverIndex = newHover;
    }
    
}

} // namespace components
