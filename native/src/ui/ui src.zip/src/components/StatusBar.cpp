#include "StatusBar.h"
#include "../GraphicsDevice.h"
#include "../NativeDesignSystem.h"

namespace components {

StatusBar::StatusBar() {
    SetBackgroundColor(design::Colors::Surface);

    m_btnZoomIn = AddButton(L"ZoomIn", controls::IconType::ZoomIn);
    m_btnZoomOut = AddButton(L"Zoom Out", controls::IconType::ZoomOut);
    m_btnPrev = AddButton(L"Prev", controls::IconType::None);
    m_btnNext = AddButton(L"Next", controls::IconType::None);
}

std::shared_ptr<controls::IconButton> StatusBar::AddButton(const std::wstring& text, controls::IconType icon) {
    auto btn = std::make_shared<controls::IconButton>(text, icon);
    btn->SetColors(design::Colors::Surface, design::Colors::ControlHover, design::Colors::TextPrimary);
    btn->SetShowText(false); // Only show icons
    btn->SetOnClick([this, text]() {
        if (onAction) onAction(text);
    });
    AddChild(btn);
    return btn;
}

void StatusBar::Layout(const D2D1_RECT_F& bounds) {
    UIElement::Layout(bounds);

    float btnSize = 32.0f;
    float cx = bounds.left + (bounds.right - bounds.left - btnSize) / 2.0f;
    
    // Position buttons vertically from the BOTTOM
    float y = bounds.bottom - design::Spacing::Medium2 - btnSize;

    if (m_btnNext) {
        m_btnNext->Layout({cx, y, cx + btnSize, y + btnSize});
        y -= (btnSize + design::Spacing::Small);
    }
    if (m_btnPrev) {
        m_btnPrev->Layout({cx, y, cx + btnSize, y + btnSize});
        y -= (btnSize + design::Spacing::Medium2);
    }
    
    if (m_btnZoomOut) {
        m_btnZoomOut->Layout({cx, y, cx + btnSize, y + btnSize});
        y -= (btnSize + design::Spacing::Small);
    }
    if (m_btnZoomIn) {
        m_btnZoomIn->Layout({cx, y, cx + btnSize, y + btnSize});
    }
}

void StatusBar::SetPageInfo(int currentPage, int totalPages) {
    m_currentPage = currentPage;
    m_totalPages = totalPages;
}

void StatusBar::SetZoom(float zoom) {
    m_zoom = zoom;
}

void StatusBar::SetFileName(const std::wstring& fileName) {
    m_fileName = fileName;
}

void StatusBar::SetState(const std::wstring& state) {
    m_state = state;
}

void StatusBar::Render(ComPtr<ID2D1RenderTarget> target) {
    Panel::Render(target);
    
    // Draw page text at the bottom
    ComPtr<ID2D1SolidColorBrush> textBrush;
    target->CreateSolidColorBrush(design::Colors::TextSecondary, &textBrush);
    
    auto textFormat = design::FontManager::Instance().GetMetadata();
    
    if (textFormat && textBrush) {
        textFormat->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
        textFormat->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
        
        std::wstring pageText = std::to_wstring(m_currentPage + 1) + L"/" + std::to_wstring(m_totalPages);
        D2D1_RECT_F pageRect = {m_bounds.left, m_btnNext->GetBounds().bottom + design::Spacing::Small, m_bounds.right, m_btnNext->GetBounds().bottom + design::Spacing::Small + 20.0f};
        target->DrawText(pageText.c_str(), static_cast<UINT32>(pageText.length()), textFormat, pageRect, textBrush.Get());
    }
}

} // namespace components
