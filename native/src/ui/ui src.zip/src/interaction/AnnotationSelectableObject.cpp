#include <cmath>
#include "AnnotationSelectableObject.h"

namespace ui {
namespace interaction {

AnnotationSelectableObject::AnnotationSelectableObject(std::shared_ptr<pdf_engine::IAnnotation> annot, int pageIndex)
    : m_annot(annot), m_pageIndex(pageIndex) {
}

std::string AnnotationSelectableObject::GetId() const {
    if (m_annot) return m_annot->GetId();
    return "";
}

int AnnotationSelectableObject::GetPageIndex() const {
    return m_pageIndex;
}

Rect AnnotationSelectableObject::GetBounds() const {
    if (m_annot) {
        auto b = m_annot->GetBounds();
        return { static_cast<double>(b.left), static_cast<double>(b.top), 
                 static_cast<double>(b.right), static_cast<double>(b.bottom) };
    }
    return {0, 0, 0, 0};
}

void AnnotationSelectableObject::SetBounds(const Rect& bounds) {
    if (m_annot) {
        m_annot->SetBounds({ static_cast<float>(bounds.left), static_cast<float>(bounds.top), 
                             static_cast<float>(bounds.right), static_cast<float>(bounds.bottom) });
    }
}

double AnnotationSelectableObject::GetRotation() const {
    return m_rotation;
}

void AnnotationSelectableObject::SetRotation(double degrees) {
    m_rotation = degrees;
}

bool AnnotationSelectableObject::HitTest(double px, double py, double tolerance) const {
    if (!m_annot) return false;
    
    if (m_annot->GetType() == pdf_engine::AnnotationType::Line) {
        pdf_engine::LineGeometry geom;
        if (m_annot->GetLineGeometry(geom)) {
            // Distance from point (px, py) to segment (geom.start, geom.end)
            double l2 = (geom.end.x - geom.start.x)*(geom.end.x - geom.start.x) + 
                        (geom.end.y - geom.start.y)*(geom.end.y - geom.start.y);
            if (l2 == 0.0) {
                double dx = px - geom.start.x;
                double dy = py - geom.start.y;
                return std::sqrt(dx*dx + dy*dy) <= tolerance;
            }
            
            double t = std::max(0.0, std::min(1.0, ((px - geom.start.x) * (geom.end.x - geom.start.x) + 
                                                    (py - geom.start.y) * (geom.end.y - geom.start.y)) / l2));
            double projX = geom.start.x + t * (geom.end.x - geom.start.x);
            double projY = geom.start.y + t * (geom.end.y - geom.start.y);
            
            double dx = px - projX;
            double dy = py - projY;
            return std::sqrt(dx*dx + dy*dy) <= tolerance;
        }
    }
    
    return ISelectableObject::HitTest(px, py, tolerance);
}

} // namespace interaction
} // namespace ui
