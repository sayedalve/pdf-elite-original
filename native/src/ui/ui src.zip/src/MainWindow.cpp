#include "ui/MainWindow.h"
#include <fstream>
#include <chrono>
#include <shlobj.h>

#include "../../utils/Logger.h"
#include "../../utils/PerfLog.h"


#include "NativeDesignSystem.h"
#include "GraphicsDevice.h"
#include "PdfViewer.h"
#include "ThemeManager.h"
#include "views/HomeView.h"
#include "views/DocumentView.h"
#include "AppMode.h"
#include "RenderWorker.h"
#include "../../pdf_engine/src/PdfDocument.h"
#include "../../pdf_engine/src/commands/AnnotationCommands.h"
#include "../../pdf_engine/src/commands/TextCommands.h"
#include "interaction/TextSelectableObject.h"
#include "components/PropertiesPanel.h"
#include "../../pdf_engine/src/commands/PageCommands.h"
#include "../../pdf_engine/src/commands/MacroCommand.h"
#include "../../pdf_engine/src/commands/AnnotationCommands.h"

#include "../../pdf_engine/src/SearchEngine.h"
#include "components/SearchBar.h"
#include "components/BookmarkPanel.h"
#include "../../core/RecentFilesManager.h"
#include "../../app/PrintManager.h"
#include <dwmapi.h>
#include <windowsx.h>
#include <shellapi.h>
#include <commdlg.h>
#include <dwrite.h>

#define WM_APP_TILE_READY (WM_APP + 1)
#define WM_APP_SEARCH_COMPLETE (WM_APP + 2)

struct DocumentTab {
    std::wstring filePath;
    std::wstring title;
    std::shared_ptr<IDocument> document;
    std::unique_ptr<PdfViewer> viewer;
    std::unique_ptr<pdf_engine::SearchEngine> searchEngine;
    std::vector<pdf_engine::SearchResult> searchResults;
    int currentMatchIndex = -1;
    bool isModified = false;
};

class MainWindowImpl {
public:
    Microsoft::WRL::ComPtr<ID2D1HwndRenderTarget> renderTarget;
    std::shared_ptr<framework::UIElement> currentView;
    std::shared_ptr<views::HomeView> homeView;
    std::shared_ptr<views::DocumentView> documentView;
    
    std::vector<std::unique_ptr<DocumentTab>> tabs;
    int activeTabIndex = -1;
    
    std::unique_ptr<SearchBar> searchBar;
    std::unique_ptr<components::BookmarkPanel> bookmarkPanel;
    bool showBookmarks = false;
    
    DocumentTab* GetActiveTab() {
        if (activeTabIndex >= 0 && activeTabIndex < tabs.size()) {
            return tabs[activeTabIndex].get();
        }
        return nullptr;
    }
    
    PdfViewer* GetViewer() {
        if (auto tab = GetActiveTab()) return tab->viewer.get();
        return nullptr;
    }
    
    pdf_engine::SearchEngine* GetSearchEngine() {
        if (auto tab = GetActiveTab()) return tab->searchEngine.get();
        return nullptr;
    }
    
    std::vector<pdf_engine::SearchResult>* GetSearchResults() {
        if (auto tab = GetActiveTab()) return &tab->searchResults;
        return nullptr;
    }
    
    
    void UpdateTabs() {
        if (!documentView || !documentView->GetTabBar()) return;
        std::vector<std::wstring> titles;
        for (auto& tab : tabs) {
            bool dirty = tab->document && tab->document->GetCommandStack().IsDirty();
            tab->isModified = dirty;
            titles.push_back(tab->title + (dirty ? L"*" : L""));
        }
        documentView->GetTabBar()->SetTabs(titles, activeTabIndex);
    }
    
    void CheckDirtyStates() {
        bool changed = false;
        for (auto& tab : tabs) {
            bool dirty = tab->document && tab->document->GetCommandStack().IsDirty();
            if (dirty != tab->isModified) {
                tab->isModified = dirty;
                changed = true;
            }
        }
        if (changed) UpdateTabs();
    }

    int* GetCurrentMatchIndex() {
        if (auto tab = GetActiveTab()) return &tab->currentMatchIndex;
        return nullptr;
    }
};

MainWindow::MainWindow() : m_className(L"PdfEliteMainWindow"), m_impl(new MainWindowImpl()) {}

MainWindow::~MainWindow() {
    if (m_hwnd) DestroyWindow(m_hwnd);
    delete m_impl;
}

bool MainWindow::Create(const std::wstring& title, int width, int height) {

    try {
        GraphicsDevice::Instance().Initialize();
        
        WNDCLASS wc = {};
        wc.lpfnWndProc = WindowProc;
        wc.hInstance = GetModuleHandle(nullptr);
        wc.lpszClassName = m_className.c_str();
        wc.hCursor = LoadCursor(nullptr, IDC_ARROW);

        RegisterClass(&wc);

        m_hwnd = CreateWindowEx(
            0, m_className.c_str(), title.c_str(),
            WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, width, height,
            nullptr, nullptr, GetModuleHandle(nullptr), this
        );

        if (!m_hwnd) {
            DWORD err = GetLastError();
            MessageBoxW(nullptr, (L"CreateWindowEx failed with error: " + std::to_wstring(err)).c_str(), L"PDFElite Error", MB_OK);
            return false;
        }

        if (m_hwnd) {
            MARGINS margins = {1, 1, 1, 1};
            DwmExtendFrameIntoClientArea(m_hwnd, &margins);

            BOOL value = TRUE;
            DwmSetWindowAttribute(m_hwnd, 20 /*DWMWA_USE_IMMERSIVE_DARK_MODE*/, &value, sizeof(value));
            COLORREF darkColor = 0x001A1311; // BGR representation of #11131A (Surface color)
            DwmSetWindowAttribute(m_hwnd, 35 /*DWMWA_CAPTION_COLOR*/, &darkColor, sizeof(darkColor));

            GraphicsDevice::Instance().CreateRenderTarget(m_hwnd, width, height, m_impl->renderTarget);
            
            m_impl->homeView = std::make_shared<views::HomeView>();
            m_impl->homeView->onOpenRequest = [this]() {
                this->OpenFile();
            };
            m_impl->documentView = std::make_shared<views::DocumentView>();
            
            m_impl->documentView->GetTabBar()->SetOnTabSelected([this](int index) {
                SwitchToTab(index);
            });
                    m_impl->documentView->GetLeftSidebar()->onPageSelected = [this](int pageIndex) {
                if (auto tab = m_impl->GetActiveTab()) {
                    if (tab->viewer) tab->viewer->GoToPage(pageIndex);
                    m_impl->documentView->GetLeftSidebar()->SetActivePage(pageIndex);
                    InvalidateRect(m_hwnd, nullptr, FALSE);
                }
            };

            m_impl->documentView->GetLeftSidebar()->onPageMoved = [this](int src, int dest) {
                if (auto tab = m_impl->GetActiveTab()) {
                    if (tab->document) {
                        auto cmd = std::make_unique<pdf_engine::commands::MovePageCommand>(static_cast<PdfDocument*>(tab->document.get()), src, dest);
                        if (tab->document->GetCommandStack().ExecuteCommand(std::move(cmd))) {
                             // force refresh
                            m_impl->documentView->GetLeftSidebar()->SetDocument(tab->document, tab->viewer->GetRenderWorker());
                            int newActive = (src < dest) ? dest - 1 : dest; 
                            tab->viewer->GoToPage(newActive);
                            m_impl->documentView->GetLeftSidebar()->SetActivePage(newActive);
                            InvalidateRect(m_hwnd, nullptr, FALSE);
                        }
                    }
                }
            };

            m_impl->documentView->onHomeRequest = [this]() {
                bool canGoHome = true;
                for (int i = 0; i < m_impl->tabs.size(); ++i) {
                    if (!PromptSaveChanges(i)) {
                        canGoHome = false;
                        break;
                    }
                }
                if (!canGoHome) return;
                
                m_impl->tabs.clear();
                m_impl->activeTabIndex = -1;
                m_impl->UpdateTabs();
                
                m_impl->currentView = m_impl->homeView;
                RECT rc;
                GetClientRect(m_hwnd, &rc);
                SendMessageW(m_hwnd, WM_SIZE, SIZE_RESTORED, MAKELPARAM(rc.right, rc.bottom));
                InvalidateRect(m_hwnd, nullptr, FALSE);
            };
            if (auto tb = m_impl->documentView->GetToolbar()) {
                tb->onAction = [this, tb](const std::wstring& action) {
                    if (action == L"Save") {
                        DoSave(m_impl->activeTabIndex);
                    }
                    else if (action == L"Print") {
                        if (auto tab = m_impl->GetActiveTab()) {
                            if (tab->document) {
                                app::PrintManager::PrintDocument(m_hwnd, tab->document);
                            }
                        }
                    }
                    else if (action == L"Save As") {
                        DoSaveAs(m_impl->activeTabIndex);
                    }
                    else if (action == L"Undo") { if (m_impl->GetViewer() && m_impl->GetViewer()->GetDocument()) m_impl->GetViewer()->GetDocument()->GetCommandStack().Undo(); }
                    else if (action == L"Redo") { if (m_impl->GetViewer() && m_impl->GetViewer()->GetDocument()) m_impl->GetViewer()->GetDocument()->GetCommandStack().Redo(); }
                    else if (action == L"Zoom Out") { if (m_impl->GetViewer()) m_impl->GetViewer()->OnZoom(-0.2f); }
                    else if (action == L"ZoomIn") { if (m_impl->GetViewer()) m_impl->GetViewer()->OnZoom(0.2f); }
                    else if (action == L"Fit Width") { if (m_impl->GetViewer()) m_impl->GetViewer()->ZoomToFitWidth(); }
                    else if (action == L"Fit Page") { if (m_impl->GetViewer()) m_impl->GetViewer()->ZoomToFitPage(); }
                    else if (action == L"First") { if (m_impl->GetViewer()) m_impl->GetViewer()->GoToPage(0); }
                    else if (action == L"Prev") { 
                        if (m_impl->GetViewer() && m_impl->GetActiveTab() && m_impl->GetActiveTab()->document) {
                            int current = m_impl->GetViewer()->GetCurrentPage();
                            if (current > 0) m_impl->GetViewer()->GoToPage(current - 1);
                        }
                    }
                    else if (action == L"Next") { 
                        if (m_impl->GetViewer() && m_impl->GetActiveTab() && m_impl->GetActiveTab()->document) {
                            int current = m_impl->GetViewer()->GetCurrentPage();
                            if (current < m_impl->GetActiveTab()->document->PageCount() - 1) m_impl->GetViewer()->GoToPage(current + 1);
                        }
                    }
                    else if (action == L"Last") { 
                        if (m_impl->GetViewer() && m_impl->GetActiveTab() && m_impl->GetActiveTab()->document) {
                            m_impl->GetViewer()->GoToPage(m_impl->GetActiveTab()->document->PageCount() - 1);
                        }
                    }
                    else if (action == L"Continuous") { if (m_impl->GetViewer()) m_impl->GetViewer()->SetLayoutMode(LayoutMode::Continuous); }
                    else if (action == L"Single") { if (m_impl->GetViewer()) m_impl->GetViewer()->SetLayoutMode(LayoutMode::SinglePage); }
                    else if (action == L"Hand") { tb->SetActiveTool(L"Hand"); if (m_impl->GetViewer()) m_impl->GetViewer()->SetToolMode(ToolMode::Select); }
                    else if (action == L"Select") { tb->SetActiveTool(L"Select"); if (m_impl->GetViewer()) m_impl->GetViewer()->SetToolMode(ToolMode::Select); }
                    else if (action == L"Highlight") { tb->SetActiveTool(L"Highlight"); if (m_impl->GetViewer()) m_impl->GetViewer()->SetToolMode(ToolMode::Highlight); }
                    else if (action == L"Line") { tb->SetActiveTool(L"Line"); if (m_impl->GetViewer()) m_impl->GetViewer()->SetToolMode(ToolMode::Line); }
                    else if (action == L"Arrow") { tb->SetActiveTool(L"Arrow"); if (m_impl->GetViewer()) m_impl->GetViewer()->SetToolMode(ToolMode::Arrow); }
                    else if (action == L"Underline") { tb->SetActiveTool(L"Underline"); if (m_impl->GetViewer()) m_impl->GetViewer()->SetToolMode(ToolMode::Underline); }
                    else if (action == L"Strikeout") { tb->SetActiveTool(L"Strikeout"); if (m_impl->GetViewer()) m_impl->GetViewer()->SetToolMode(ToolMode::Strikeout); }
                    else if (action == L"Edit Text") { tb->SetActiveTool(L"Edit Text"); if (m_impl->GetViewer()) m_impl->GetViewer()->SetToolMode(ToolMode::EditText); }
                    else if (action == L"Add Text") { tb->SetActiveTool(L"Add Text"); if (m_impl->GetViewer()) m_impl->GetViewer()->SetToolMode(ToolMode::AddText); }
                    else if (action == L"Add Image") { if (m_impl->GetViewer()) m_impl->GetViewer()->TriggerInsertImage(); }
                    else if (action == L"Rotate CW") {
                        if (auto tab = m_impl->GetActiveTab()) {
                            if (tab->document && tab->viewer) {
                                auto selected = m_impl->documentView->GetLeftSidebar()->GetSelectedPages();
                                if (selected.empty()) selected.insert(tab->viewer->GetCurrentPage());
                                auto macro = std::make_unique<pdf_engine::commands::MacroCommand>("Rotate Pages CW");
                                for (int page : selected) {
                                    macro->AddCommand(std::make_unique<pdf_engine::commands::RotatePageCommand>(static_cast<PdfDocument*>(tab->document.get()), page, 90));
                                }
                                if (tab->document->GetCommandStack().ExecuteCommand(std::move(macro))) {
                                     // refresh
                                    RefreshAfterPageOp();
                                }
                            }
                        }
                    }
                    else if (action == L"Rotate CCW") {
                        if (auto tab = m_impl->GetActiveTab()) {
                            if (tab->document && tab->viewer) {
                                auto selected = m_impl->documentView->GetLeftSidebar()->GetSelectedPages();
                                if (selected.empty()) selected.insert(tab->viewer->GetCurrentPage());
                                auto macro = std::make_unique<pdf_engine::commands::MacroCommand>("Rotate Pages CCW");
                                for (int page : selected) {
                                    macro->AddCommand(std::make_unique<pdf_engine::commands::RotatePageCommand>(static_cast<PdfDocument*>(tab->document.get()), page, 270));
                                }
                                if (tab->document->GetCommandStack().ExecuteCommand(std::move(macro))) {
                                     // refresh
                                    RefreshAfterPageOp();
                                }
                            }
                        }
                    }
                    else if (action == L"Delete Page") {
                        if (auto tab = m_impl->GetActiveTab()) {
                            if (tab->document && tab->viewer) {
                                auto selected = m_impl->documentView->GetLeftSidebar()->GetSelectedPages();
                                if (selected.empty()) selected.insert(tab->viewer->GetCurrentPage());
                                if (selected.size() >= tab->document->PageCount()) {
                                    MessageBoxW(m_hwnd, L"A document must keep at least one page.", L"Delete Page", MB_OK | MB_ICONINFORMATION);
                                    return;
                                }
                                if (selected.size() > 1) {
                                    if (MessageBoxW(m_hwnd, L"Are you sure you want to delete the selected pages?", L"Delete Pages", MB_YESNO | MB_ICONWARNING) != IDYES) {
                                        return;
                                    }
                                }
                                auto macro = std::make_unique<pdf_engine::commands::MacroCommand>("Delete Pages");
                                std::vector<int> sortedPages(selected.begin(), selected.end());
                                for (auto it = sortedPages.rbegin(); it != sortedPages.rend(); ++it) {
                                    macro->AddCommand(std::make_unique<pdf_engine::commands::DeletePageCommand>(static_cast<PdfDocument*>(tab->document.get()), *it));
                                }
                                tab->viewer->ExecuteMacroStructureChange(std::move(macro));
                                int current = tab->viewer->GetCurrentPage();
                                if (current >= tab->document->PageCount()) current = tab->document->PageCount() - 1;
                                tab->viewer->GoToPage(current);
                                RefreshAfterPageOp();
                            }
                        }
                    }
                    else if (action == L"Insert Page") {
                        if (auto tab = m_impl->GetActiveTab()) {
                            if (tab->document && tab->viewer) {
                                int current = tab->viewer->GetCurrentPage();
                                auto size = tab->document->GetPageSize(current);
                                tab->viewer->InsertBlankPage(current + 1, size.width, size.height);
                                RefreshAfterPageOp();
                            }
                        }
                    }
                    else if (action == L"Extract Page") {
                        if (auto tab = m_impl->GetActiveTab()) {
                            if (tab->document && tab->viewer) {
                                auto selected = m_impl->documentView->GetLeftSidebar()->GetSelectedPages();
                                if (selected.empty()) selected.insert(tab->viewer->GetCurrentPage());
                                std::vector<int> indices(selected.begin(), selected.end());
                                auto extracted = tab->document->ExtractPages(indices);
                                if (extracted) {
                                    OPENFILENAMEW ofn = {};
                                    ofn.lStructSize = sizeof(ofn);
                                    ofn.hwndOwner = m_hwnd;
                                    wchar_t szFile[MAX_PATH] = {0};
                                    ofn.lpstrFile = szFile;
                                    ofn.nMaxFile = MAX_PATH;
                                    ofn.lpstrFilter = L"PDF Documents (*.pdf) *.pdf All Files (*.*) *.* ";
                                    ofn.nFilterIndex = 1;
                                    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
                                    ofn.lpstrDefExt = L"pdf";
                                    if (GetSaveFileNameW(&ofn)) {
                                        if (!extracted->SaveAs(ofn.lpstrFile)) {
                                            MessageBoxW(m_hwnd, L"Failed to save the extracted page.", L"Extract Page", MB_OK | MB_ICONERROR);
                                        }
                                    }
                                }
                            }
                        }
                    }
    else if (action == L"Bookmarks") {
                        m_impl->showBookmarks = !m_impl->showBookmarks;
                        if (m_impl->showBookmarks) {
                            if (m_impl->bookmarkPanel) m_impl->bookmarkPanel->Show();
                        } else {
                            if (m_impl->bookmarkPanel) m_impl->bookmarkPanel->Hide();
                        }
                        // Trigger a layout recalculation to hide/show thumbnails if needed
                        RECT rc;
                        GetClientRect(m_hwnd, &rc);
                        SendMessageW(m_hwnd, WM_SIZE, SIZE_RESTORED, MAKELPARAM(rc.right, rc.bottom));
                    }
                    InvalidateRect(m_hwnd, nullptr, FALSE);
                };
            }
            
            if (auto rail = m_impl->documentView->GetModeRail()) {
                rail->SetOnModeSelected([this](app::AppMode mode) {
                    if (mode == app::AppMode::Home) {
                        // Home isn't a persistent workspace mode: return to the start
                        // view and leave the rail highlighting the default doc mode so
                        // it's correct when a document view comes back.
                        if (auto r = m_impl->documentView->GetModeRail()) r->SetActiveMode(app::AppMode::View);
                        if (auto tb = m_impl->documentView->GetToolbar()) tb->SetMode(app::AppMode::View);
                        if (m_impl->documentView->onHomeRequest) m_impl->documentView->onHomeRequest();
                        return;
                    }
                    if (auto tb = m_impl->documentView->GetToolbar()) tb->SetMode(mode);
                    RECT rc;
                    GetClientRect(m_hwnd, &rc);
                    SendMessageW(m_hwnd, WM_SIZE, SIZE_RESTORED, MAKELPARAM(rc.right, rc.bottom));
                    InvalidateRect(m_hwnd, nullptr, FALSE);
                });
                // Foundation opens documents in View (reading) mode.
                rail->SetActiveMode(app::AppMode::View);
            }

        m_impl->currentView = m_impl->homeView; // Start with HomeView (Image 1)
        
        m_impl->searchBar = std::make_unique<SearchBar>();
        m_impl->searchBar->Create(m_hwnd);
        m_impl->searchBar->Show();
        m_impl->searchBar->SetOnSearchCallback([this](const std::wstring& query) {
            auto engine = m_impl->GetSearchEngine();
            if (!engine) return;
            engine->Cancel();
            auto results = m_impl->GetSearchResults();
            auto matchIndex = m_impl->GetCurrentMatchIndex();
            if (query.empty()) {
                if (results) results->clear();
                if (matchIndex) *matchIndex = -1;
                m_impl->searchBar->SetResultCount(0, 0);
                if (auto v = m_impl->GetViewer()) {
                    if (results) v->SetSearchResults(*results, -1);
                }
                return;
            }
            engine->SearchAsync(query, false, false, [this](const std::vector<pdf_engine::SearchResult>& res) {
                auto pResults = new std::vector<pdf_engine::SearchResult>(res);
                PostMessage(m_hwnd, WM_APP_SEARCH_COMPLETE, reinterpret_cast<WPARAM>(pResults), 0);
            });
        });
        m_impl->searchBar->SetOnNextCallback([this]() {
            auto results = m_impl->GetSearchResults();
            auto matchIndex = m_impl->GetCurrentMatchIndex();
            if (!results || results->empty() || !matchIndex) return;
            *matchIndex = (*matchIndex + 1) % static_cast<int>(results->size());
            m_impl->searchBar->SetResultCount(static_cast<int>(results->size()), *matchIndex + 1);
            if (auto v = m_impl->GetViewer()) v->SetSearchResults(*results, *matchIndex);
        });
        m_impl->searchBar->SetOnPrevCallback([this]() {
            auto results = m_impl->GetSearchResults();
            auto matchIndex = m_impl->GetCurrentMatchIndex();
            if (!results || results->empty() || !matchIndex) return;
            *matchIndex = (*matchIndex - 1 + static_cast<int>(results->size())) % static_cast<int>(results->size());
            m_impl->searchBar->SetResultCount(static_cast<int>(results->size()), *matchIndex + 1);
            if (auto v = m_impl->GetViewer()) v->SetSearchResults(*results, *matchIndex);
        });
        
        m_impl->bookmarkPanel = std::make_unique<components::BookmarkPanel>();
        m_impl->bookmarkPanel->Create(m_hwnd);
        m_impl->bookmarkPanel->Hide();
        m_impl->bookmarkPanel->SetOnNavigateCallback([this](const pdf_engine::NavigationTarget& target) {
            if (m_impl->GetViewer()) {
                m_impl->GetViewer()->NavigateTo(target);
            }
        });
        m_impl->searchBar->SetOnCloseCallback([this]() {
            m_impl->searchBar->Hide();
            SetFocus(m_hwnd);
            auto results = m_impl->GetSearchResults();
            auto matchIndex = m_impl->GetCurrentMatchIndex();
            if (results) results->clear();
            if (matchIndex) *matchIndex = -1;
            if (auto v = m_impl->GetViewer()) {
                if (results) v->SetSearchResults(*results, -1);
            }
        });

        ThemeManager::Instance().OnThemeChanged.AddListener([this]() {
            // PostMessage to the main thread to repaint
            PostMessage(m_hwnd, WM_APP_TILE_READY, 0, 0);
        });

        ThemeManager::Instance().StartWatching();
    } // close if (m_hwnd)
    } catch (const std::exception& e) {
        MessageBoxA(nullptr, e.what(), "Exception in Create", MB_OK);
        return false;
    } catch (...) {
        MessageBoxA(nullptr, "Unknown exception in Create", "Exception", MB_OK);
        return false;
    }

    return m_hwnd != nullptr;
}

void MainWindow::Show(int nCmdShow) {
    if (m_hwnd) SetTimer(m_hwnd, 1, 16, nullptr);
    ShowWindow(m_hwnd, nCmdShow);
}

LRESULT CALLBACK MainWindow::WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    try {
        MainWindow* pThis = nullptr;
        if (uMsg == WM_NCCREATE) {
            CREATESTRUCT* pCreate = reinterpret_cast<CREATESTRUCT*>(lParam);
            pThis = reinterpret_cast<MainWindow*>(pCreate->lpCreateParams);
            SetWindowLongPtr(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(pThis));
            pThis->m_hwnd = hwnd;
        } else {
            pThis = reinterpret_cast<MainWindow*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
        }
        if (pThis) return pThis->HandleMessage(uMsg, wParam, lParam);
        return DefWindowProc(hwnd, uMsg, wParam, lParam);
    } catch (const std::exception& e) {
        MessageBoxA(nullptr, e.what(), "Exception in WindowProc", MB_OK);
        return 0;
    } catch (...) {
        MessageBoxA(nullptr, "Unknown exception in WindowProc", "Exception", MB_OK);
        return 0;
    }
}

LRESULT MainWindow::HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    
    case WM_NCHITTEST: {
        LRESULT hit = DefWindowProc(m_hwnd, uMsg, wParam, lParam);
        if (hit == HTCLIENT) {
            POINT pt;
            pt.x = GET_X_LPARAM(lParam);
            pt.y = GET_Y_LPARAM(lParam);
            ScreenToClient(m_hwnd, &pt);

            RECT rcWindow;
            GetClientRect(m_hwnd, &rcWindow);

            int border = 8;
            bool isTop = pt.y < border;
            bool isBottom = pt.y >= rcWindow.bottom - border;
            bool isLeft = pt.x < border;
            bool isRight = pt.x >= rcWindow.right - border;

            if (isTop && isLeft) return HTTOPLEFT;
            if (isTop && isRight) return HTTOPRIGHT;
            if (isBottom && isLeft) return HTBOTTOMLEFT;
            if (isBottom && isRight) return HTBOTTOMRIGHT;
            if (isTop) return HTTOP;
            if (isBottom) return HTBOTTOM;
            if (isLeft) return HTLEFT;
            if (isRight) return HTRIGHT;

            // Custom caption area: top 40px, but exclude the right 140px (which we will draw as window controls)
            if (pt.y < 40 && pt.x < rcWindow.right - 140) {
                // Return HTCAPTION to allow window dragging. 
                // Note: Components under here won't get normal WM_LBUTTONDOWN.
                return HTCAPTION;
            }
        }
        return hit;
    }

    case WM_SIZE:
        if (m_impl->renderTarget) {
            UINT width = LOWORD(lParam);
            UINT height = HIWORD(lParam);
            m_impl->renderTarget->Resize(D2D1::SizeU(width, height));
            
            UINT dpi = GetDpiForWindow(m_hwnd);
            float scale = dpi / 96.0f;
            float dipWidth = width / scale;
            float dipHeight = height / scale;
            
            if (m_impl->currentView) {
                m_impl->currentView->Layout({0, 0, dipWidth, dipHeight});
            }
            
            if (m_impl->currentView == m_impl->documentView && m_impl->GetViewer()) {
                m_impl->GetViewer()->OnResize(m_impl->documentView->GetCanvasContainer()->GetBounds());
            }
            
            if (m_impl->searchBar && m_impl->documentView && m_impl->documentView->GetToolbar()) {
                auto tbBounds = m_impl->documentView->GetToolbar()->GetBounds();
                float searchW = 320.0f;
                float searchH = 32.0f;
                float searchX = tbBounds.left + (tbBounds.right - tbBounds.left - searchW) / 2.0f;
                float searchY = tbBounds.top + (tbBounds.bottom - tbBounds.top - searchH) / 2.0f;
                m_impl->searchBar->SetBounds(static_cast<int>(searchX * scale), 
                                             static_cast<int>(searchY * scale), 
                                             static_cast<int>(searchW * scale), 
                                             static_cast<int>(searchH * scale));
            }
            
            if (m_impl->bookmarkPanel && m_impl->documentView && m_impl->currentView == m_impl->documentView) {
                if (m_impl->showBookmarks) {
                    auto bounds = m_impl->documentView->GetLeftSidebar()->GetBounds();
                    m_impl->bookmarkPanel->SetBounds(static_cast<int>(bounds.left * scale),
                                                     static_cast<int>(bounds.top * scale),
                                                     static_cast<int>((bounds.right - bounds.left) * scale),
                                                     static_cast<int>((bounds.bottom - bounds.top) * scale));
                    m_impl->bookmarkPanel->Show();
                } else {
                    m_impl->bookmarkPanel->Hide();
                }
            }
        }
        return 0;
        case WM_SETCURSOR: {
            if (LOWORD(lParam) == HTCLIENT && m_impl->currentView == m_impl->documentView && m_impl->GetViewer()) {
                if (m_impl->GetViewer()->OnSetCursor()) {
                    return TRUE;
                }
            }
            return DefWindowProc(m_hwnd, uMsg, wParam, lParam);
        }

    case WM_MOUSEMOVE:
    case WM_LBUTTONDOWN:
    case WM_LBUTTONDBLCLK:
    case WM_LBUTTONUP: {
        UINT dpi = GetDpiForWindow(m_hwnd);
        float scale = dpi / 96.0f;
        float x = GET_X_LPARAM(lParam) / scale;
        float y = GET_Y_LPARAM(lParam) / scale;
        if (m_impl->currentView) {
            if (uMsg == WM_MOUSEMOVE) m_impl->currentView->OnMouseMove(x, y);
            else if (uMsg == WM_LBUTTONDOWN || uMsg == WM_LBUTTONDBLCLK) m_impl->currentView->OnMouseDown(x, y);
            else m_impl->currentView->OnMouseUp(x, y);
        }
        if (m_impl->currentView == m_impl->documentView && m_impl->GetViewer()) {
            if (uMsg == WM_MOUSEMOVE) m_impl->GetViewer()->OnMouseMove(static_cast<int>(x), static_cast<int>(y));
            else if (uMsg == WM_LBUTTONDOWN) m_impl->GetViewer()->OnLButtonDown(static_cast<int>(x), static_cast<int>(y));
            else if (uMsg == WM_LBUTTONDBLCLK) m_impl->GetViewer()->OnLButtonDoubleClick(static_cast<int>(x), static_cast<int>(y));
            else m_impl->GetViewer()->OnLButtonUp(static_cast<int>(x), static_cast<int>(y));
        }
        
        if (uMsg == WM_MOUSEMOVE) {
            static DWORD lastInvalidate = 0;
            DWORD now = GetTickCount();
            if (now - lastInvalidate > 33) { // ~30 fps cap for hover/tooltip
                InvalidateRect(m_hwnd, nullptr, FALSE);
                lastInvalidate = now;
            }
        }
        return 0;
    }
    case WM_RBUTTONUP: {
        UINT dpi = GetDpiForWindow(m_hwnd);
        float scale = dpi / 96.0f;
        float x = GET_X_LPARAM(lParam) / scale;
        float y = GET_Y_LPARAM(lParam) / scale;
        if (m_impl->currentView == m_impl->documentView && m_impl->GetViewer()) {
            m_impl->GetViewer()->OnRButtonUp(static_cast<int>(x), static_cast<int>(y));
        }
        return 0;
    }
    case WM_MOUSEWHEEL: {
        int delta = GET_WHEEL_DELTA_WPARAM(wParam);
        POINT pt;
        pt.x = GET_X_LPARAM(lParam); 
        pt.y = GET_Y_LPARAM(lParam);
        ScreenToClient(m_hwnd, &pt);
        UINT dpi = GetDpiForWindow(m_hwnd);
        float scale = dpi / 96.0f;
        float x = pt.x / scale;
        float y = pt.y / scale;

        if (m_impl->currentView == m_impl->documentView && m_impl->GetViewer()) {
            if (m_impl->documentView->GetLeftSidebar()->HitTest(x, y)) {
                float wheelDelta = static_cast<float>(delta) / 120.0f;
                m_impl->documentView->GetLeftSidebar()->OnMouseWheel(wheelDelta);
            } else {
                if (GET_KEYSTATE_WPARAM(wParam) & MK_CONTROL) {
                    m_impl->GetViewer()->OnZoom(static_cast<float>(delta > 0 ? 0.2f : -0.2f), x, y);
                } else {
                    float scaledDelta = -((static_cast<float>(delta) / 120.0f) * 100.0f);
                    m_impl->GetViewer()->OnScroll(scaledDelta);
                }
            }
        }
        InvalidateRect(m_hwnd, nullptr, FALSE);
        return 0;
    }
    case WM_KEYDOWN: {
        bool handled = false;
        if (GetKeyState(VK_CONTROL) & 0x8000) {
            if (wParam == 'O') {
                this->OpenFile();
                handled = true;
            } else if (wParam == 'S') {
                if (GetKeyState(VK_SHIFT) & 0x8000) {
                    DoSaveAs(m_impl->activeTabIndex);
                } else {
                    DoSave(m_impl->activeTabIndex);
                }
                handled = true;
            } else if (wParam == 'F') {
                if (m_impl->searchBar) {
                    m_impl->searchBar->Show();
                    m_impl->searchBar->SetFocus();
                }
                handled = true;
            } else if (wParam == 'W') {
                if (m_impl->activeTabIndex >= 0) {
                    CloseTab(m_impl->activeTabIndex);
                }
                handled = true;
            } else if (wParam == 'T') {
                if (m_impl->GetViewer()) m_impl->GetViewer()->SetToolMode(ToolMode::AddText);
                handled = true;
            } else if (wParam == 'I') {
                if (m_impl->GetViewer()) m_impl->GetViewer()->TriggerInsertImage();
                handled = true;
            }
        }
        if (!handled && m_impl->GetViewer()) {
            m_impl->GetViewer()->OnKeyDown(wParam);
        }
        return 0;
    }
    case WM_CHAR: {
        if (m_impl->currentView == m_impl->documentView && m_impl->GetViewer()) {
            m_impl->GetViewer()->OnChar(wParam);
        }
        return 0;
    }
    case WM_COMMAND:
        if (m_impl->currentView == m_impl->documentView && m_impl->GetViewer()) {
            m_impl->GetViewer()->OnCommand(wParam, lParam);
        }
        return 0;
    case WM_APP_SEARCH_COMPLETE:
        if (wParam != 0) {
            auto pResults = reinterpret_cast<std::vector<pdf_engine::SearchResult>*>(wParam);
            if (auto res = m_impl->GetSearchResults()) *res = *pResults;
            delete pResults;
            
            if (auto idx = m_impl->GetCurrentMatchIndex()) *idx = m_impl->GetSearchResults()->empty() ? -1 : 0;
            if (m_impl->searchBar) {
                m_impl->searchBar->SetResultCount(static_cast<int>(m_impl->GetSearchResults()->size()), m_impl->GetSearchResults()->empty() ? 0 : 1);
            }
            if (m_impl->GetViewer()) {
                m_impl->GetViewer()->SetSearchResults((*m_impl->GetSearchResults()), (*m_impl->GetCurrentMatchIndex()));
            }
        }
        return 0;
    case WM_APP_TILE_READY:
        if (wParam != 0) {
            auto result = reinterpret_cast<RenderResult*>(wParam);
            if (m_impl->GetViewer()) {
                m_impl->GetViewer()->OnTileReady(result, m_impl->renderTarget);
                if (m_impl->documentView && m_impl->documentView->GetLeftSidebar()) {
                    m_impl->documentView->GetLeftSidebar()->OnTileReady(result, m_impl->renderTarget);
                }
            }
            delete result;
        }
        InvalidateRect(m_hwnd, nullptr, FALSE);
        return 0;
    case WM_DROPFILES: {
        HDROP hDrop = (HDROP)wParam;
        UINT count = DragQueryFileW(hDrop, 0xFFFFFFFF, nullptr, 0);
        for (UINT i = 0; i < count; ++i) {
            wchar_t filePath[MAX_PATH];
            if (DragQueryFileW(hDrop, i, filePath, MAX_PATH)) {
                std::wstring pathStr = filePath;
                if (pathStr.length() > 4 && pathStr.substr(pathStr.length() - 4) == L".pdf") {
                    OpenFileDirect(pathStr);
                } else {
                    MessageBoxW(m_hwnd, L"Unsupported file type. Please drop PDF files only.", L"PDF Elite", MB_OK | MB_ICONINFORMATION);
                }
            }
        }
        DragFinish(hDrop);
        return 0;
    }
    
    case WM_TIMER:
        if (wParam == 1 && m_impl->GetViewer()) {
            if (m_impl->GetViewer()->UpdatePhysics()) {
                InvalidateRect(m_hwnd, nullptr, FALSE);
            }
        }
        return 0;

    case WM_PAINT: {
        m_impl->CheckDirtyStates();
        PAINTSTRUCT ps;
        BeginPaint(m_hwnd, &ps);
        if (m_impl->renderTarget) {
            m_impl->renderTarget->BeginDraw();
            m_impl->renderTarget->Clear(design::Colors::Background); // App background

            if (m_impl->currentView) m_impl->currentView->Render(m_impl->renderTarget);

            if (m_impl->currentView == m_impl->documentView && m_impl->GetViewer()) {
                if (m_impl->GetViewer()->GetDocument()) {
                    m_impl->documentView->GetStatusBar()->SetPageInfo(m_impl->GetViewer()->GetCurrentPage(), m_impl->GetViewer()->GetDocument()->PageCount());
                    m_impl->documentView->GetStatusBar()->SetZoom(static_cast<float>(m_impl->GetViewer()->GetZoom()));
                }
                m_impl->GetViewer()->Render(m_impl->renderTarget, m_impl->documentView->GetCanvasContainer()->GetBounds());
                m_impl->GetViewer()->RenderThumbnails(m_impl->renderTarget, m_impl->documentView->GetLeftSidebar()->GetBounds());
            }

            std::wstring tip = m_impl->currentView ? m_impl->currentView->GetTooltipText() : L"";
            if (!tip.empty()) {
                POINT pt; GetCursorPos(&pt); ScreenToClient(m_hwnd, &pt);
                UINT dpi = GetDpiForWindow(m_hwnd);
                float scale = dpi / 96.0f;
                float x = pt.x / scale;
                float y = pt.y / scale;
                
                auto textFormat = design::FontManager::Instance().GetTooltip();
                if (textFormat) {
                    float w = tip.length() * 6.5f + 12.0f; // estimation
                    float h = 18.0f;
                    
                    D2D1_RECT_F bgRect = { x + 12.0f, y + 24.0f, x + 12.0f + w, y + 24.0f + h };
                    D2D1_ROUNDED_RECT rRect = D2D1::RoundedRect(bgRect, 4.0f, 4.0f);
                    
                    ComPtr<ID2D1SolidColorBrush> bgBrush, borderBrush, textBrush;
                    m_impl->renderTarget->CreateSolidColorBrush(design::Colors::SurfaceElevated, &bgBrush);
                    m_impl->renderTarget->CreateSolidColorBrush(design::Colors::Border, &borderBrush);
                    m_impl->renderTarget->CreateSolidColorBrush(design::Colors::TextPrimary, &textBrush);
                    
                    m_impl->renderTarget->FillRoundedRectangle(rRect, bgBrush.Get());
                    m_impl->renderTarget->DrawRoundedRectangle(rRect, borderBrush.Get(), 1.0f);
                    
                    D2D1_RECT_F textRect = { bgRect.left + 6.0f, bgRect.top + 2.0f, bgRect.right - 6.0f, bgRect.bottom - 2.0f };
                    m_impl->renderTarget->DrawTextW(tip.c_str(), static_cast<UINT32>(tip.length()), textFormat, textRect, textBrush.Get());
                }
            }

            m_impl->renderTarget->EndDraw();
        }
        EndPaint(m_hwnd, &ps);
        return 0;
    }
    case WM_CLOSE: {
        bool canClose = true;
        for (int i = 0; i < m_impl->tabs.size(); ++i) {
            if (!PromptSaveChanges(i)) {
                canClose = false;
                break;
            }
        }
        if (canClose) {
            PostQuitMessage(0);
        }
        return 0;
    }
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(m_hwnd, uMsg, wParam, lParam);
}


void MainWindow::SwitchToTab(int index) {
    PERF_SCOPE("SwitchToTab");
    if (index < 0 || index >= m_impl->tabs.size()) return;
    m_impl->activeTabIndex = index;
    m_impl->UpdateTabs();
    
    if (auto tab = m_impl->GetActiveTab()) {
        m_impl->documentView->GetStatusBar()->SetFileName(tab->filePath.c_str());
        if (tab->document) m_impl->documentView->GetStatusBar()->SetPageInfo(tab->viewer->GetCurrentPage(), tab->document->PageCount());
        m_impl->documentView->GetStatusBar()->SetZoom(static_cast<float>(tab->viewer->GetZoom()));
        
        // Let viewer resize to container
        tab->viewer->OnResize(m_impl->documentView->GetCanvasContainer()->GetBounds());
        m_impl->documentView->GetLeftSidebar()->SetDocument(tab->document, tab->viewer->GetRenderWorker());
        m_impl->documentView->GetLeftSidebar()->SetActivePage(tab->viewer->GetCurrentPage());
        
        if (m_impl->bookmarkPanel && tab->document) {
            m_impl->bookmarkPanel->LoadBookmarks(tab->document->GetBookmarks());
        }
    }
    
    RECT rc;
    GetClientRect(m_hwnd, &rc);
    SendMessageW(m_hwnd, WM_SIZE, SIZE_RESTORED, MAKELPARAM(rc.right, rc.bottom));
    
    InvalidateRect(m_hwnd, nullptr, FALSE);
}

void MainWindow::OpenFileDirect(const std::wstring& path) {
    PERF_SCOPE("OpenFileDirect");
    utils::Logger::Log("OPEN_FILE_DIRECT_START");
    utils::Logger::Log("DOCUMENT_LOAD_START");
    auto result = PdfDocument::LoadFromFile(path.c_str());
    if (result.has_value()) {
        utils::Logger::Log("DOCUMENT_LOAD_SUCCESS");
        core::RecentFilesManager::Instance().AddFile(path);
        std::shared_ptr<IDocument> sharedDoc = std::move(result.value);
        
        auto tab = std::make_unique<DocumentTab>();
        tab->filePath = path;
        size_t slashPos = path.find_last_of(L"/\\");
        tab->title = (slashPos != std::wstring::npos) ? path.substr(slashPos + 1) : path;
        tab->document = sharedDoc;
        
        tab->searchEngine = std::make_unique<pdf_engine::SearchEngine>(sharedDoc);
        
        tab->viewer = std::make_unique<PdfViewer>();
        tab->viewer->Initialize(m_hwnd);
        tab->viewer->SetDocument(sharedDoc);
        
        tab->viewer->GetInteractionManager().onSelectionChanged = [this]() {
            auto t = m_impl->GetActiveTab();
            if (!t) return;
            auto sel = t->viewer->GetInteractionManager().GetSelection();
            bool showProps = false;
            if (sel.size() == 1 && std::dynamic_pointer_cast<ui::interaction::TextSelectableObject>(sel[0])) {
                m_impl->documentView->GetPropertiesPanel()->SetSelectedObject(sel[0]);
                showProps = true;
            }
            
            if (m_impl->documentView->GetPropertiesPanel()->IsVisible() != showProps) {
                m_impl->documentView->GetPropertiesPanel()->SetVisible(showProps);
                RECT rc;
                GetClientRect(m_hwnd, &rc);
                SendMessageW(m_hwnd, WM_SIZE, SIZE_RESTORED, MAKELPARAM(rc.right, rc.bottom));
            }
            InvalidateRect(m_hwnd, nullptr, FALSE);
        };
        
        m_impl->tabs.push_back(std::move(tab));
        m_impl->activeTabIndex = static_cast<int>(m_impl->tabs.size()) - 1;
        
        m_impl->currentView = m_impl->documentView;
        m_impl->UpdateTabs();
        utils::Logger::Log("DOCUMENT_VIEW_ACTIVATED");
        
        m_impl->documentView->GetStatusBar()->SetFileName(path.c_str());
        m_impl->documentView->GetStatusBar()->SetPageInfo(0, sharedDoc->PageCount());
        m_impl->documentView->GetStatusBar()->SetZoom(static_cast<float>(m_impl->GetViewer()->GetZoom()));
        
        RECT rc;
        GetClientRect(m_hwnd, &rc);
        SendMessageW(m_hwnd, WM_SIZE, SIZE_RESTORED, MAKELPARAM(rc.right, rc.bottom));
        
        InvalidateRect(m_hwnd, nullptr, FALSE);
    } else {
        utils::Logger::Log("DOCUMENT_LOAD_FAILURE");
    }
}

void MainWindow::OpenFile() {
    utils::Logger::Log("OPEN_DIALOG_START");
    OPENFILENAMEW ofn = {};
    wchar_t szFile[260] = { 0 };
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = m_hwnd;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = sizeof(szFile) / sizeof(wchar_t);
    ofn.lpstrFilter = L"PDF Files\0*.pdf\0All\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
    if (GetOpenFileNameW(&ofn)) {
        utils::Logger::Log("OPEN_DIALOG_SUCCESS");
        utils::Logger::Log("FILE_SELECTED");
        OpenFileDirect(ofn.lpstrFile);
    } else {
        DWORD err = CommDlgExtendedError();
        utils::Logger::Log("OPEN_DIALOG_CANCEL (Error: " + std::to_string(err) + ")");
    }
}

bool MainWindow::DoSave(int tabIndex) {
    PERF_SCOPE("DoSave");
    if (tabIndex < 0 || tabIndex >= m_impl->tabs.size()) return false;
    auto& tab = m_impl->tabs[tabIndex];
    if (!tab->document) return false;
    
    // If no path is set or we cannot write to it, fallback to SaveAs
    if (tab->filePath.empty()) {
        return DoSaveAs(tabIndex);
    }

    DWORD attrs = GetFileAttributesW(tab->filePath.c_str());
    if (attrs != INVALID_FILE_ATTRIBUTES && (attrs & FILE_ATTRIBUTE_READONLY)) {
        return DoSaveAs(tabIndex);
    }
    
    if (tab->document->SaveAs(tab->filePath)) {
        tab->document->GetCommandStack().MarkSaved();
        m_impl->UpdateTabs();
        return true;
    } else {
        MessageBoxW(m_hwnd, L"Failed to save document. The file might be read-only or locked.", L"Save Error", MB_OK | MB_ICONERROR);
        return false;
    }
}

void MainWindow::RefreshAfterPageOp() {
    auto tab = m_impl->GetActiveTab();
    if (!tab || !tab->document || !tab->viewer) return;

    int current = tab->viewer->GetCurrentPage();
    int pageCount = tab->document->PageCount();

    // Rebuild the sidebar thumbnails for the new page structure. The viewer's
    // structural refresh stops and restarts its render worker, so we must re-read
    // GetRenderWorker() here (this runs right after the op, on the same UI thread)
    // to hand the sidebar the CURRENT worker rather than a stale pointer. This
    // mirrors the proven open / tab-switch refresh path.
    if (auto sidebar = m_impl->documentView->GetLeftSidebar()) {
        sidebar->SetDocument(tab->document, tab->viewer->GetRenderWorker());
        sidebar->SetActivePage(current);
    }
    if (auto status = m_impl->documentView->GetStatusBar()) {
        status->SetPageInfo(current, pageCount);
    }
    if (m_impl->bookmarkPanel) {
        m_impl->bookmarkPanel->LoadBookmarks(tab->document->GetBookmarks());
    }

    InvalidateRect(m_hwnd, nullptr, FALSE);
}

bool MainWindow::DoSaveAs(int tabIndex) {
    PERF_SCOPE("DoSaveAs");
    if (tabIndex < 0 || tabIndex >= m_impl->tabs.size()) return false;
    auto& tab = m_impl->tabs[tabIndex];
    if (!tab->document) return false;

    OPENFILENAMEW ofn = {};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = m_hwnd;
    wchar_t szFile[MAX_PATH] = {0};
    wcsncpy_s(szFile, tab->filePath.c_str(), MAX_PATH - 1);
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"PDF Documents (*.pdf)\0*.pdf\0All Files (*.*)\0*.*\0";
    ofn.nFilterIndex = 1;
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
    ofn.lpstrDefExt = L"pdf";
    
    if (GetSaveFileNameW(&ofn)) {
        if (tab->document->SaveAs(ofn.lpstrFile)) {
            tab->filePath = ofn.lpstrFile;
            std::wstring pathStr = tab->filePath;
            size_t slashPos = pathStr.find_last_of(L"/\\");
            tab->title = (slashPos != std::wstring::npos) ? pathStr.substr(slashPos + 1) : pathStr;
            tab->document->GetCommandStack().MarkSaved();
            m_impl->UpdateTabs();
            
            if (m_impl->activeTabIndex == tabIndex && m_impl->documentView && m_impl->documentView->GetStatusBar()) {
                m_impl->documentView->GetStatusBar()->SetFileName(tab->filePath.c_str());
            }
            
            return true;
        } else {
            MessageBoxW(m_hwnd, L"Failed to save document to the new location.", L"Save Error", MB_OK | MB_ICONERROR);
            return false;
        }
    }
    return false; // User cancelled
}

bool MainWindow::PromptSaveChanges(int tabIndex) {
    if (tabIndex < 0 || tabIndex >= m_impl->tabs.size()) return true;
    auto& tab = m_impl->tabs[tabIndex];
    if (tab->document && tab->document->GetCommandStack().IsDirty()) {
        std::wstring msg = L"Do you want to save changes to " + tab->title + L"?";
        int result = MessageBoxW(m_hwnd, msg.c_str(), L"PDF Elite", MB_YESNOCANCEL | MB_ICONWARNING);
        if (result == IDCANCEL) return false;
        if (result == IDYES) {
            if (!DoSave(tabIndex)) {
                return false;
            }
        }
    }
    return true;
}

void MainWindow::CloseTab(int tabIndex) {
    if (!PromptSaveChanges(tabIndex)) return;
    
    // Stop rendering
    /* render worker handled by viewer destructor */
    m_impl->tabs.erase(m_impl->tabs.begin() + tabIndex);
    
    if (m_impl->tabs.empty()) {
        m_impl->activeTabIndex = -1;
        m_impl->currentView = m_impl->homeView;
    } else {
        if (m_impl->activeTabIndex >= m_impl->tabs.size()) {
            m_impl->activeTabIndex = static_cast<int>(m_impl->tabs.size() - 1);
        }
        SwitchToTab(m_impl->activeTabIndex);
    }
}



