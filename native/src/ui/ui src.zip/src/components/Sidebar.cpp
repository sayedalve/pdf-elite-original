#include "Sidebar.h"
#include "../controls/IconButton.h"
#include "../NativeDesignSystem.h"

namespace components {

Sidebar::Sidebar() {
    SetLayoutDirection(framework::LayoutDirection::Vertical);
    SetBackgroundColor(design::Colors::SurfaceElevated);
    SetPadding(design::Spacing::Small);
    SetSpacing(design::Spacing::Small);
}

} // namespace components
