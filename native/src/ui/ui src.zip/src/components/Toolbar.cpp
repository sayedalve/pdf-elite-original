#include "Toolbar.h"
#include "../controls/IconButton.h"
#include "../NativeDesignSystem.h"
#include <algorithm>

namespace components {

using app::AppMode;

Toolbar::Toolbar() {
    SetLayoutDirection(framework::LayoutDirection::Horizontal);
    SetBackgroundColor(design::Colors::Surface);
    SetPadding(design::Spacing::Small);
    SetSpacing(design::Spacing::Small);

    // Group 0 = shared document/history/selection chrome. Group 1 = the active
    // mode's own actions. A visual gap is inserted where the group changes.

    // --- Shared file + history (group 0) ---
    AddButton(L"Save",        controls::IconType::Save, false, true, 0,
              {AppMode::View, AppMode::Comment, AppMode::Edit, AppMode::Organize, AppMode::Tools});
    AddButton(L"Save As",     controls::IconType::None, true,  true, 0,
              {AppMode::View, AppMode::Comment, AppMode::Edit, AppMode::Organize, AppMode::Tools});
    AddButton(L"Print",       controls::IconType::None, true,  true, 0, {AppMode::View});
    AddButton(L"Undo",        controls::IconType::Undo, false, true, 0,
              {AppMode::Comment, AppMode::Edit, AppMode::Organize});
    AddButton(L"Redo",        controls::IconType::Redo, false, true, 0,
              {AppMode::Comment, AppMode::Edit, AppMode::Organize});
    // Select (object picking) is shared by the editing/annotation/tools modes.
    AddButton(L"Select",      controls::IconType::None, true,  true, 0,
              {AppMode::Tools, AppMode::Edit, AppMode::Comment});

    // --- View mode: reading (group 1) ---
    AddButton(L"Zoom Out",    controls::IconType::ZoomOut, false, true, 1, {AppMode::View});
    AddButton(L"ZoomIn",      controls::IconType::ZoomIn,  false, true, 1, {AppMode::View});
    AddButton(L"Fit Width",   controls::IconType::None, true, true, 1, {AppMode::View});
    AddButton(L"Fit Page",    controls::IconType::None, true, true, 1, {AppMode::View});
    AddButton(L"Bookmarks",   controls::IconType::None, true, true, 1, {AppMode::View});
    AddButton(L"First",       controls::IconType::None, true, true, 1, {AppMode::View});
    AddButton(L"Prev",        controls::IconType::None, true, true, 1, {AppMode::View});
    AddButton(L"Next",        controls::IconType::None, true, true, 1, {AppMode::View});
    AddButton(L"Last",        controls::IconType::None, true, true, 1, {AppMode::View});
    AddButton(L"Continuous",  controls::IconType::None, true, true, 1, {AppMode::View});
    AddButton(L"Single",      controls::IconType::None, true, true, 1, {AppMode::View});
    AddButton(L"Hand",        controls::IconType::None, true, true, 1, {AppMode::View});

    // --- Comment mode: annotations (group 1) ---
    // Implemented markups are enabled; the rest are shown disabled.
        AddButton(L"Highlight",   controls::IconType::Highlight, true, true,  1, {AppMode::Comment});
    AddButton(L"Line",        controls::IconType::None, true, true,  1, {AppMode::Comment});
    AddButton(L"Arrow",       controls::IconType::None, true, true,  1, {AppMode::Comment});

    // --- Edit mode: content editing (group 1) ---
    AddButton(L"Add Text",    controls::IconType::AddText, false, true,  1, {AppMode::Edit});
    AddButton(L"Add Image",controls::IconType::None, true, true,  1, {AppMode::Edit});
    AddButton(L"Edit Text",   controls::IconType::None, true, true, 1, {AppMode::Edit});


    // --- Organize mode: page operations (group 1) ---
    AddButton(L"Rotate CW",   controls::IconType::None, true, true,  1, {AppMode::Organize});
    AddButton(L"Rotate CCW",  controls::IconType::None, true, true,  1, {AppMode::Organize});
    AddButton(L"Delete Page", controls::IconType::None, true, true,  1, {AppMode::Organize});
    AddButton(L"Insert Page", controls::IconType::None, true, true,  1, {AppMode::Organize});
    AddButton(L"Extract Page",controls::IconType::None, true, true,  1, {AppMode::Organize});
    AddButton(L"Replace Page",controls::IconType::None, true, true,  1, {AppMode::Organize});

    // --- Tools mode: utilities (group 1; Select is shared above) ---


    // Foundation opens in View (reading) mode.
    m_mode = AppMode::View;
    ApplyModeVisibility();
}

std::shared_ptr<controls::IconButton> Toolbar::AddButton(
    const std::wstring& text, controls::IconType icon, bool isText,
    bool enabled, int group, std::vector<app::AppMode> modes) {
    auto btn = std::make_shared<controls::IconButton>(isText ? text : L"", icon);
    btn->SetColors(design::Colors::Surface, design::Colors::ControlHover, design::Colors::TextPrimary);
    btn->SetEnabled(enabled);
    btn->SetShowText(isText);
    btn->SetOnClick([this, text]() {
        if (onAction) onAction(text);
    });
    AddChild(btn);
    m_buttons[text] = btn;
    m_btns.push_back({ btn, std::move(modes), text, isText, group });
    return btn;
}

void Toolbar::ApplyModeVisibility() {
    for (auto& b : m_btns) {
        bool visible = std::find(b.modes.begin(), b.modes.end(), m_mode) != b.modes.end();
        b.button->SetVisible(visible);
    }
}

void Toolbar::SetMode(app::AppMode mode) {
    m_mode = mode;
    ApplyModeVisibility();
    // Re-flow the now-visible buttons. Guard against being called before the
    // first real layout (bounds still zero); a WM_SIZE will lay us out then.
    if (m_bounds.right > m_bounds.left) {
        Layout(m_bounds);
    }
}

void Toolbar::SetActiveTool(const std::wstring& toolName) {
    // Tools that have a toggled/active visual state.
    static const wchar_t* kToolNames[] = {
        L"Hand", L"Select", L"Highlight", L"Underline", L"Strikeout",
        L"Line", L"Arrow", L"Add Text", L"Edit Text"
    };
    for (const wchar_t* name : kToolNames) {
        auto it = m_buttons.find(name);
        if (it != m_buttons.end()) {
            it->second->SetActive(it->first == toolName);
        }
    }
}

void Toolbar::Layout(const D2D1_RECT_F& bounds) {
    UIElement::Layout(bounds);

    float btnHeight = design::Metrics::ControlHeightNormal;
    float y = bounds.top + (bounds.bottom - bounds.top - btnHeight) / 2.0f; // center vertically
    float leftX = bounds.left + m_padding;
    float rightX = bounds.right - m_padding;

    // First pass: lay out right-aligned items (group 2 or hardcoded names)
    // We do this in reverse order so they stack from right to left.
    for (int i = (int)m_btns.size() - 1; i >= 0; --i) {
        auto& b = m_btns[i];
        if (!b.button || !b.button->IsVisible()) continue;
        
        bool isRightAligned = (b.label == L"Save" || b.label == L"Save As" || b.label == L"Print" || b.label == L"Share" || b.group == 2);
        
        if (isRightAligned) {
            float w;
            if (b.isText) {
                float len = static_cast<float>(b.label.length());
                w = 20.0f + len * 8.0f;
                if (w < 60.0f) w = 60.0f;
            } else {
                w = 36.0f;
            }
            
            b.button->Layout({ rightX - w, y, rightX, y + btnHeight });
            rightX -= (w + m_spacing);
        }
    }

    int prevGroup = -1;
    for (auto& b : m_btns) {
        if (!b.button || !b.button->IsVisible()) continue;

        bool isRightAligned = (b.label == L"Save" || b.label == L"Save As" || b.label == L"Print" || b.label == L"Share" || b.group == 2);
        if (isRightAligned) continue;

        if (prevGroup != -1 && b.group != prevGroup) {
            leftX += design::Spacing::Large1;
        }
        prevGroup = b.group;

        float w;
        if (b.isText) {
            float len = static_cast<float>(b.label.length());
            w = 20.0f + len * 8.0f;
            if (w < 60.0f) w = 60.0f;
        } else {
            w = 36.0f;
        }

        b.button->Layout({ leftX, y, leftX + w, y + btnHeight });
        leftX += w + m_spacing;
    }
}

} // namespace components


